# workarounds:
export PYTHON_EGG_CACHE='/tmp'

kinit csaload1 -kt /home/csaload1/.key

current_time=$(date "+%Y%m%d-%H%M%S")

FILE=/tmp/$2_$current_time.txt
EXTRACT_SQL=$1
DELIMITER=$3
TW_FOLDER=$4


shift
shift
shift
shift
# iterate
while test ${#} -gt 0
do
  impala-shell -i impala.dr.bcbsma.com -d default -k --ssl -B --output_delimiter="$DELIMITER" -q "$1"  >> $FILE
  shift
done


echo $EXTRACT_SQL
impala-shell -i impala.dr.bcbsma.com -d default -k --ssl -B --output_delimiter="$DELIMITER" -q "$EXTRACT_SQL" >> $FILE

#rsync -ratlz  --remove-source-files --rsh="sshpass -p Wintersnow@2019 ssh -o StrictHostKeyChecking=no -l csaload01ts" $FILE  #staging.sftp.bluecrossma.com:$TW_FOLDER

export SSHPASS=Wintersnow@2019
sshpass -e sftp -oBatchMode=no -b - csaload01ts@staging.sftp.bluecrossma.com << !
   cd $TW_FOLDER
   put $FILE
   !rm $FILE
   bye
!


