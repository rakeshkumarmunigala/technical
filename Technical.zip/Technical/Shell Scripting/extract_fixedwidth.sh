# workarounds:
export PYTHON_EGG_CACHE='/tmp'

kinit csaload1 -kt /home/csaload1/.key

current_time=$(date "+%Y%m%d-%H%M%S")

FILE=/tmp/$2_$current_time.txt
EXTRACT_SQL=$1
echo "1111" >> $FILE

#echo "1111" >> $FILE
shift
shift
# iterate
while test ${#} -gt 0
do
  impala-shell -i impala.dr.bcbsma.com -d default -k --ssl --ca_cert=/opt/cloudera/security/x509/cmagent.pem -k -B --output_delimiter="~" -q "$1" | sed 's#~##g' >> $FILE
  shift
done
echo "9999" >> $FILE

impala-shell -i impala.dr.bcbsma.com -d default -k --ssl --ca_cert=/opt/cloudera/security/x509/cmagent.pem -k -B --output_delimiter="~" -q "$EXTRACT_SQL" | sed 's#~##g' >> $FILE

#sshpass -p "Welcome3" scp -r $FILE agower02@mclmp01vr:/bluecloud/agower02

rsync -ratlz  --remove-source-files --rsh="sshpass -p Welcome3 ssh -o StrictHostKeyChecking=no -l agower02" $FILE  mclmp01vr:/bluecloud/agower02