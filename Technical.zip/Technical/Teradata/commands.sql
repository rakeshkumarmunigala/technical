
SELECT * FROM force_di_cntl;

SELECT * FROM platform_instance;


SELECT * FROM platform_subscription;
SELECT * FROM routing_criteria_tree;
SELECT * FROM claim_transmit_request_tracking;



SELECT * FROM routing_criteria;

SELECT * FROM claim_set;

SELECT * FROM claim_event_ascent;




SELECT * FROM claim_data_owner;


SELECT * FROM force_esi.claim_event
UNION
select * from public.claim_event_ascent

SELECT * FROM force_master.claim_set;

SELECT * FROM force_master.platform_subscription;

SELECT * FROM force_master.platform_instance;

SELECT * FROM public.platform_subscription;


SELECT * FROM public.claim_event_cigna;

SELECT * FROM public.claim_event_esi;

SELECT * FROM public.claim_event_ascent;


DELETE FROM claim_event_ascent;

DELETE FROM claim_event_esi;

DELETE FROM claim_event_cigna;




SELECT * FROM public.platform_subscription

select * from public.claim_event_test 
where org_hierarchy_level_3_cd IN ('MKEELEC1','MKEELEC2') limit 10
union
select * from force_master.claim_event 
where commercial_claim_ind = 'Y';

SELECT *
FROM
	public.claim_event_test where org_hierarchy_level_3_cd IN ('MKEELEC1','MKEELEC2') limit 10;
UNION ALL
SELECT *
FROM
	public.claim_event_test where org_hierarchy_level_3_cd = 'MKEELEC2' limit 2;

GRANT SELECT, UPDATE, INSERT, DELETE ON public.force_di_cntl TO app_dba;
 ng 
select * from public.force_di_cntl
where force_load_request_id=17

CREATE TABLE force_distribution.claim_extract_attribute
( 
 claim_extract_attribute_id  integer  NOT NULL ,
 attribute_name       text  NULL ,
 attribute_data_type  text  NULL ,
 last_updated_by      text  NULL ,
 last_updated_ts      timestamp with time zone  NULL ,
  PRIMARY KEY (claim_extract_attribute_id)
);


UPDATE public.force_di_cntl
SET 
process_name='FORCE-DI-CLAIMS-CHECK',
fetch_status='COMPLETED'
where force_load_request_id=17;


UPDATE public.force_di_cntl
SET 
process_name='FORCE-DI-CLAIMS-EXTRACT',
fetch_status='READY',
last_exec_time=CURRENT_TIMESTAMP
where force_load_request_id=17

ALTER TABLE public.claim_event_rak ALTER COLUMN bill_net_check_amt TYPE TEXT;

CREATE TABLE public.force_di_cntl AS SELECT * FROM force_master.force_di_cntl limit 1;

INSERT INTO public.claim_event_rak (claim_event_id, sequence_nbr, serviced_dt, received_ts, claim_source_system_id, source_system_status_cd, source_system_transaction_type_cd, event_origination_id, claim_data_origin_id, claim_data_owner_id, claim_data_source_key_1, claim_data_source_key_2, adjudication_dt, service_provider_id, pharmacy_product_service_id, patient_id, pharmacy_rx_nbr, org_hierarchy_level_1_cd, org_hierarchy_level_2_cd, org_hierarchy_level_3_cd, org_hierarchy_level_4_cd, org_hierarchy_level_5_cd, org_hierarchy_level_6_cd, org_hierarchy_level_7_cd, org_hierarchy_level_8_cd, org_hierarchy_level_9_cd, org_hierarchy_level_10_cd, claim_count_nbr, commercial_claim_ind, specialty_drug_ind, billed_brand_generic_cd, dispensed_brand_generic_cd, nabp, npi, formulary_id, mail_retail_cd, fdb_otc_ind, fill_drug_otc_ind, media_type_cd, adjudicated_pharmacy_class_cd, vaccine_ind, bill_net_check_amt, last_updated_by, last_updated_ts) VALUES ('3332b068-e942-4a6b-86e9-e25062f0e2a4', 1, '2019-03-21 -04', '2020-06-03 10:30:13.037000-04', 1, 'B', '31', NULL, NULL, 1, '978529348128119670', '0', '2019-03-21 -04', NULL, '55111071730        ', '385517841', '000000854683', '47179', '7179', 'MKEELEC1', '', 'MKEELECA01', NULL, NULL, NULL, NULL, NULL, '1', 'Y', 'N', 'G', '2', '5129007     ', '1356382220', '0000001702', 'R', '', 'N', '4', '1', 'N', '943.24', 'FORCE', '2020-06-03 10:30:13.037000-04')