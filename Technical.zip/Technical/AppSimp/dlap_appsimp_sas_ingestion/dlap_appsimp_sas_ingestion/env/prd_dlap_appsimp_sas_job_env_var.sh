#!/bin/bash

export JOB_NAMENODE_URL=hdfs://odhprodhdfs
export JOB_ENV=prd
export JOB_DOMAIN=dlap_appsimp_sas

export JOB_OOZIE_URL=https://bclgp20vr.bcbsma.com:11443/oozie/

export JOB_SPARK_ANACONDA_PYTHON=/opt/cloudera/parcels/Anaconda/envs/py36/bin/python
export JOB_SPARK_DRIVER_MEMORY=2G
export JOB_SPARK_EXECUTOR_MEMORY=2G
export JOB_SPARK_NUM_EXECUTORS=5
export JOB_SPARK_EXECUTOR_CORES=2
export JOB_SPARK_DRIVER_CORES=2
export JOB_SPARK_YARN_MAXAPPATTEMPTS=1

HOME_PATH=`echo $HOME | cut -d '/' -f 2`

if [[ $HOME_PATH == "home" ]]
then
	TW_ID_FILE_PATH=$HOME/.ssh/id_rsa
else
	TW_ID_FILE_PATH=$HOME/tw_id_file
fi

export JOB_HIVE_BEELINE_URL=jdbc:hive2://bclgp20vr.bcbsma.com:10000/
export JOB_HIVE_BEELINE_PRINCIPAL=hive/hive.odhprod.bcbsma.com@BCBSMAMD.NET
export JOB_HIVE_BEELINE_SSL=true

export JOB_SYNCSORT_SUCCESS_HDFS_DIR=/$JOB_ENV/raw/sas/oozie/syncsort/
export JOB_INGESTION_SUCCESS_HDFS_DIR=/$JOB_ENV/raw/sas/oozie/ingestion/

export JOB_COMMON_ARGS="tw_id_file=$TW_ID_FILE_PATH hive2_jdbc_url=$JOB_HIVE_BEELINE_URL hive2_jdbc_principal=$JOB_HIVE_BEELINE_PRINCIPAL hive2_jdbc_ssl=$JOB_HIVE_BEELINE_SSL syncsort_success_hdfs_dir=$JOB_SYNCSORT_SUCCESS_HDFS_DIR ingestion_success_hdfs_dir=$JOB_INGESTION_SUCCESS_HDFS_DIR support_mail_list=amar.kashyap@bcbsma.com,saisunil.vanam@bcbsma.com,rakesh.munigala@bcbsma.com,siva.sangupillai@bcbsma.com"
