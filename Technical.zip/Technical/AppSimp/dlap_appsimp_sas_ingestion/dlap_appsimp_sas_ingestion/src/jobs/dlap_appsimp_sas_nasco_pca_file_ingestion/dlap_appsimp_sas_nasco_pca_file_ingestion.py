"""dlap_appsimp_sas_nasco_pca_file_ingestion.py: This Program Reads the Data from Source File and Ingest the Data into Hive Curate Table"""

__author__      = "Amar Kashyap"
__copyright__   = "Copyright 2019, This Code is Developed for BCBSMA by IBM Under Appsimp Program - SAS Mainframe to DLAP Migration"
__credits__     = ["Ramu Nair", "Rakesh Munigala", "Sai Sunil Vanam"]
__version__     = "1.0"
__maintainer__  = "Amar Kashyap"
__email__       = "amar.kashyap@bcbsma.com, amakashy@in.ibm.com"

import os,sys,shutil,json,traceback,argparse,socket,time
from datetime import datetime
from dateutil.relativedelta import *
from enum import Enum

from pyspark.sql import SparkSession
from pyspark.sql.types import *
from pyspark.sql.functions import *
from py4j.java_gateway import java_import

from shared import dlap_appsimp_sas_mail_util as mu
from shared import dlap_appsimp_sas_audit_update as au
from shared import dlap_appsimp_sas_sftp_util as tw
from shared import dlap_appsimp_sas_configs as cfg

class DataValidationError(Exception): 
	def __init__(self, value): 
		self.value = value 
	def __str__(self): 
		return(repr(self.value))

class FileNotFoundError(Exception):
	def __init__(self, value):
		self.value = value	
	def __str__(self):
		return(repr(self.value))

class dlap_appsimp_sas_nasco_pca_file_ingestion:
	def __init__(self,spark,args):
		java_import(spark._jvm, 'org.apache.hadoop.fs.Path')
		self.spark = spark
		self.env = args['env']
		self.dmn = args['dmn']
		self.temp_dir = args['temp_dir']
		self.args = args
		self.job_nm = spark.sparkContext.appName
		self.yarn_app_id = spark.sparkContext.applicationId
		self.start_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
		self.job_run_time = datetime.today().strftime('%Y-%m-%d-%H-%M-%S')
		self.host_nm = socket.getfqdn()
		self.hdfs_output_file = None 
		self.from_mail = spark.sparkContext.sparkUser()
		self.log_file = args['log_file']
		self.logger = spark.sparkContext._jvm.org.apache.log4j.LogManager.getLogger(__name__)
	def get_schema(self,schema_list,all_string = False):
		import operator
		schema_list = sorted(schema_list, key=lambda k: k["metadata"]["id"])
		schema_fields = []
		for col in schema_list:
			if all_string:
				schema_fields.append(StructField(col['name'], StringType(), True, col["metadata"]))
			else:
				if col['type'] == "STRING":
					schema_fields.append(StructField(col['name'], StringType(), True, col["metadata"]))
				elif col['type'] in ["INTEGER"]:
					schema_fields.append(StructField(col['name'], IntegerType(), True, col["metadata"]))
				elif col['type'] in ["LONG"]:
					schema_fields.append(StructField(col['name'], LongType(), True, col["metadata"]))
				elif col['type'] in ["DOUBLE"]:
					schema_fields.append(StructField(col['name'], DoubleType(), True, col["metadata"]))
				elif col['type'] == "TIMESTAMP":
					schema_fields.append(StructField(col['name'], DateType(), True, col["metadata"]))
		return StructType(schema_fields)
	def get_pca_mapAndTrsformQuery(self,raw_schema_enum,curate_schema_enum,ingest_file_nm):
		mapAndTrsformQuery = """
			{0.sub_plan.name} as {1.sub_pln_num.name},
			{0.svc_plan.name} as {1.svc_pln_num.name},
			{0.subscriber.name} as {1.sub_num.name},
			{0.icn.name} as {1.clm_num.name},
			cast
			(
				from_unixtime(unix_timestamp({0.fdos.name},'MMddyyyy') ,'yyyy-MM-dd') as timestamp
			) as {1.frst_day_of_svc.name},
			cast
			(
				from_unixtime(unix_timestamp({0.ldos.name},'MMddyyyy') ,'yyyy-MM-dd') as timestamp
			) as {1.lst_day_of_svc.name},
			cast
			(
				from_unixtime(unix_timestamp({0.check_date.name},'MMddyyyy') ,'yyyy-MM-dd') as timestamp
			) as {1.chk_dt.name},
			{0.prov_num.name} as {1.prov_num.name},
			cast(concat(trim(substr({0.allowed_charges.name},-1)),trim(substr({0.allowed_charges.name},1,13))) as double) as {1.allow_chrgs.name},
			cast(concat(trim(substr({0.prov_comp_amt.name},-1)),trim(substr({0.prov_comp_amt.name},1,13))) as double) as {1.prov_cmp_amt.name},
			cast(concat(trim(substr({0.prov_comp_pct.name},-1)),trim(substr({0.prov_comp_pct.name},1,13))) as double) as {1.prov_cmp_pct.name},
			'{2}' as {1.file_nm.name},
			current_timestamp() as {1.load_timestamp.name},
			substr(split('{2}','_')[3],1,8) as {1.feed_dt.name}
			""".format(raw_schema_enum,curate_schema_enum,ingest_file_nm)
		return mapAndTrsformQuery
	def run(self):
		input_trigger_list = None
		ingest_status = None
		tw_tgt_file_nm = None
		local_output_dir = self.temp_dir + "/"
		self.logger.info('Started Running the Job: ' + self.job_nm)
		self.logger.info('Job is Running in Region: ' + self.env)
		self.logger.info('Job is Running for Domain: ' + self.dmn)
		self.logger.info('Job is Running on Hostname: ' + self.host_nm)
		self.logger.info('Job is using Temp Directory: ' + self.temp_dir)
		self.logger.info('Job Start Time: ' + self.start_time)
		self.logger.info('Job Yarn Application Id is: ' + self.yarn_app_id)
		self.logger.info('Job Log File Name is: ' + self.log_file)
		self.logger.info('Started Setting Job Level SparkConf')
		self.spark.conf.set("spark.sql.crossJoin.enabled", "true")
		self.spark.conf.set("spark.sql.shuffle.partitions", "4")
		self.spark.conf.set("hive.exec.dynamic.partition", "true")
		self.spark.conf.set("hive.exec.dynamic.partition.mode", "nonstrict")
		self.logger.info('Finished Setting Job Level SparkConf')

		self.logger.info('Defining Data Validation Function')
		def data_validation(row,schema,zone):
			not_valid = []
			for i in range(len(schema.fields)):
				field = schema.fields[i]
				if zone == "raw":
					try:
						if str(field.dataType) == "StringType":
							data_type = "String"
							str(row[i])
						elif str(field.dataType) in ["IntegerType","LongType"]:
							data_type = "Integer"
							int(row[i])
						elif str(field.dataType) == "DoubleType":
							data_type = "Double"
							float(row[i])
					except Exception as e:
						not_valid.append(field.name + " : Expected " + data_type)
				elif zone == "curate":
					if str(field.dataType) == "StringType" and row[i] != None and not isinstance(row[i],str):
						not_valid.append(field.name + " : Expected String")
					elif str(field.dataType) in ["IntegerType","LongType"] and row[i] != None and not isinstance(row[i],int):
						not_valid.append(field.name + " : Expected Integer")
					elif str(field.dataType) == "DoubleType" and row[i] != None and not isinstance(row[i],float):
						not_valid.append(field.name + " : Expected Double")
			if len(not_valid) > 0:
				return (row,"isNotValid",not_valid)
			else:
				return (row,"isValid",not_valid)
		self.logger.info('Defined Data Validation Function')

		self.logger.info('Defining Fixed Width Parser Function')
		def fixedWidthParser(row,schema,conv=False):
			result = []
			for i in range(len(schema.fields)):
				field = schema.fields[i]
				position = field.metadata['position']
				size = field.metadata['size']
				value = row[0][position-1:position-1+size]
				if conv:
					if str(field.dataType) == "StringType":
						result.append(str(value))
					elif str(field.dataType) in ["IntegerType","LongType"]:
						result.append(int(value.strip()))
					elif str(field.dataType) == "DoubleType":
						result.append(float(value.strip()))
				else:
					result.append(value)
			return tuple(result)
		self.logger.info('Defined Fixed Width Parser Function')
		
		try:
			feed_cycle = self.args['feed_cycle']
			self.logger.info('Feed Cycle is: ' + feed_cycle)

			success_file_nm = self.args["success_file_nm"]
			self.logger.info('Success File Name is: ' + success_file_nm)

			ingestion_success_file_path = self.args["ingestion_success_hdfs_dir"] + success_file_nm
			self.logger.info('Ingestion Success File is: ' + ingestion_success_file_path)

			self.logger.info('Started Reading Job Configurations from Config Table')
			config = cfg.get_config(self.spark,self.env,self.job_nm)
			self.logger.info('Job Configurations Read from Config Table are: ' + json.dumps(config))
			staging_hdfs_dir = "/" + self.env + config["staging_hdfs_dir"]
			error_hdfs_dir = "/" + self.env + config["error_hdfs_dir"]
			schema_hdfs_dir = "/" + self.env + config["schema_hdfs_dir"]
			tw_server = config["tw_server"]
			tw_user = config["tw_user"]
			tw_ascii_src_dir = config["tw_ascii_src_dir"]
			tw_src_file_pattern = config["tw_src_file_pattern"] + "$"
			self.logger.info('Successfully Read Job Configurations from Config Table')

			self.logger.info('Staging HDFS Dir is: ' + staging_hdfs_dir)
			self.logger.info('Error HDFS Dir is: ' + error_hdfs_dir)
			self.logger.info('Source Schema HDFS Dir is: ' + schema_hdfs_dir)
			self.logger.info('TW FTP Server is: ' + tw_server)
			self.logger.info('TW FTP User is: ' + tw_user)
			self.logger.info('TW FTP Source Dir is: ' + tw_ascii_src_dir)
			self.logger.info('TW FTP Source File Name Pattern is: ' + tw_src_file_pattern)

			fs = self.spark._jvm.org.apache.hadoop.fs.FileSystem.get(self.spark._jsc.hadoopConfiguration())
			if fs.exists(self.spark.sparkContext._jvm.Path(ingestion_success_file_path)):
				fs.delete(self.spark.sparkContext._jvm.Path(ingestion_success_file_path),False)
				self.logger.info('Old Ingestion Success File Deleted Successfully')
			else:
				self.logger.info('Old Ingestion Success File Not Found for Deletion')

			try:
				if 'tw_id_file' in self.args or 'tw_password' in self.args:
					self.logger.info('Downloading Source Ingestion File from TW FTP Server at Location: ' + tw_ascii_src_dir)
					if 'tw_id_file' in self.args:
						tw_id = self.args['tw_id_file']
						tw_tgt_file_nm = tw.download_file(self.spark,tw_server,tw_user,tw_ascii_src_dir,local_output_dir,tw_src_file_pattern,identity=tw_id)
					elif 'tw_password' in self.args:
						tw_pass = self.args['tw_password']
						tw_tgt_file_nm = tw.download_file(self.spark,tw_server,tw_user,tw_ascii_src_dir,local_output_dir,tw_src_file_pattern,password=tw_pass)
			except Exception as e:
				self.logger.info('Failed to Download Source Ingestion File from TW FTP Server')
				raise

			if tw_tgt_file_nm == None:
				raise(FileNotFoundError("Source Ingestion File from TW FTP Server Not Found"))
			else:
				self.logger.info('Successfully Downloaded Source Ingestion File from TW FTP Server with File Name: ' + tw_tgt_file_nm)

			self.logger.info('Started writing Source Ingestion File from Local to HDFS Staging Directory: ' + staging_hdfs_dir)
			local_ingest_file_path = local_output_dir + tw_tgt_file_nm
			fs.copyFromLocalFile(self.spark.sparkContext._jvm.Path(local_ingest_file_path),self.spark.sparkContext._jvm.Path(staging_hdfs_dir))
			self.logger.info('Finished writing Source Ingestion File from Local to HDFS Staging Directory')

			self.logger.info('Reading Feed Date from Local Ingest File Name')
			feed_dt = local_ingest_file_path.split("/")[-1].split("_")[3][:8]
			feed_mnth= ""
			self.logger.info('Feed Date from Local Ingest File Name is: ' + feed_dt)

			self.logger.info('Connecting to HiveServer2 using JDBC')
			java_import(self.spark._jvm, 'org.apache.hive.jdbc.HiveDriver')
			driver = self.spark.sparkContext._jvm.HiveDriver()
			hive2_jdbc_url = self.args['hive2_jdbc_url']
			hive2_jdbc_principal = self.args['hive2_jdbc_principal']
			hive2_jdbc_ssl = self.args['hive2_jdbc_ssl']
			hive2_jdbc_connect_url = hive2_jdbc_url +";principal="+ hive2_jdbc_principal + ";ssl=" + hive2_jdbc_ssl + ";"
			self.logger.info('Hive2 JDBC CONNECT URL is ' + hive2_jdbc_connect_url)
			conn = driver.connect(hive2_jdbc_connect_url,self.spark.sparkContext._jvm.java.util.Properties())
			stmt = conn.createStatement()
			self.logger.info('Successfully Connected to HiveServer2 using JDBC')

			self.logger.info('Trying to Ingest the Nasco PCA File with Feed Date: ' + feed_dt)

			input_trigger_list = [	(tw_tgt_file_nm, "schema_claim_sas_nasco_pca.json")]

			self.logger.info('Validating if all the Input Trigger File Exists')
			fs = self.spark._jvm.org.apache.hadoop.fs.FileSystem.get(self.spark._jsc.hadoopConfiguration())
			for ingest_file_nm,schema_file_nm in input_trigger_list:
				try:
					fs.getFileStatus(self.spark.sparkContext._jvm.Path(staging_hdfs_dir + ingest_file_nm))
				except Exception as e:
					self.logger.info('Input Ingest Trigger File Does Not Exists: ' + ingest_file_nm)
					raise
				try:
					fs.getFileStatus(self.spark.sparkContext._jvm.Path(schema_hdfs_dir + schema_file_nm))
				except Exception as e:
					self.logger.info('Input Schema Trigger File Does Not Exists: ' + schema_file_nm)
					raise
			self.logger.info('Validation of Input Trigger File Done Successfully')

			ingest_status = {}

			for ingest_file_nm,schema_file_nm in input_trigger_list:
				ingest_status[ingest_file_nm] = {'ParquetWrite': 'FAILED','AlterQuery': 'FAILED','RawMove': 'FAILED'}
				ingest_status[ingest_file_nm]['staging_hdfs_dir'] = staging_hdfs_dir

				self.logger.info('Ingestion File Name is ' + ingest_file_nm)
				self.logger.info('Source Schema File Name is ' + schema_file_nm)

				self.logger.info('Started Reading the Schema File')
				jsonSchema_0 = self.spark.read.text(schema_hdfs_dir + schema_file_nm)
				jsonSchema = jsonSchema_0.rdd.map(lambda l: (1,l.value)).groupByKey().map(lambda l: "".join(list(l[1]))).collect()
				dataset = json.loads(jsonSchema[0])
				curate_table_name = dataset["name"]
				curate_db_name = self.env + "_curate_" + dataset["business_domain"]
				curate_hdfs_dir= "/" + self.env + "/curate/" + dataset["business_domain"] + "/" + dataset["name"] + "/"
				ingest_status[ingest_file_nm]['curate_hdfs_dir'] = curate_hdfs_dir
				raw_hdfs_dir = "/" + self.env +"/raw/"+ dataset["business_domain"] +"/" + dataset["source_system_code"] +"/"+ dataset["name"] +"/"
				ingest_status[ingest_file_nm]['raw_hdfs_dir'] = raw_hdfs_dir
				partition_keys_list = dataset["partition_keys"]
				raw_schema_list = dataset["raw_schema"]
				curate_schema_list = dataset["curate_schema"]
				self.logger.info('Successfully Read the Schema File')

				self.logger.info('Curate DB Name is ' + curate_db_name)
				self.logger.info('Curate Table Name is ' + curate_table_name)
				self.logger.info('Curate HDFS Directory is ' + curate_hdfs_dir)
				self.logger.info('Curate DB Name is ' + curate_db_name)
				self.logger.info('Raw HDFS Directory is ' + raw_hdfs_dir)

				self.logger.info('Get Raw Schema and Raw Schema Enum')
				raw_schema = self.get_schema(raw_schema_list)
				raw_string_schema = self.get_schema(raw_schema_list,all_string = True)
				raw_schema_enum = Enum('raw_schema_enum',[c.name for c in raw_schema.fields],start=0)
				self.logger.info('Successfully Got Raw Schema, Raw String Schema and Raw Schema Enum')

				self.logger.info('Get Curate Schema and Curate Schema Enum')
				curate_schema = self.get_schema(curate_schema_list)
				curate_schema_enum = Enum('curate_schema_enum',[c.name for c in curate_schema.fields],start=0)
				self.logger.info('Successfully Got Curate Schema and Curate Schema Enum')

				#self.logger.info('Raw Schema are ' + raw_schema)
				#self.logger.info('Curate Schema are ' + curate_schema)
				partition_columns = partition_keys_list
				self.logger.info('Curate Table Partitioning Columns are ' + "".join(partition_columns))

				raw_temp_table_view = "raw_temp_view_" + curate_table_name
				self.logger.info('Raw Temp Table View is: ' + raw_temp_table_view)

				curate_temp_table_view = "curate_temp_view_" + curate_table_name
				self.logger.info('Curate Temp Table View is: ' + curate_temp_table_view)

				self.logger.info('Creating Mapping and Transformation Query')

				if schema_file_nm == "schema_claim_sas_nasco_pca.json":
					mapAndTrsformQuery = self.get_pca_mapAndTrsformQuery(raw_schema_enum,curate_schema_enum,ingest_file_nm)

				self.logger.info('Map and Transform Query is: ' + mapAndTrsformQuery)

				self.logger.info('Reading Ingest File From Staging HDFS Directory')
				A0 = self.spark.read.text(staging_hdfs_dir + ingest_file_nm)
				self.logger.info('Read Ingest File From Staging HDFS Directory')

				self.logger.info('Started Parsing the Records through fixedWidthParser')
				A1 = A0.rdd.map(lambda row: fixedWidthParser(row,raw_string_schema))
				A = self.spark.createDataFrame(A1,raw_string_schema)
				self.logger.info('Parsing the Records through fixedWidthParser Done')

				self.logger.info('Started Doing Data Validation on Raw Ingest File')
				B = A.rdd.map(lambda row: data_validation(row,raw_schema,"raw"))
				notValidCount = B.filter(lambda row: row[1] == "isNotValid").count()
				if notValidCount != 0:
					self.logger.info('Data Validation on Raw Ingest File Failed')
					self.logger.info('Number of Records Failed Raw Data Validation is: ' + str(notValidCount))
					error_file_name = error_hdfs_dir + ingest_file_nm
					B.filter(lambda row: row[1] == "isNotValid").saveAsTextFile(error_hdfs_dir +"RAW_"+ ingest_file_nm)
					self.logger.info('Bad Records Written in Error File: ' + error_hdfs_dir +"RAW_"+ ingest_file_nm)
					self.logger.info('Aborting Ingest Process')
					raise(DataValidationError("Raw Data Validation Failed"))
				else:
					self.logger.info('Data Validation on Raw Ingest File Succeeded')

				self.logger.info('Creating Raw Data Frame by Parsing through fixedWidthParser and Applying Raw Schema')
				C0 = self.spark.read.text(staging_hdfs_dir + ingest_file_nm)
				C1 = C0.rdd.map(lambda row: fixedWidthParser(row,raw_schema,conv=True))
				C = self.spark.createDataFrame(C1,raw_schema)
				C.createOrReplaceTempView(raw_temp_table_view)
				#B.map(lambda row: row[0])
				#D = self.spark.createDataFrame(C,raw_schema)
				#D.createOrReplaceTempView(raw_temp_table_view)
				self.logger.info('Created Raw Data Frame Successfully by Parsing through fixedWidthParser and Applying Raw Schema')

				self.logger.info('Applying Curate Mapping and Transformation on Raw Data Frame')
				E = self.spark.sql("""SELECT {0} FROM {1}""".format(mapAndTrsformQuery,raw_temp_table_view))
			
				self.logger.info('Started Doing Data Validation on Curate Data Frame')
				F = E.rdd.map(lambda row: data_validation(row,curate_schema,"curate"))
				notValidCount = F.filter(lambda row: row[1] == "isNotValid").count()
				if notValidCount != 0:
					self.logger.info('Data Validation on Curate Data Frame Failed')
					self.logger.info('Number of Records Failed Curate Data Validation is: ' + str(notValidCount))
					self.logger.info('Aborting Ingest Process')
					F.filter(lambda row: row[1] == "isNotValid").saveAsTextFile(error_hdfs_dir +"CURATE_"+ ingest_file_nm)
					self.logger.info('Bad Records Written in Error File: ' + error_hdfs_dir +"CURATE_"+ ingest_file_nm)
					raise(DataValidationError("Curate Data Validation Failed"))
				else:
					self.logger.info('Data Validation on Curate Data Frame Succeeded')

				E.createOrReplaceTempView(curate_temp_table_view)
				#self.logger.info('The Curate Data are: ' + E.show(truncate=False))

				try:
					self.logger.info('Writting Curate Data to Parquet File')
					E.write.mode("append").partitionBy(partition_columns).parquet(curate_hdfs_dir)
					ingest_status[ingest_file_nm]['ParquetWrite'] = 'SUCCESS'
					self.logger.info('Curate Data Successfully Written to Parquet File')
				except Exception as e:
					self.logger.info('Failed to Write Curate Data to Parquet File')
					raise

				try:
					self.logger.info('Adding Partitions to Table')
					alterQuery = """MSCK REPAIR TABLE {0}.{1}""".format(curate_db_name,curate_table_name)
					self.logger.info('Alter Query is: ' + alterQuery)
					result = stmt.execute(alterQuery)
					ingest_status[ingest_file_nm]['AlterQuery'] = 'SUCCESS'
					self.logger.info('Partitions Added Successfully')
				except Exception as e:
					self.logger.info('Failed to Add Partitions to Table')
					raise

				try:
					self.logger.info('Moving Ingest File from Staging HDFS to Raw HDFS Directory')
					fs = self.spark._jvm.org.apache.hadoop.fs.FileSystem.get(self.spark._jsc.hadoopConfiguration())
					if fs.exists(self.spark.sparkContext._jvm.Path(raw_hdfs_dir + ingest_file_nm)):
						fs.rename(
							self.spark.sparkContext._jvm.Path(raw_hdfs_dir + ingest_file_nm),
							self.spark.sparkContext._jvm.Path(raw_hdfs_dir + ingest_file_nm + "_" +datetime.today().strftime('%Y%m%d%H%M%S')))
						self.logger.info('Backed Up Older Raw HDFS Ingest File')
					fs.rename(
						self.spark.sparkContext._jvm.Path(staging_hdfs_dir + ingest_file_nm),
						self.spark.sparkContext._jvm.Path(raw_hdfs_dir + ingest_file_nm))
					ingest_status[ingest_file_nm]['RawMove'] = 'SUCCESS'
					self.logger.info('Successfully Moved Ingest File from Staging to Raw HDFS Directory')
				except Exception as e:
					self.logger.info('Failed to Move Ingest File from Staging HDFS to RAW HDFS Directory')
					raise

				self.logger.info('Ingest Status is: ' + json.dumps(ingest_status))

			self.logger.info('Closing Connection to HiveServer2')
			conn.close()
			self.logger.info('Successfully Closed Connection to HiveServer2')

			self.logger.info('Writing Ingestion Success File: ' + ingestion_success_file_path)
			write_stream = fs.create(self.spark.sparkContext._jvm.Path(ingestion_success_file_path))
			ingestion_success_status = {}
			ingestion_success_status["feed_dt"] = feed_dt
			if feed_mnth == "":
				if feed_cycle == "MONTHLY" and datetime.strptime(feed_dt,"%Y%m%d").day in range(1,27):
					feed_mnth = (datetime.strptime(feed_dt,"%Y%m%d") - relativedelta(months=1)).strftime('%m')
				else:
					feed_mnth = datetime.strptime(feed_dt,"%Y%m%d").strftime('%m')
			ingestion_success_status["feed_mnth"] = feed_mnth
			self.logger.info('Ingestion Success Status is: ' + json.dumps(ingestion_success_status))
			write_stream.writeBytes(json.dumps(ingestion_success_status)+"\n")
			write_stream.close()
			self.logger.info('Successfully Written to Ingestion Success File: ' + ingestion_success_file_path)

			try:
				if 'tw_id_file' in self.args or 'tw_password' in self.args:
					self.logger.info('Removing Source Ingestion File from TW FTP Server at Location: ' + tw_ascii_src_dir)
					if 'tw_id_file' in self.args:
						tw_id = self.args['tw_id_file']
						tw_tgt_file_nm = tw.remove_file(self.spark,tw_server,tw_user,tw_ascii_src_dir,tw_tgt_file_nm,identity=tw_id)
					elif 'tw_password' in self.args:
						tw_pass = self.args['tw_password']
						tw_tgt_file_nm = tw.remove_file(self.spark,tw_server,tw_user,tw_ascii_src_dir,tw_tgt_file_nm,password=tw_pass)
			except Exception as e:
				self.logger.info('Failed to Remove Source Ingestion File from TW FTP Server')

			self.logger.info('Appsimp Audit logs table will be updated with SUCCESS Status')
			au.set_success(self.spark,self.env,self.job_nm,self.host_nm,self.yarn_app_id,self.start_time,"",self.log_file,self.dmn)
			self.end_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
			self.logger.info('Job End Time is: ' + self.end_time)
			self.logger.info('Finished Executing the Job: ' + self.job_nm)
		except Exception as e:
			self.logger.info('Rolling back Ingested Data if Required')
			if ingest_status != None and input_trigger_list != None:
				for ingest_file_nm,schema_file_nm in input_trigger_list:
					file_key = ingest_file_nm
					if file_key in ingest_status.keys() and ingest_status[file_key]['RawMove'] == 'SUCCESS':
						self.logger.info('Rolling back Ingest File from RAW HDFS to Staging HDFS Directory')
						self.logger.info('Deleting RAW HDFS Directory: ' + ingest_status[file_key]['raw_hdfs_dir'] + ingest_file_nm)
						fs.delete(self.spark.sparkContext._jvm.Path(ingest_status[file_key]['raw_hdfs_dir'] + ingest_file_nm),True)
						self.logger.info('Deleted RAW HDFS Directory Successfully')
					if file_key in ingest_status.keys() and (ingest_status[file_key]['AlterQuery'] == 'SUCCESS' or ingest_status[file_key]['ParquetWrite'] == 'SUCCESS'):
						self.logger.info('Rolling back Ingest File from Curate HDFS Directory')
						self.logger.info('Deleting Curate HDFS Directory: '+ ingest_status[file_key]['curate_hdfs_dir'] +'feed_dt='+ feed_dt)
						fs.delete(self.spark.sparkContext._jvm.Path(ingest_status[file_key]['curate_hdfs_dir'] + 'feed_dt='+ feed_dt),True)
						self.logger.info('Deleting Curate HDFS Directory Sucessfully')
				self.logger.info('Rolling back Ingested Data Done')
			self.logger.info('Appsimp Audit logs table will be updated with FAILED Status')
			au.set_failed(self.spark,self.env,self.job_nm,self.host_nm,self.yarn_app_id,self.start_time,"",self.log_file,self.dmn)
			raise

def main(spark,**args):
	logger = spark.sparkContext._jvm.org.apache.log4j.LogManager.getLogger(__name__)
	obj =  dlap_appsimp_sas_nasco_pca_file_ingestion(spark,args)
	logger.info("Successfully Initialized the Pyspark Job: " + spark.sparkContext.appName)
	try:
		obj.run()
	except Exception as e:
		raise
