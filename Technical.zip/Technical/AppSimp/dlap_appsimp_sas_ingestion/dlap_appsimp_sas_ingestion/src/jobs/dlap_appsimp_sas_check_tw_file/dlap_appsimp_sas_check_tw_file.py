"""dlap_appsimp_sas_check_tw_file.py: This Program Checks if Nasco File are Available on TW FTP Server for Ingestion into DLAP"""

__author__      = "Amar Kashyap"
__copyright__   = "Copyright 2019, This Code is Developed for BCBSMA by IBM Under Appsimp Program - SAS Mainframe to DLAP Migration"
__credits__     = ["Ramu Nair", "Rakesh Munigala", "Sai Sunil Vanam"]
__version__     = "1.0"
__maintainer__  = "Amar Kashyap"
__email__       = "amar.kashyap@bcbsma.com, amakashy@in.ibm.com"

import os,sys,shutil,json,traceback,argparse,socket,time
from datetime import datetime
from enum import Enum
import re

from pyspark.sql import SparkSession
from pyspark.sql.types import *
from pyspark.sql.functions import *
from py4j.java_gateway import java_import

from shared import dlap_appsimp_sas_mail_util as mu
from shared import dlap_appsimp_sas_audit_update as au
from shared import dlap_appsimp_sas_configs as cfg

class TWFileSearchTriggerError(Exception):
	def __init__(self, value):
		self.value = value
	def __str__(self):
		return(repr(self.value))

class TWAuthValidationError(Exception): 
	def __init__(self, value): 
		self.value = value 
	def __str__(self): 
		return(repr(self.value))

class FileNotFoundError(Exception):
	def __init__(self, value):
		self.value = value	
	def __str__(self):
		return(repr(self.value))

class dlap_appsimp_sas_check_tw_file:
	def __init__(self,spark,args):
		self.spark = spark
		self.env = args['env']
		self.dmn = args['dmn']
		self.temp_dir = args['temp_dir']
		self.args = args
		self.job_nm = spark.sparkContext.appName
		self.yarn_app_id = spark.sparkContext.applicationId
		self.start_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
		self.job_run_time = datetime.today().strftime('%Y-%m-%d-%H-%M-%S')
		self.host_nm = socket.getfqdn()
		self.from_mail = spark.sparkContext.sparkUser()
		self.support_mail_list = args['support_mail_list'].split(',')
		self.log_file = args['log_file']
		self.logger = spark.sparkContext._jvm.org.apache.log4j.LogManager.getLogger(__name__)
	def run(self):
		tw_id_file = None
		tw_password = None
		tw_tgt_file_nm = None
		self.logger.info('Started Running the Job: ' + self.job_nm)
		self.logger.info('Job is Running in Region: ' + self.env)
		self.logger.info('Job is Running for Domain: ' + self.dmn)
		self.logger.info('Job is Running on Hostname: ' + self.host_nm)
		self.logger.info('Job is using Temp Directory: ' + self.temp_dir)
		self.logger.info('Job Start Time: ' + self.start_time)
		self.logger.info('Job Yarn Application Id is: ' + self.yarn_app_id)
		self.logger.info('Job Log File Name is: ' + self.log_file)
		self.logger.info('Started Setting Job Level SparkConf')
		self.spark.conf.set("spark.sql.crossJoin.enabled", "true")
		self.spark.conf.set("spark.sql.shuffle.partitions", "4")
		self.spark.conf.set("hive.exec.dynamic.partition", "true")
		self.spark.conf.set("hive.exec.dynamic.partition.mode", "nonstrict")
		self.logger.info('Finished Setting Job Level SparkConf')

		try:
			tw_src_dir = ""
			tw_src_file_pattern = ""
			tw_src_file_pattern_prefix = ""
			job_type = ""

			if 'job_type' in self.args:
				job_type = self.args['job_type'].lower() + " "

			if 'tw_src_dir' in self.args:
				tw_src_dir = self.args['tw_src_dir']

			if 'tw_src_file_pattern' in self.args:
				tw_src_file_pattern = self.args['tw_src_file_pattern']

			if 'tw_src_file_pattern_prefix' in self.args:
				tw_src_file_pattern_prefix = self.args['tw_src_file_pattern_prefix']

			self.logger.info('Started Reading Job Configurations from Config Table')
			config = cfg.get_config(self.spark,self.env,self.job_nm)
			self.logger.info('Job Configurations Read from Config Table are: ' + json.dumps(config))
			tw_server = config["tw_server"]
			tw_user = config["tw_user"]
			if 'tw_src_dir' in config.keys():
				tw_src_dir = config["tw_src_dir"]
			if 'tw_src_file_pattern' in config.keys():
				tw_src_file_pattern = config["tw_src_file_pattern"]
			if 'tw_src_file_pattern_prefix' in config.keys():
				tw_src_file_pattern_prefix =  config["tw_src_file_pattern_prefix"]
			self.logger.info('Successfully Read Job Configurations from Config Table')

			self.logger.info('TW FTP Server is: ' + tw_server)
			self.logger.info('TW FTP User is: ' + tw_user)
			self.logger.info('TW FTP Source Directory is: ' + tw_src_dir)
			self.logger.info('TW FTP Source File Name Pattern is: ' + tw_src_file_pattern)
			self.logger.info('TW FTP Source File Name Pattern Prefix is: ' + tw_src_file_pattern_prefix)

			file_search_trigger = None
			if tw_src_dir == "":
				raise(TWFileSearchTriggerError("TW FTP Source Directory Not Found"))

			if tw_src_file_pattern == "":
				raise(TWFileSearchTriggerError("TW FTP Source File Pattern Not Found"))

			if 'tw_id_file' in self.args:
				tw_id_file = self.args['tw_id_file']
			elif 'tw_password' in self.args:
				tw_password = self.args['tw_password']
			else:
				raise(TWAuthValidationError("No Authentication Mechanism Provided to Connect to TW FTP Server"))

			self.logger.info('Connecting to TW Server: ' + tw_server)
			try:
				java_import(self.spark._jvm,'com.jcraft.jsch.JSch')
				jsch = self.spark._jvm.JSch()
				if tw_id_file != None and tw_password == None:
					jsch.addIdentity(tw_id_file)
				s = jsch.getSession(tw_user,tw_server,22)
				s.setConfig("StrictHostKeyChecking","no")
				if tw_id_file == None and tw_password != None:
					s.setPassword(password)
				s.connect()
				c = s.openChannel("sftp")
				c.connect()
				self.logger.info('Connected to TW Server: ' + tw_server)
			except Exception as e:
				self.logger.info('Failed to Connect to TW Server: ' + tw_server)
				raise

			if tw_src_file_pattern_prefix != "":
				tw_src_file_pattern = tw_src_file_pattern_prefix + "_" + tw_src_file_pattern
				self.logger.info('Updated TW FTP Source File Name Pattern is: ' + tw_src_file_pattern)

			tw_file_list = []
			self.logger.info('Scanning TW FTP Server in Directory: ' + tw_src_dir + ' for File Pattern: ' + tw_src_file_pattern)
			files = c.ls(tw_src_dir)
			for f in files:
				if re.match(re.compile(tw_src_file_pattern + "$"),f.getFilename()) != None:
					src_file_nm = f.getFilename()
					if src_file_nm.split('_')[0] == "PROD":
						tgt_file_nm = "_".join(["PRD"] + src_file_nm.split('_')[1:])
						c.rename(tw_src_dir + src_file_nm,tw_src_dir + tgt_file_nm)
						tw_file_list.append(tgt_file_nm)
					else:
						tgt_file_nm = src_file_nm
						tw_file_list.append(tgt_file_nm)

			self.logger.info('Scanning Done')

			if len(tw_file_list) == 0:
				self.logger.info('The Nasco Files were Not found on TW FTP Server with Pattern: ' + tw_src_file_pattern)
				mu.send_mail(self.job_nm,self.from_mail,self.support_mail_list, \
					self.env.upper() + " : " + "FAILED" + " - " + "Pyspark Job " + job_type + self.job_nm + " Did Not Received a File On TW", \
					"Pyspark Job " + job_type + self.job_nm + " Did Not Received the following NASCO File On TW FTP Server: " + tw_src_file_pattern)
			else:
				self.logger.info('The Nasco Following Files were found on TW FTP Server: ' + ",".join(tw_file_list))

			self.logger.info('Disconnecting From TW Server: ' + tw_server)
			c.exit()
			s.disconnect()
			self.logger.info('Disconnected From TW Server: ' + tw_server)

			self.logger.info('Appsimp Audit logs table will be updated with SUCCESS Status')
			au.set_success(self.spark,self.env,self.job_nm,self.host_nm,self.yarn_app_id,self.start_time,"",self.log_file,self.dmn)
			self.end_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
			self.logger.info('Job End Time is: ' + self.end_time)
			self.logger.info('Finished Executing the Job: ' + self.job_nm)
		except Exception as e:
			self.logger.info('Appsimp Audit logs table will be updated with FAILED Status')
			au.set_failed(self.spark,self.env,self.job_nm,self.host_nm,self.yarn_app_id,self.start_time,"",self.log_file,self.dmn)
			raise

def main(spark,**args):
	logger = spark.sparkContext._jvm.org.apache.log4j.LogManager.getLogger(__name__)
	obj =  dlap_appsimp_sas_check_tw_file(spark,args)
	logger.info("Successfully Initialized the Pyspark Job: " + spark.sparkContext.appName)
	try:
		obj.run()
	except Exception as e:
		raise
