"""dlap_appsimp_sas_schema_onboarding.py: This Program Reads the Schema Details from the Schema Json File and Create the Hive Table and HDFS Directory"""

__author__      = "Amar Kashyap"
__copyright__   = "Copyright 2019, This Code is Developed for BCBSMA by IBM Under Appsimp Program - SAS Mainframe to DLAP Migration"
__credits__     = ["Rakesh Munigala", "Sai Sunil Vanam"]
__version__     = "1.0"
__maintainer__  = "Amar Kashyap"
__email__       = "amar.kashyap@bcbsma.com, amakashy@in.ibm.com"

import os,sys,shutil,json,traceback,argparse,socket,time
from datetime import datetime

from py4j.java_gateway import java_import
from pyspark.sql import SparkSession
from pyspark.sql.types import *
from pyspark.sql.functions import *

from shared import dlap_appsimp_sas_mail_util as mu
from shared import dlap_appsimp_sas_audit_update as au
from shared import dlap_appsimp_sas_configs as cfg

class dlap_appsimp_sas_schema_onboarding:
	def __init__(self,spark,args):
		java_import(spark._jvm, 'org.apache.hadoop.fs.Path')
		self.spark = spark
		self.env = args['env']
		self.dmn = args['dmn']
		self.temp_dir = args['temp_dir']
		self.args = args
		self.job_nm = spark.sparkContext.appName
		self.yarn_app_id = spark.sparkContext.applicationId
		self.start_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
		self.job_run_time = datetime.today().strftime('%Y-%m-%d-%H-%M-%S')
		self.host_nm = socket.getfqdn()
		self.from_mail = spark.sparkContext.sparkUser()
		self.log_file = args['log_file']
		self.logger = spark.sparkContext._jvm.org.apache.log4j.LogManager.getLogger(__name__)
	def get_columns(self,schema_list,partition_list):
		import operator
		schema_list = sorted(schema_list, key=lambda k: k["metadata"]["id"])
		column_fields = []
		partition_fields = []
		for col in schema_list:
			if col['type'] == "STRING":
				if col['name'] in partition_list:
					partition_fields.append(col['name'] + " string")
				else:
                                	column_fields.append(col['name'] + "    string")
			elif col['type'] == "INTEGER":
				if col['name'] in partition_list:
					partition_fields.append(col['name'] + " int")
				else:
					column_fields.append(col['name'] + "    int")
			elif col['type'] == "LONG":
				if col['name'] in partition_list:
					partition_fields.append(col['name'] + " bigint")
				else:
					column_fields.append(col['name'] + "    bigint")
			elif col['type'] == "DOUBLE":
				if col['name'] in partition_list:
					partition_fields.append(col['name'] + " double")
				else:
					column_fields.append(col['name'] + "    double")
			elif col['type'] == "TIMESTAMP":
				if col['name'] in partition_list:
					partition_fields.append(col['name'] + " timestamp")
				else:
					column_fields.append(col['name'] + "    timestamp")
		return (",".join(column_fields),",".join(partition_fields))
	def run(self):
		self.logger.info('Started Running the Job: ' + self.job_nm)
		self.logger.info('Job is Running in Region: ' + self.env)
		self.logger.info('Job is Running for Domain: ' + self.dmn)
		self.logger.info('Job is Running on Hostname: ' + self.host_nm)
		self.logger.info('Job is using Temp Directory: ' + self.temp_dir)
		self.logger.info('Job Start Time: ' + self.start_time)
		self.logger.info('Job Yarn Application Id is: ' + self.yarn_app_id)
		self.logger.info('Job Log File Name is: ' + self.log_file)
		self.logger.info('Started Setting Job Level SparkConf')
		self.spark.conf.set("spark.sql.crossJoin.enabled", "true")
		self.spark.conf.set("spark.sql.shuffle.partitions", "4")
		self.spark.conf.set("hive.exec.dynamic.partition", "true")
		self.spark.conf.set("hive.exec.dynamic.partition.mode", "nonstrict")
		self.logger.info('Finished Setting Job Level SparkConf')
		
		try:
			self.logger.info('Started Reading Job Configurations from Config Table')
			config = cfg.get_config(self.spark,self.env,self.job_nm)
			self.logger.info('Job Configurations Read from Config Table are: ' + json.dumps(config))
			src_schema_hdfs_dir = "/" + self.env + config['onboarding_hdfs_dir']
			tgt_schema_hdfs_dir = "/" + self.env + config['schema_hdfs_dir']
			self.logger.info('Successfully Read Job Configurations from Config Table')

			self.logger.info('Source Schema HDFS Dir is: ' + src_schema_hdfs_dir)
			self.logger.info('Target Schema HDFS Dir is: ' + tgt_schema_hdfs_dir)

			self.logger.info('Scanning Schema Files in Schema HDFS Directory')
			fs = self.spark._jvm.org.apache.hadoop.fs.FileSystem.get(self.spark._jsc.hadoopConfiguration())
			input_trigger_list = fs.globStatus(self.spark.sparkContext._jvm.Path(src_schema_hdfs_dir + "schema_*.json"))
			self.logger.info('Schema File Founded is: ' + str(len(input_trigger_list)))
			self.logger.info('Started Processing Schema File One by One')

			self.logger.info('Connecting to HiveServer2 using JDBC')
			java_import(self.spark._jvm, 'org.apache.hive.jdbc.HiveDriver')
			driver = self.spark.sparkContext._jvm.HiveDriver()
			hive2_jdbc_url = self.args['hive2_jdbc_url']
			hive2_jdbc_principal = self.args['hive2_jdbc_principal']
			hive2_jdbc_ssl = self.args['hive2_jdbc_ssl']
			hive2_jdbc_connect_url = hive2_jdbc_url +";principal="+ hive2_jdbc_principal + ";ssl=" + hive2_jdbc_ssl + ";"
			self.logger.info('Hive2 JDBC CONNECT URL is ' + hive2_jdbc_connect_url)
			conn = driver.connect(hive2_jdbc_connect_url,self.spark.sparkContext._jvm.java.util.Properties())
			stmt = conn.createStatement()
			self.logger.info('Successfully Connected to HiveServer2 using JDBC')

			for trigger_file in input_trigger_list:
				schema_file_nm = trigger_file.getPath().getName()
				self.logger.info('Processing Schema File Name is: ' + schema_file_nm)

				self.logger.info('Started Reading the Schema File')
				jsonSchema_0 = self.spark.read.text(src_schema_hdfs_dir + schema_file_nm)
				jsonSchema = jsonSchema_0.rdd.map(lambda l: (1,l.value)).groupByKey().map(lambda l: "".join(list(l[1]))).collect()
				dataset = json.loads(jsonSchema[0])
				curate_table_name = dataset["name"]
				curate_db_name = self.env + "_curate_" + dataset["business_domain"]
				curate_hdfs_dir = "/" + self.env + "/curate/" + dataset["business_domain"] + "/" + dataset["name"]
				raw_hdfs_dir = "/" + self.env + "/raw/" + dataset["business_domain"] + "/" + dataset["source_system_code"] + "/" + dataset["name"]
				partition_keys_list = dataset["partition_keys"]
				raw_schema_list = dataset["raw_schema"]
				curate_schema_list = dataset["curate_schema"]
				self.logger.info('Successfully Read the Schema File')

				self.logger.info('Curate DB Name is ' + curate_db_name)
				self.logger.info('Curate Table Name is ' + curate_table_name)
				self.logger.info('Curate HDFS Directory is ' + curate_hdfs_dir)
				self.logger.info('Raw HDFS Directory is ' + raw_hdfs_dir)
				self.logger.info('Curate DB Name is ' + curate_db_name)

				self.logger.info('Get Curate Columns and Partitioning Columns')
				curate_columns,partition_columns = self.get_columns(curate_schema_list,partition_keys_list)
				self.logger.info('Successfully Got Curate Columns and Partitioning Columns')
				self.logger.info('Curate Table Columns are ' + curate_columns)
				self.logger.info('Curate Table Partitioning Columns are ' + partition_columns)

				self.logger.info('Dropping Table If Exists')
				dropQuery = """DROP TABLE IF EXISTS {0}.{1}""".format(curate_db_name,curate_table_name)
				self.logger.info('Drop Query is: ' + dropQuery)
				result = stmt.execute(dropQuery)
				self.logger.info('Table Dropped Successfully')

				self.logger.info('Creating Table')
				createQuery = """
					CREATE EXTERNAL TABLE {0}.{1}
					(
						{2}
					)
					PARTITIONED BY ({3})
					STORED AS PARQUET
					LOCATION '{4}'
					TBLPROPERTIES('spark.sql.partitionProvider'='catalog')
					""".format(curate_db_name,curate_table_name,curate_columns,partition_columns,curate_hdfs_dir)

				self.logger.info('Create Query is: ' + createQuery)
				result = stmt.execute(createQuery)
				self.logger.info('Table Created Successfully')

				self.logger.info('Altering Table')
				alterQuery = """MSCK REPAIR TABLE {0}.{1}""".format(curate_db_name,curate_table_name)
				self.logger.info('Alter Query is: ' + alterQuery)
				result = stmt.execute(alterQuery)
				self.logger.info('Table Altered Successfully')

				self.logger.info('Creating Raw HDFS Directory: ' + raw_hdfs_dir)
				if fs.exists(self.spark.sparkContext._jvm.Path(raw_hdfs_dir)):
					self.logger.info('Raw HDFS Directory Already Exists')
					self.logger.info('Raw HDFS Directory will not be created')
				else:
					fs.mkdirs(self.spark.sparkContext._jvm.Path(raw_hdfs_dir))
					self.logger.info('Successfully Created Raw HDFS Directory')

				self.logger.info('Moving Schema File to Target Schema Dir: ' + tgt_schema_hdfs_dir)
				if fs.exists(self.spark.sparkContext._jvm.Path(tgt_schema_hdfs_dir + schema_file_nm)):
					fs.rename(
					self.spark.sparkContext._jvm.Path(tgt_schema_hdfs_dir + schema_file_nm),
					self.spark.sparkContext._jvm.Path(tgt_schema_hdfs_dir + schema_file_nm + "_" +datetime.today().strftime('%Y%m%d%H%M%S')))
					self.logger.info('Backed Up Older Schema File in Target Schema Directory')
				
				fs.rename(
					self.spark.sparkContext._jvm.Path(src_schema_hdfs_dir + schema_file_nm),
					self.spark.sparkContext._jvm.Path(tgt_schema_hdfs_dir + schema_file_nm))
				self.logger.info('Successfully Moved Schema File to Target Schema HDFS Directory')

			self.logger.info('Closing Connection to HiveServer2')
			conn.close()
			self.logger.info('Successfully Closed Connection to HiveServer2')
			self.logger.info('Appsimp Audit logs table will be updated with SUCCESS Status')
			au.set_success(self.spark,self.env,self.job_nm,self.host_nm,self.yarn_app_id,self.start_time,"",self.log_file,self.dmn)
			self.end_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
			self.logger.info('Job End Time is: ' + self.end_time)
			self.logger.info('Finished Executing the Job: ' + self.job_nm)
		except Exception as e:
			self.logger.info('Appsimp Audit logs table will be updated with FAILED Status')
			au.set_failed(self.spark,self.env,self.job_nm,self.host_nm,self.yarn_app_id,self.start_time,"",self.log_file,self.dmn)
			raise

def main(spark,**args):
	logger = spark.sparkContext._jvm.org.apache.log4j.LogManager.getLogger(__name__)
	obj =  dlap_appsimp_sas_schema_onboarding(spark,args)
	logger.info("Successfully Initialized the Pyspark Job: " + spark.sparkContext.appName)
	try:
		obj.run()
	except Exception as e:
		raise
