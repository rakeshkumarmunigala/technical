"""dlap_appsimp_sas_remove_success_file.py:Program Checks if Nasco File are Available on TW FTP Server for Ingestion into DLAP"""

__author__      = "Amar Kashyap"
__copyright__   = "Copyright 2019, This Code is Developed for BCBSMA by IBM Under Appsimp Program - SAS Mainframe to DLAP Migration"
__credits__     = ["Ramu Nair", "Rakesh Munigala", "Sai Sunil Vanam"]
__version__     = "1.0"
__maintainer__  = "Amar Kashyap"
__email__       = "amar.kashyap@bcbsma.com, amakashy@in.ibm.com"

import os,sys,shutil,json,traceback,argparse,socket,time
from datetime import datetime
from enum import Enum
import re

from pyspark.sql import SparkSession
from pyspark.sql.types import *
from pyspark.sql.functions import *
from py4j.java_gateway import java_import

from shared import dlap_appsimp_sas_mail_util as mu
from shared import dlap_appsimp_sas_audit_update as au
from shared import dlap_appsimp_sas_configs as cfg

class TWFileSearchTriggerError(Exception):
	def __init__(self, value):
		self.value = value
	def __str__(self):
		return(repr(self.value))

class TWAuthValidationError(Exception): 
	def __init__(self, value): 
		self.value = value 
	def __str__(self): 
		return(repr(self.value))

class FileNotFoundError(Exception):
	def __init__(self, value):
		self.value = value	
	def __str__(self):
		return(repr(self.value))

class dlap_appsimp_sas_remove_success_file:
	def __init__(self,spark,args):
		java_import(spark._jvm, 'org.apache.hadoop.fs.Path')
		self.spark = spark
		self.env = args['env']
		self.dmn = args['dmn']
		self.temp_dir = args['temp_dir']
		self.args = args
		self.job_nm = spark.sparkContext.appName
		self.yarn_app_id = spark.sparkContext.applicationId
		self.start_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
		self.job_run_time = datetime.today().strftime('%Y-%m-%d-%H-%M-%S')
		self.host_nm = socket.getfqdn()
		self.from_mail = spark.sparkContext.sparkUser()
		self.support_mail_list = args['support_mail_list'].split(',')
		self.log_file = args['log_file']
		self.logger = spark.sparkContext._jvm.org.apache.log4j.LogManager.getLogger(__name__)
	def run(self):
		tw_id_file = None
		tw_password = None
		tw_tgt_file_nm = None
		self.logger.info('Started Running the Job: ' + self.job_nm)
		self.logger.info('Job is Running in Region: ' + self.env)
		self.logger.info('Job is Running for Domain: ' + self.dmn)
		self.logger.info('Job is Running on Hostname: ' + self.host_nm)
		self.logger.info('Job is using Temp Directory: ' + self.temp_dir)
		self.logger.info('Job Start Time: ' + self.start_time)
		self.logger.info('Job Yarn Application Id is: ' + self.yarn_app_id)
		self.logger.info('Job Log File Name is: ' + self.log_file)
		self.logger.info('Started Setting Job Level SparkConf')
		self.spark.conf.set("spark.sql.crossJoin.enabled", "true")
		self.spark.conf.set("spark.sql.shuffle.partitions", "4")
		self.spark.conf.set("hive.exec.dynamic.partition", "true")
		self.spark.conf.set("hive.exec.dynamic.partition.mode", "nonstrict")
		self.logger.info('Finished Setting Job Level SparkConf')

		try:
			
					
			success_file_nm = self.args["success_file_nm"]
			self.logger.info('Success File Name is: ' + success_file_nm)

			ingestion_success_file_path = self.args["ingestion_success_hdfs_dir"] + success_file_nm
			self.logger.info('Ingestion Success File is: ' + ingestion_success_file_path)
			
			syncsort_success_file_path = self.args["syncsort_success_hdfs_dir"] + success_file_nm
			self.logger.info('Syncsort Success File is: ' + syncsort_success_file_path)
			
			fs = self.spark._jvm.org.apache.hadoop.fs.FileSystem.get(self.spark._jsc.hadoopConfiguration())
			ingestion_status = fs.globStatus(self.spark.sparkContext._jvm.Path(ingestion_success_file_path))
					
			for fileStatus in ingestion_status:
				files=fileStatus.getPath()
				self.logger.info('Ingestion Success files present for removal are:' +str(files))
				fs.delete(fileStatus.getPath())
				
			self.logger.info(' Ingestion Success File Deleted Successfully')			
				
			fs = self.spark._jvm.org.apache.hadoop.fs.FileSystem.get(self.spark._jsc.hadoopConfiguration())
			syncsort_status = fs.globStatus(self.spark.sparkContext._jvm.Path(syncsort_success_file_path))
									
			for fileStatus in syncsort_status:
				files=fileStatus.getPath()
				self.logger.info('Syncsort Success files present for removal are:' +str(files))
				fs.delete(fileStatus.getPath())
				
			self.logger.info('The Syncsort Success File Deleted Successfully')			
			
			self.logger.info('Appsimp Audit logs table will be updated with SUCCESS Status')
			au.set_success(self.spark,self.env,self.job_nm,self.host_nm,self.yarn_app_id,self.start_time,"",self.log_file,self.dmn)
			self.end_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
			self.logger.info('Job End Time is: ' + self.end_time)
			self.logger.info('Finished Executing the Job: ' + self.job_nm)
		except Exception as e:
			self.logger.info('Appsimp Audit logs table will be updated with FAILED Status')
			au.set_failed(self.spark,self.env,self.job_nm,self.host_nm,self.yarn_app_id,self.start_time,"",self.log_file,self.dmn)
			raise

def main(spark,**args):
	logger = spark.sparkContext._jvm.org.apache.log4j.LogManager.getLogger(__name__)
	obj =  dlap_appsimp_sas_remove_success_file(spark,args)
	logger.info("Successfully Initialized the Pyspark Job: " + spark.sparkContext.appName)
	try:
		obj.run()
	except Exception as e:
		raise
