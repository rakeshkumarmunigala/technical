"""dlap_appsimp_sas_nasco_bank_file_ingestion.py: This Program Reads the Data from Source File and Ingest the Data into Hive Curate Table"""

__author__      = "Amar Kashyap"
__copyright__   = "Copyright 2019, This Code is Developed for BCBSMA by IBM Under Appsimp Program - SAS Mainframe to DLAP Migration"
__credits__     = ["Ramu Nair", "Rakesh Munigala", "Sai Sunil Vanam"]
__version__     = "1.0"
__maintainer__  = "Amar Kashyap"
__email__       = "amar.kashyap@bcbsma.com, amakashy@in.ibm.com"

import os,sys,shutil,json,traceback,argparse,socket,time
from datetime import datetime
from dateutil.relativedelta import *
from enum import Enum

from pyspark.sql import SparkSession
from pyspark.sql.types import *
from pyspark.sql.functions import *
from py4j.java_gateway import java_import

from shared import dlap_appsimp_sas_mail_util as mu
from shared import dlap_appsimp_sas_audit_update as au
from shared import dlap_appsimp_sas_configs as cfg

class DataValidationError(Exception): 
	def __init__(self, value): 
		self.value = value 
	def __str__(self): 
		return(repr(self.value))

class dlap_appsimp_sas_nasco_bank_file_ingestion:
	def __init__(self,spark,args):
		java_import(spark._jvm, 'org.apache.hadoop.fs.Path')
		self.spark = spark
		self.env = args['env']
		self.dmn = args['dmn']
		self.temp_dir = args['temp_dir']
		self.args = args
		self.job_nm = spark.sparkContext.appName
		self.yarn_app_id = spark.sparkContext.applicationId
		self.start_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
		self.job_run_time = datetime.today().strftime('%Y-%m-%d-%H-%M-%S')
		self.host_nm = socket.getfqdn()
		self.hdfs_output_file = None 
		self.from_mail = spark.sparkContext.sparkUser()
		self.log_file = args['log_file']
		self.logger = spark.sparkContext._jvm.org.apache.log4j.LogManager.getLogger(__name__)
	def get_schema(self,schema_list,all_string = False):
		import operator
		schema_list = sorted(schema_list, key=lambda k: k["metadata"]["id"])
		schema_fields = []
		for col in schema_list:
			if all_string:
				schema_fields.append(StructField(col['name'], StringType(), True))
			else:
				if col['type'] == "STRING":
					schema_fields.append(StructField(col['name'], StringType(), True))
				elif col['type'] in ["INTEGER"]:
					schema_fields.append(StructField(col['name'], IntegerType(), True))
				elif col['type'] in ["LONG"]:
					schema_fields.append(StructField(col['name'], LongType(), True))
				elif col['type'] in ["DOUBLE"]:
					schema_fields.append(StructField(col['name'], DoubleType(), True))
				elif col['type'] == "TIMESTAMP":
					schema_fields.append(StructField(col['name'], DateType(), True))
		return StructType(schema_fields)
	def get_date_mapAndTrsformQuery(self,raw_schema_enum,curate_schema_enum,ingest_file_nm):
		mapAndTrsformQuery = """
			{0.control_plan_number.name} as {1.cntrl_pln_num.name},
			{0.customer_plan_number.name} as {1.cust_pln_num.name},
			{0.check_account_id.name} as {1.chk_acct_id.name},
			{0.key_field.name} as {1.key_fld.name},
			{0.run_date_jul.name} as {1.run_dt_jul.name},
			{0.post_date_jul.name} as {1.post_dt_jul.name},
			{0.current_account_per.name} as {1.curr_acct_per.name},
			{0.current_account_per_x.name} as {1.curr_acct_per_x.name},
			{0.current_account_year.name} as {1.curr_acct_yr.name},
			{0.current_account_month.name} as {1.curr_acct_mnth.name},
			{0.rev_run.name} as {1.rev_run.name},
			{0.phase.name} as {1.phase.name},
			{0.close_cycle.name} as {1.close_cycle.name},
			{0.keytapes.name} as {1.keytapes.name},
			{0.claim_dispos_std.name} as {1.clm_dispos_std.name},
			{0.claim_dispos_cal.name} as {1.clm_dispos_cal.name},
			{0.claim_nat.name} as {1.clm_nat.name},
			{0.claim_new_std.name} as {1.clm_new_std.name},
			{0.claim_new_cal.name} as {1.clm_new_cal.name},
			{0.bofa.name} as {1.bofa.name},
			{0.wf.name} as {1.wf.name},
			{0.bsom.name} as {1.bsom.name},
			{0.ipdr.name} as {1.ipdr.name},
			{0.lockbox.name} as {1.lockbox.name},
			{0.pers_active.name} as {1.pers_actv.name},
			{0.pers_retire.name} as {1.pers_retire.name},
			{0.mc_auto_ar.name} as {1.mc_auto_ar.name},
			{0.pers_date.name} as {1.pers_dt.name},
			{0.nat_disallows.name} as {1.nat_disallows.name},
			{0.bill_indicator.name} as {1.bill_ind.name},
			{0.claim_1099_lob.name} as {1.clm_1099_lob.name},
			{0.customer_number.name} as {1.cust_num.name},
			{0.customer_name.name} as {1.cust_nm.name},
			{0.last_workday_sw.name} as {1.lst_workday_sw.name},
			{0.first_workday_sw.name} as {1.frst_workday_sw.name},
			{0.month_end_sw.name} as {1.mnth_end_sw.name},
			{0.run_date.name} as {1.run_dt.name},
			{0.run_date_month.name} as {1.run_dt_mnth.name},
			{0.post_date.name} as {1.post_dt.name},
			{0.post_date_month.name} as {1.post_dt_mnth.name},
			{0.current_start_date.name} as {1.curr_start_dt.name},
			{0.current_end_date.name} as {1.curr_end_dt.name},
			{0.current_year_month.name} as {1.curr_yr_mnth.name},
			{0.current_pers_date.name} as {1.curr_pers_dt.name},
			CASE
				WHEN trim({0.time_of_day.name}) = ''
					THEN null
				ELSE trim({0.time_of_day.name})
			END as {1.time_of_day.name},
			{0.day_of_week.name} as {1.day_of_week.name},
			cast
			(
				from_unixtime(unix_timestamp({0.run_date_standard.name},'yyyyMMdd') ,'yyyy-MM-dd') as timestamp
			) as {1.run_dt_stdrd.name},
			cast
			(
				from_unixtime(unix_timestamp({0.post_date_standard.name},'yyyyMMdd') ,'yyyy-MM-dd') as timestamp
			) as {1.post_dt_stdrd.name},
			cast
			(
				from_unixtime(unix_timestamp({0.current_start_date_standard.name},'yyyyMMdd') ,'yyyy-MM-dd') as timestamp
			) as {1.curr_start_dt_stdrd.name},
			cast
			(
				from_unixtime(unix_timestamp({0.current_end_date_standard.name},'yyyyMMdd') ,'yyyy-MM-dd') as timestamp
			) as {1.curr_end_dt_stdrd.name},
			{0.current_account_per_standard.name} as {1.curr_acct_per_stdrd.name},
			{0.current_century_year.name} as {1.curr_cntury_yr.name},
			'{2}' as {1.file_nm.name},
			current_timestamp() as {1.load_timestamp.name},
			split('{2}','_')[2] as {1.feed_cycle.name},
			substr(split('{2}','_')[6],1,8) as {1.feed_dt.name}
			""".format(raw_schema_enum,curate_schema_enum,ingest_file_nm)
		return mapAndTrsformQuery
	def get_check_mapAndTrsformQuery(self,raw_schema_enum,curate_schema_enum,ingest_file_nm):
		mapAndTrsformQuery = """
			{0.control_plan_number.name} as {1.cntrl_pln_num.name},
			{0.customer_plan_number.name} as {1.cust_pln_num.name},
			{0.check_account_id.name} as {1.chk_acct_id.name},
			{0.micr_number.name} as {1.micr_num.name},
			{0.int_check_number.name} as {1.int_chk_num.name},
			{0.issue_date.name} as {1.issue_dt.name},
			{0.check_status.name} as {1.chk_stat.name},
			{0.status_date.name} as {1.stat_dt.name},
			{0.je_date.name} as {1.je_dt.name},
			{0.total_amount.name} as {1.tot_amt.name},
			{0.claim_amount.name} as {1.clm_amt.name},
			{0.total_int.name} as {1.tot_int.name},
			{0.group_superset_code.name} as {1.grp_superset_cd.name},
			{0.group_groupset_code.name} as {1.grp_groupset_cd.name},
			{0.group_service_plan_code.name} as {1.grp_svc_pln_cd.name},
			{0.group_fund_plan_code.name} as {1.grp_fund_pln_cd.name},
			{0.subscriber_plan_number.name} as {1.sub_pln_num.name},
			{0.member_number.name} as {1.mem_num.name},
			{0.provider_plan_code.name} as {1.prov_pln_cd.name},
			{0.provider_lob.name} as {1.prov_lob.name},
			{0.provider_number.name} as {1.prov_num.name},
			{0.je_code.name} as {1.je_cd.name},
			{0.claim_1099_indicator.name} as {1.clm_1099_ind.name},
			{0.payee_check_type.name} as {1.payee_chk_cd.name},
			{0.pay_assign_code.name} as {1.pay_assgn_cd.name},
			{0.hmo_indicator.name} as {1.hmo_ind.name},
			{0.backup_withhold_percent.name} as {1.bkup_whld_pct.name},
			{0.trigger_flag.name} as {1.trgr_flag.name},
			CASE
				WHEN trim({0.customer_name.name}) = ''
					THEN null
				ELSE trim({0.customer_name.name})
			END as {1.cust_nm.name},
			{0.provider_npi.name} as {1.prov_npi.name},
			{0.report_183_sw.name} as {1.rprt_183_sw.name},
			{0.report_183_date.name} as {1.rprt_183_dt.name},
			{0.report_hold_check_status.name} as {1.rprt_hld_chk_stats.name},
			{0.report_hold_check_date.name} as {1.rprt_hld_chk_dt.name},
			{0.gl_status_reported.name} as {1.gl_stat_rprt.name},
			{0.number_of_segment.name} as {1.num_of_seg.name},
			CASE
				WHEN length({0.issue_date.name}) between 3 and 6
					THEN cast(from_unixtime(unix_timestamp(lpad({0.issue_date.name},6,'0'),'yyMMdd') ,'yyyy-MM-dd') as timestamp)
				ELSE null
			END as {1.issue_dt_trsform.name},
			CASE
				WHEN length({0.status_date.name}) between 3 and 6
					THEN cast(from_unixtime(unix_timestamp(lpad({0.status_date.name},6,'0'),'yyMMdd') ,'yyyy-MM-dd') as timestamp)
				ELSE null
			END as {1.stat_dt_trsform.name},
			CASE
				WHEN length({0.je_date.name}) between 3 and 6
					THEN cast(from_unixtime(unix_timestamp(lpad({0.je_date.name},6,'0'),'yyMMdd') ,'yyyy-MM-dd') as timestamp)
				ELSE null
			END as {1.je_dt_trsform.name},
			CASE
				WHEN length({0.report_183_date.name}) between 3 and 6
					THEN cast(from_unixtime(unix_timestamp(lpad({0.report_183_date.name},6,'0'),'yyMMdd') ,'yyyy-MM-dd') as timestamp)
				ELSE null
			END as {1.rprt_183_dt_trsform.name},
			CASE
				WHEN length({0.report_hold_check_date.name}) between 3 and 6
					THEN cast(from_unixtime(unix_timestamp(lpad({0.report_hold_check_date.name},6,'0'),'yyMMdd') ,'yyyy-MM-dd') as timestamp)
				ELSE null
			END as {1.rprt_hld_chk_dt_trsform.name},
			'{2}' as {1.file_nm.name},
			current_timestamp() as {1.load_timestamp.name},
			split('{2}','_')[2] as {1.feed_cycle.name},
			substr(split('{2}','_')[6],1,8) as {1.feed_dt.name}
			""".format(raw_schema_enum,curate_schema_enum,ingest_file_nm)
		return mapAndTrsformQuery
	def get_stdrd_mapAndTrsformQuery(self,raw_schema_enum,curate_schema_enum,ingest_file_nm):
		mapAndTrsformQuery = """
			{0.control_plan_number.name} as {1.cntrl_pln_num.name},
			{0.customer_plan_number.name} as {1.cust_pln_num.name},
			{0.check_account_id.name} as {1.chk_acct_id.name},
			{0.micr_number.name} as {1.micr_num.name},
			{0.segment_id.name} as {1.seg_id.name},
			{0.subscriber_plan.name} as {1.sub_pln.name},
			{0.member_number.name} as {1.mem_num.name},
			{0.action_plan.name} as {1.actn_pln.name},
			{0.claim_number.name} as {1.clm_num.name},
			{0.pay_amount.name} as {1.pay_amt.name},
			{0.type.name} as {1.typ.name},
			{0.disposition_code.name} as {1.dispos_cd.name},
			{0.interest_flag.name} as {1.int_flag.name},
			{0.stop_pay_indicator.name} as {1.stop_pay_ind.name},
			{0.group_owner_plan.name} as {1.grp_own_pln.name},
			{0.group_superset_code.name} as {1.grp_superset_cd.name},
			{0.group_groupset_code.name} as {1.grp_groupset_cd.name},
			{0.group_service_plan_code.name} as {1.grp_svc_pln_cd.name},
			{0.group_fund_plan_code.name} as {1.grp_fund_pln_cd.name},
			'{2}' as {1.file_nm.name},
			current_timestamp() as {1.load_timestamp.name},
			split('{2}','_')[2] as {1.feed_cycle.name},
			substr(split('{2}','_')[6],1,8) as {1.feed_dt.name}
			""".format(raw_schema_enum,curate_schema_enum,ingest_file_nm)
		return mapAndTrsformQuery
	def get_recoup_mapAndTrsformQuery(self,raw_schema_enum,curate_schema_enum,ingest_file_nm):
		mapAndTrsformQuery = """
			{0.control_plan_number.name} as {1.cntrl_pln_num.name},
			{0.customer_plan_number.name} as {1.cust_pln_num.name},
			{0.check_account_id.name} as {1.chk_acct_id.name},
			{0.micr_number.name} as {1.micr_num.name},
			{0.segment_id.name} as {1.seg_id.name},
			{0.ar_control_number.name} as {1.ar_cntrl_num.name},
			{0.amount_applied.name} as {1.amt_apld.name},
			{0.ar_type.name} as {1.ar_typ.name},
			{0.setup_date.name} as {1.setup_dt.name},
			{0.reason_code.name} as {1.rsn_cd.name},
			{0.disposition_date.name} as {1.dispos_dt.name},
			{0.disposition_code.name} as {1.dispos_cd.name},
			{0.interest_flag.name} as {1.int_flag.name},
			{0.group_owner_plan.name} as {1.grp_own_pln.name},
			{0.group_superset_code.name} as {1.grp_superset_cd.name},
			{0.group_groupset_code.name} as {1.grp_groupset_cd.name},
			{0.group_service_plan_code.name} as {1.grp_svc_pln_cd.name},
			{0.group_fund_plan_code.name} as {1.grp_fund_pln_cd.name},
			CASE
				WHEN length({0.setup_date.name}) between 3 and 6
					THEN cast(from_unixtime(unix_timestamp(lpad({0.setup_date.name},6,'0'),'yyMMdd') ,'yyyy-MM-dd') as timestamp)
				ELSE null
			END as {1.setup_dt_trsform.name},
			CASE
				WHEN trim({0.disposition_date.name}) = ''
					THEN null
				ELSE trim({0.disposition_date.name})
			END as {1.dispos_dt_trsform.name},
			'{2}' as {1.file_nm.name},
			current_timestamp() as {1.load_timestamp.name},
			split('{2}','_')[2] as {1.feed_cycle.name},
			substr(split('{2}','_')[6],1,8) as {1.feed_dt.name}
			""".format(raw_schema_enum,curate_schema_enum,ingest_file_nm)
		return mapAndTrsformQuery
	def run(self):
		input_trigger_list = None
		ingest_status = None
		self.logger.info('Started Running the Job: ' + self.job_nm)
		self.logger.info('Job is Running in Region: ' + self.env)
		self.logger.info('Job is Running for Domain: ' + self.dmn)
		self.logger.info('Job is Running on Hostname: ' + self.host_nm)
		self.logger.info('Job is using Temp Directory: ' + self.temp_dir)
		self.logger.info('Job Start Time: ' + self.start_time)
		self.logger.info('Job Yarn Application Id is: ' + self.yarn_app_id)
		self.logger.info('Job Log File Name is: ' + self.log_file)
		self.logger.info('Started Setting Job Level SparkConf')
		self.spark.conf.set("spark.sql.crossJoin.enabled", "true")
		self.spark.conf.set("spark.sql.shuffle.partitions", "4")
		self.spark.conf.set("hive.exec.dynamic.partition", "true")
		self.spark.conf.set("hive.exec.dynamic.partition.mode", "nonstrict")
		self.logger.info('Finished Setting Job Level SparkConf')

		self.logger.info('Defining Data Validation Function')
		def data_validation(row,schema,zone):
			not_valid = []
			for i in range(len(schema.fields)-1):
				field = schema.fields[i]
				if zone == "raw":
					try:
						if str(field.dataType) == "StringType":
							data_type = "String"
							str(row[i])
						elif str(field.dataType) in ["IntegerType","LongType"]:
							data_type = "Integer"
							int(row[i])
						elif str(field.dataType) == "DoubleType":
							data_type = "Double"
							float(row[i])
					except Exception as e:
						not_valid.append(field.name + " : Expected " + data_type)
				elif zone == "curate":
					if str(field.dataType) == "StringType" and row[i] != None and not isinstance(row[i],str):
						not_valid.append(field.name + " : Expected String")
					elif str(field.dataType) in ["IntegerType","LongType"] and row[i] != None and not isinstance(row[i],int):
						not_valid.append(field.name + " : Expected Integer")
					elif str(field.dataType) == "DoubleType" and row[i] != None and not isinstance(row[i],float):
						not_valid.append(field.name + " : Expected Double")
			if len(not_valid) > 0:
				return (row,"isNotValid",not_valid)
			else:
				return (row,"isValid",not_valid)
		self.logger.info('Defined Data Validation Function')
		
		try:
			feed_cycle = self.args['feed_cycle']
			self.logger.info('Feed Cycle is: ' + feed_cycle)

			success_file_nm = self.args["success_file_nm"]
			self.logger.info('Success File Name is: ' + success_file_nm)

			ingestion_success_file_path = self.args["ingestion_success_hdfs_dir"] + success_file_nm
			self.logger.info('Ingestion Success File is: ' + ingestion_success_file_path)

			self.logger.info('Started Reading Job Configurations from Config Table')
			config = cfg.get_config(self.spark,self.env,self.job_nm)
			self.logger.info('Job Configurations Read from Config Table are: ' + json.dumps(config))
			staging_hdfs_dir = "/" + self.env + config["staging_hdfs_dir"]
			error_hdfs_dir = "/" + self.env + config["error_hdfs_dir"]
			schema_hdfs_dir = "/" + self.env + config["schema_hdfs_dir"]
			self.logger.info('Successfully Read Job Configurations from Config Table')

			self.logger.info('Staging HDFS Dir is: ' + staging_hdfs_dir)
			self.logger.info('Error HDFS Dir is: ' + error_hdfs_dir)
			self.logger.info('Source Schema HDFS Dir is: ' + schema_hdfs_dir)

			fs = self.spark._jvm.org.apache.hadoop.fs.FileSystem.get(self.spark._jsc.hadoopConfiguration())
			if fs.exists(self.spark.sparkContext._jvm.Path(ingestion_success_file_path)):
				fs.delete(self.spark.sparkContext._jvm.Path(ingestion_success_file_path),False)
				self.logger.info('Old Ingestion Success File Deleted Successfully')
			else:
				self.logger.info('Old Ingestion Success File Not Found for Deletion')

			syncsort_success_file_path = self.args["syncsort_success_hdfs_dir"] + success_file_nm
			self.logger.info('Syncsort Success File is: ' + syncsort_success_file_path)

			self.logger.info('Checking If Syncsort Success File is Present')
			try:
				fs.getFileStatus(self.spark.sparkContext._jvm.Path(syncsort_success_file_path))
				self.logger.info('Syncsort Success File is Present')
			except Exception as e:
				self.logger.info('Syncsort Success File Does Not Exists')
				raise

			self.logger.info('Reading Feed Date from Syncsort Success File')
			jsonSchema = self.spark.read.text(syncsort_success_file_path).rdd.map(lambda l: (1,l.value)).groupByKey().map(lambda l: "".join(list(l[1]))).collect()
			syncsort_success_status = json.loads(jsonSchema[0])
			feed_dt = str(syncsort_success_status["feed_dt"])
			feed_mnth = str(syncsort_success_status["feed_mnth"])
			self.logger.info('Feed Date Read from Syncsort Success File is: ' + feed_dt)

			self.logger.info('Connecting to HiveServer2 using JDBC')
			java_import(self.spark._jvm, 'org.apache.hive.jdbc.HiveDriver')
			driver = self.spark.sparkContext._jvm.HiveDriver()
			hive2_jdbc_url = self.args['hive2_jdbc_url']
			hive2_jdbc_principal = self.args['hive2_jdbc_principal']
			hive2_jdbc_ssl = self.args['hive2_jdbc_ssl']
			hive2_jdbc_connect_url = hive2_jdbc_url +";principal="+ hive2_jdbc_principal + ";ssl=" + hive2_jdbc_ssl + ";"
			self.logger.info('Hive2 JDBC CONNECT URL is ' + hive2_jdbc_connect_url)
			conn = driver.connect(hive2_jdbc_connect_url,self.spark.sparkContext._jvm.java.util.Properties())
			stmt = conn.createStatement()
			self.logger.info('Successfully Connected to HiveServer2 using JDBC')

			self.logger.info('Trying to Ingest the Nasco ' + feed_cycle.upper() + ' Bank File with Feed Date: ' + feed_dt)

			input_trigger_list = [	(self.env.upper() + "_NASCO_" + feed_cycle.upper() + "_BANK_DATE_SEG_" + feed_dt + ".txt",
								"schema_claim_sas_nasco_" + feed_cycle.lower() + "_bank_date_seg.json"),
						(self.env.upper() + "_NASCO_" + feed_cycle.upper() + "_BANK_CHECK_SEG_" + feed_dt + ".txt",
								"schema_claim_sas_nasco_" + feed_cycle.lower() + "_bank_check_seg.json"),
						(self.env.upper() + "_NASCO_" + feed_cycle.upper() + "_BANK_STDRD_SEG_" + feed_dt + ".txt",
								"schema_claim_sas_nasco_" + feed_cycle.lower() + "_bank_stdrd_seg.json"),
						(self.env.upper() + "_NASCO_" + feed_cycle.upper() + "_BANK_RECOUP_SEG_" + feed_dt + ".txt",
								"schema_claim_sas_nasco_" + feed_cycle.lower() + "_bank_recoup_seg.json")]

			self.logger.info('Validating if all the Input Trigger File Exists')
			fs = self.spark._jvm.org.apache.hadoop.fs.FileSystem.get(self.spark._jsc.hadoopConfiguration())
			for ingest_file_nm,schema_file_nm in input_trigger_list:
				try:
					fs.getFileStatus(self.spark.sparkContext._jvm.Path(staging_hdfs_dir + ingest_file_nm))
				except Exception as e:
					self.logger.info('Input Ingest Trigger File Does Not Exists: ' + ingest_file_nm)
					raise
				try:
					fs.getFileStatus(self.spark.sparkContext._jvm.Path(schema_hdfs_dir + schema_file_nm))
				except Exception as e:
					self.logger.info('Input Schema Trigger File Does Not Exists: ' + schema_file_nm)
					raise
			self.logger.info('Validation of Input Trigger File Done Successfully')

			ingest_status = {}

			for ingest_file_nm,schema_file_nm in input_trigger_list:
				ingest_status[ingest_file_nm] = {'ParquetWrite': 'FAILED','AlterQuery': 'FAILED','RawMove': 'FAILED'}
				ingest_status[ingest_file_nm]['staging_hdfs_dir'] = staging_hdfs_dir

				self.logger.info('Ingestion File Name is ' + ingest_file_nm)
				self.logger.info('Source Schema File Name is ' + schema_file_nm)

				self.logger.info('Started Reading the Schema File')
				jsonSchema_0 = self.spark.read.text(schema_hdfs_dir + schema_file_nm)
				jsonSchema = jsonSchema_0.rdd.map(lambda l: (1,l.value)).groupByKey().map(lambda l: "".join(list(l[1]))).collect()
				dataset = json.loads(jsonSchema[0])
				curate_table_name = dataset["name"]
				curate_db_name = self.env + "_curate_" + dataset["business_domain"]
				curate_hdfs_dir= "/" + self.env + "/curate/" + dataset["business_domain"] + "/" + dataset["name"] + "/"
				ingest_status[ingest_file_nm]['curate_hdfs_dir'] = curate_hdfs_dir
				raw_hdfs_dir = "/" + self.env +"/raw/"+ dataset["business_domain"] +"/" + dataset["source_system_code"] +"/"+ dataset["name"] +"/"
				ingest_status[ingest_file_nm]['raw_hdfs_dir'] = raw_hdfs_dir
				partition_keys_list = dataset["partition_keys"]
				raw_schema_list = dataset["raw_schema"]
				curate_schema_list = dataset["curate_schema"]
				self.logger.info('Successfully Read the Schema File')

				self.logger.info('Curate DB Name is ' + curate_db_name)
				self.logger.info('Curate Table Name is ' + curate_table_name)
				self.logger.info('Curate HDFS Directory is ' + curate_hdfs_dir)
				self.logger.info('Curate DB Name is ' + curate_db_name)
				self.logger.info('Raw HDFS Directory is ' + raw_hdfs_dir)

				self.logger.info('Get Raw Schema and Raw Schema Enum')
				raw_schema = self.get_schema(raw_schema_list)
				raw_string_schema = self.get_schema(raw_schema_list,all_string = True)
				raw_schema_enum = Enum('raw_schema_enum',[c.name for c in raw_schema.fields],start=0)
				self.logger.info('Successfully Got Raw Schema, Raw String Schema and Raw Schema Enum')

				self.logger.info('Get Curate Schema and Curate Schema Enum')
				curate_schema = self.get_schema(curate_schema_list)
				curate_schema_enum = Enum('curate_schema_enum',[c.name for c in curate_schema.fields],start=0)
				self.logger.info('Successfully Got Curate Schema and Curate Schema Enum')

				#self.logger.info('Raw Schema are ' + raw_schema)
				#self.logger.info('Curate Schema are ' + curate_schema)
				partition_columns = partition_keys_list
				self.logger.info('Curate Table Partitioning Columns are ' + "".join(partition_columns))

				raw_temp_table_view = "raw_temp_view_" + curate_table_name
				self.logger.info('Raw Temp Table View is: ' + raw_temp_table_view)

				curate_temp_table_view = "curate_temp_view_" + curate_table_name
				self.logger.info('Curate Temp Table View is: ' + curate_temp_table_view)

				self.logger.info('Creating Mapping and Transformation Query')

				if schema_file_nm == "schema_claim_sas_nasco_" + feed_cycle.lower() + "_bank_date_seg.json":
					mapAndTrsformQuery = self.get_date_mapAndTrsformQuery(raw_schema_enum,curate_schema_enum,ingest_file_nm)
				elif schema_file_nm == "schema_claim_sas_nasco_" + feed_cycle.lower() + "_bank_check_seg.json":
					mapAndTrsformQuery = self.get_check_mapAndTrsformQuery(raw_schema_enum,curate_schema_enum,ingest_file_nm)
				elif schema_file_nm == "schema_claim_sas_nasco_" + feed_cycle.lower() + "_bank_stdrd_seg.json":
					mapAndTrsformQuery = self.get_stdrd_mapAndTrsformQuery(raw_schema_enum,curate_schema_enum,ingest_file_nm)
				elif schema_file_nm == "schema_claim_sas_nasco_" + feed_cycle.lower() + "_bank_recoup_seg.json":
					mapAndTrsformQuery = self.get_recoup_mapAndTrsformQuery(raw_schema_enum,curate_schema_enum,ingest_file_nm)

				self.logger.info('Map and Transform Query is: ' + mapAndTrsformQuery)

				self.logger.info('Reading Ingest File From Staging HDFS Directory')
				A = self.spark.read.option("delimiter","|").schema(raw_string_schema).csv(staging_hdfs_dir + ingest_file_nm)
				self.logger.info('Read Ingest File From Staging HDFS Directory')

				self.logger.info('Started Doing Data Validation on Raw Ingest File')
				B = A.rdd.map(lambda row: data_validation(row,raw_schema,"raw"))
				notValidCount = B.filter(lambda row: row[1] == "isNotValid").count()
				if notValidCount != 0:
					self.logger.info('Data Validation on Raw Ingest File Failed')
					self.logger.info('Number of Records Failed Raw Data Validation is: ' + str(notValidCount))
					error_file_name = error_hdfs_dir + ingest_file_nm
					B.filter(lambda row: row[1] == "isNotValid").saveAsTextFile(error_hdfs_dir + ingest_file_nm)
					self.logger.info('Bad Records Written in Error File: ' + error_hdfs_dir + ingest_file_nm)
					self.logger.info('Aborting Ingest Process')
					raise(DataValidationError("Raw Data Validation Failed"))
				else:
					self.logger.info('Data Validation on Raw Ingest File Succeeded')

				self.logger.info('Creating Raw Data Frame by Applying Raw Schema')
				C = self.spark.read.option("delimiter","|").schema(raw_schema).csv(staging_hdfs_dir + ingest_file_nm)
				C.createOrReplaceTempView(raw_temp_table_view)
				#B.map(lambda row: row[0])
				#D = self.spark.createDataFrame(C,raw_schema)
				#D.createOrReplaceTempView(raw_temp_table_view)
				self.logger.info('Created Raw Data Frame Successfully')

				self.logger.info('Applying Curate Mapping and Transformation on Raw Data Frame')
				E = self.spark.sql("""SELECT {0} FROM {1}""".format(mapAndTrsformQuery,raw_temp_table_view))
			
				self.logger.info('Started Doing Data Validation on Curate Data Frame')
				F = E.rdd.map(lambda row: data_validation(row,curate_schema,"curate"))
				notValidCount = F.filter(lambda row: row[1] == "isNotValid").count()
				if notValidCount != 0:
					self.logger.info('Data Validation on Curate Data Frame Failed')
					self.logger.info('Number of Records Failed Curate Data Validation is: ' + str(notValidCount))
					self.logger.info('Aborting Ingest Process')
					raise(DataValidationError("Curate Data Validation Failed"))
				else:
					self.logger.info('Data Validation on Curate Data Frame Succeeded')

				E.createOrReplaceTempView(curate_temp_table_view)
				#self.logger.info('The Curate Data are: ' + E.show(truncate=False))

				try:
					self.logger.info('Writting Curate Data to Parquet File')
					E.write.mode("append").partitionBy(partition_columns).parquet(curate_hdfs_dir)
					ingest_status[ingest_file_nm]['ParquetWrite'] = 'SUCCESS'
					self.logger.info('Curate Data Successfully Written to Parquet File')
				except Exception as e:
					self.logger.info('Failed to Write Curate Data to Parquet File')
					raise

				try:
					self.logger.info('Adding Partitions to Table')
					alterQuery = """MSCK REPAIR TABLE {0}.{1}""".format(curate_db_name,curate_table_name)
					self.logger.info('Alter Query is: ' + alterQuery)
					result = stmt.execute(alterQuery)
					ingest_status[ingest_file_nm]['AlterQuery'] = 'SUCCESS'
					self.logger.info('Partitions Added Successfully')
				except Exception as e:
					self.logger.info('Failed to Add Partitions to Table')
					raise

				try:
					self.logger.info('Moving Ingest File from Staging HDFS to Raw HDFS Directory')
					fs = self.spark._jvm.org.apache.hadoop.fs.FileSystem.get(self.spark._jsc.hadoopConfiguration())
					if fs.exists(self.spark.sparkContext._jvm.Path(raw_hdfs_dir + ingest_file_nm)):
						fs.rename(
							self.spark.sparkContext._jvm.Path(raw_hdfs_dir + ingest_file_nm),
							self.spark.sparkContext._jvm.Path(raw_hdfs_dir + ingest_file_nm + "_" +datetime.today().strftime('%Y%m%d%H%M%S')))
						self.logger.info('Backed Up Older Raw HDFS Ingest File')
					fs.rename(
						self.spark.sparkContext._jvm.Path(staging_hdfs_dir + ingest_file_nm),
						self.spark.sparkContext._jvm.Path(raw_hdfs_dir + ingest_file_nm))
					ingest_status[ingest_file_nm]['RawMove'] = 'SUCCESS'
					self.logger.info('Successfully Moved Ingest File from Staging to Raw HDFS Directory')
				except Exception as e:
					self.logger.info('Failed to Move Ingest File from Staging HDFS to RAW HDFS Directory')
					raise

				self.logger.info('Ingest Status is: ' + json.dumps(ingest_status))

			self.logger.info('Closing Connection to HiveServer2')
			conn.close()
			self.logger.info('Successfully Closed Connection to HiveServer2')

			self.logger.info('Writing Ingestion Success File: ' + ingestion_success_file_path)
			write_stream = fs.create(self.spark.sparkContext._jvm.Path(ingestion_success_file_path))
			ingestion_success_status = {}
			ingestion_success_status["feed_dt"] = feed_dt
			if feed_mnth == "":
				if feed_cycle == "MONTHLY" and datetime.strptime(feed_dt,"%Y%m%d").day in range(1,27):
					feed_mnth = (datetime.strptime(feed_dt,"%Y%m%d") - relativedelta(months=1)).strftime('%m')
				else:
					feed_mnth = datetime.strptime(feed_dt,"%Y%m%d").strftime('%m')
			ingestion_success_status["feed_mnth"] = feed_mnth
			self.logger.info('Ingestion Success Status is: ' + json.dumps(ingestion_success_status))
			write_stream.writeBytes(json.dumps(ingestion_success_status)+"\n")
			write_stream.close()
			self.logger.info('Successfully Written to Ingestion Success File: ' + ingestion_success_file_path)

			self.logger.info('Deleting Syncsort Success File: ' + syncsort_success_file_path)
			fs.delete(self.spark.sparkContext._jvm.Path(syncsort_success_file_path),False)
			self.logger.info('Syncsort Success File Deleted Successfully')

			self.logger.info('Appsimp Audit logs table will be updated with SUCCESS Status')
			au.set_success(self.spark,self.env,self.job_nm,self.host_nm,self.yarn_app_id,self.start_time,"",self.log_file,self.dmn)
			self.end_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
			self.logger.info('Job End Time is: ' + self.end_time)
			self.logger.info('Finished Executing the Job: ' + self.job_nm)
		except Exception as e:
			self.logger.info('Rolling back Ingested Data if Required')
			if ingest_status != None and input_trigger_list != None:
				for ingest_file_nm,schema_file_nm in input_trigger_list:
					file_key = ingest_file_nm
					if file_key in ingest_status.keys() and ingest_status[file_key]['RawMove'] == 'SUCCESS':
						self.logger.info('Rolling back Ingest File from RAW HDFS to Staging HDFS Directory')
						fs.rename(
							self.spark.sparkContext._jvm.Path(ingest_status[file_key]['raw_hdfs_dir'] + ingest_file_nm),
							self.spark.sparkContext._jvm.Path(ingest_status[file_key]['staging_hdfs_dir'] + ingest_file_nm))
						self.logger.info('Rolled back Ingest File from RAW HDFS to Staging HDFS Directory Successfully')
					if file_key in ingest_status.keys() and (ingest_status[file_key]['AlterQuery'] == 'SUCCESS' or ingest_status[file_key]['ParquetWrite'] == 'SUCCESS'):
						self.logger.info('Rolling back Ingest File from Curate HDFS Directory')
						self.logger.info('Deleting Curate HDFS Directory: '+ ingest_status[file_key]['curate_hdfs_dir'] +'feed_cycle='+ feed_cycle +'/feed_dt='+ feed_dt)
						fs.delete(self.spark.sparkContext._jvm.Path(ingest_status[file_key]['curate_hdfs_dir'] + 'feed_cycle='+ feed_cycle +'/feed_dt='+ feed_dt),True)
						self.logger.info('Deleted Curate HDFS Directory Successfully')
				self.logger.info('Rolling back Ingested Data Done')
			self.logger.info('Appsimp Audit logs table will be updated with FAILED Status')
			au.set_failed(self.spark,self.env,self.job_nm,self.host_nm,self.yarn_app_id,self.start_time,"",self.log_file,self.dmn)
			raise

def main(spark,**args):
	logger = spark.sparkContext._jvm.org.apache.log4j.LogManager.getLogger(__name__)
	obj =  dlap_appsimp_sas_nasco_bank_file_ingestion(spark,args)
	logger.info("Successfully Initialized the Pyspark Job: " + spark.sparkContext.appName)
	try:
		obj.run()
	except Exception as e:
		raise
