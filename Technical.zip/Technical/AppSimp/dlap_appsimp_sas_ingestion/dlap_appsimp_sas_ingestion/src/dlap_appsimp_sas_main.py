"""dlap_appsimp_sas_main.py: This Program is a main program for the spark submit command which is used to import each job as a module and run the job"""

__author__      = "Amar Kashyap"
__copyright__   = "Copyright 2019, This Code is Developed for BCBSMA by IBM Under Appsimp Program - SAS Mainframe to DLAP Migration"
__credits__     = ["Rakesh Munigala", "Sai Sunil Vanam"]
__version__     = "1.0"
__maintainer__  = "Amar Kashyap"
__email__       = "amar.kashyap@bcbsma.com, amakashy@in.ibm.com"

import argparse
import importlib
import time
import os
import sys
import json
import traceback
import shutil

if os.path.exists('jobs.zip'):
	sys.path.insert(0, 'jobs.zip')
else:
	sys.path.insert(0, './jobs')

if os.path.exists('libs.zip'):
	sys.path.insert(1, 'libs.zip')
else:
	sys.path.insert(1, './libs')

from shared import dlap_appsimp_sas_mail_util as mu

try:
	from pyspark.sql import SparkSession 
except:
	import findspark
	findspark.init()
	from pyspark.sql import SparkSession

if __name__ == '__main__':
	parser = argparse.ArgumentParser(description='Run a PySpark job')
	parser.add_argument('--job', type=str, required=True, dest='job_name', help="The name of the job module you want to run")
	parser.add_argument('--dmn', type=str, required=True, dest='job_dmn', help="The name of the business domain the job module belongs to")
	parser.add_argument('--env', type=str, required=True, dest='job_env', help="The name of the environment the job module will run in")
	parser.add_argument('--job-args', nargs='*', help="Extra arguments to send to the PySpark job (example: --job-args key1=value1")

	args = parser.parse_args()
	print("Called with arguments: %s" % (args))

	job_args = dict()
	if args.job_args:
		job_args_tuples = [arg_str.split('=') for arg_str in args.job_args]
		job_args = {a[0]: a[1] for a in job_args_tuples}

	job_args['job_name'] = args.job_name.lower()
	job_args['dmn'] = args.job_dmn.lower()
	job_args['env'] = args.job_env.lower()
	print('\nJob Environment is %s\n' % (job_args))

	try:
		temp_dir = ""
		log_file = ""
		support_mail_list = ""
		if 'support_mail_list' in job_args: support_mail_list = job_args['support_mail_list'].split(',')
		from_mail = "spark"
		spark = SparkSession.builder.appName(args.job_name).getOrCreate()
		from_mail = spark.sparkContext.sparkUser()
		logger = spark.sparkContext._jvm.org.apache.log4j.LogManager.getLogger(__name__)
		fileAppender = logger.getAppender('File')
		if fileAppender != None:
			log_file = fileAppender.getFile()
			fs = spark._jvm.org.apache.hadoop.fs.RawLocalFileSystem()
			path = spark._jvm.org.apache.hadoop.fs.Path(log_file)
			perm = spark._jvm.org.apache.hadoop.fs.permission.FsPermission.valueOf("-rw-r--r--")
			if fs.pathToFile(path).exists(): fs.setPermission(path,perm)
		job_args['log_file'] = log_file
		logger.info("#####################################################")
		logger.info("Pyspark Session Created and Logger Initialized Successfully")
		logger.info("Logging to Log File: " + log_file)
		logger.info("Creating Temp Directory for Processing")
		temp_dir = "/tmp/" + args.job_name + "_SparkJob_" + spark.sparkContext.applicationId
		os.mkdir(temp_dir)
		logger.info("Created Temp Directory: " + temp_dir)
		job_args['temp_dir'] = temp_dir
		logger.info("Running Job: " + args.job_name)
		logger.info("Job Arguments: " + json.dumps(job_args))
		job_module = importlib.import_module('jobs.%s.%s' % (args.job_name, args.job_name))
		start = time.time()
		job_module.main(spark, **job_args)
		end = time.time()
		if os.path.isdir(temp_dir): shutil.rmtree(temp_dir)
		logger.info("Deleted Temp Directory: " + temp_dir)
		logger.info("Execution of Job " + args.job_name + " took " + str(end-start) + " Seconds")
		if support_mail_list != "":
			if 'job_type' in job_args.keys():
				job_type_identifier = job_args['job_type'].lower() + " "
			else:
				job_type_identifier = ""
			mu.send_mail(args.job_name,from_mail,support_mail_list, \
			args.job_env.upper() + " : " + "SUCCESS" + " - " + "Pyspark Job " + job_type_identifier + args.job_name + " Completed Successfully", \
			"Pyspark Job " + job_type_identifier + args.job_name + " Completed Successfully")
	except Exception as e:
		if temp_dir != "" and os.path.isdir(temp_dir): shutil.rmtree(temp_dir)
		logger.info("Deleted Temp Directory: " + temp_dir)
		logger.error("Error in Job Execution: " + traceback.format_exc())
		if support_mail_list != "":
			if 'job_type' in job_args.keys():
				job_type_identifier = job_args['job_type'].lower() + " "
			else:
				job_type_identifier = ""
			mu.send_mail(args.job_name,from_mail,support_mail_list, \
			args.job_env.upper() + " : " + "FAILED" + " - " + "Pyspark Job " + job_type_identifier + args.job_name + " Failed", \
			"Pyspark Job " + job_type_identifier + args.job_name + " Failed")
		raise
