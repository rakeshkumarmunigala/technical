"""dlap_appsimp_sas_sftp_util.py: This Program defines subroutine for transferring a file to TW using SFTP Protocol"""

__author__      = "Amar Kashyap"
__copyright__   = "Copyright 2019, This Code is Developed for BCBSMA by IBM Under Appsimp Program - SAS Mainframe to DLAP Migration"
__credits__     = ["Rakesh Munigala", "Sai Sunil Vanam"]
__version__     = "1.0"
__maintainer__  = "Amar Kashyap"
__email__       = "amar.kashyap@bcbsma.com, amakashy@in.ibm.com"

from py4j.java_gateway import java_import
import re,operator

def upload_file(spark,server,user,source,destination,file_pattern,identity=None,password=None):
	try:
		java_import(spark._jvm,'com.jcraft.jsch.JSch')
		jsch = spark._jvm.JSch()
		if identity != None and password == None:
			jsch.addIdentity(identity)
		s = jsch.getSession(user,server,22)
		s.setConfig("StrictHostKeyChecking","no")
		if identity == None and password != None:
			s.setPassword(password)
		s.connect()
		c = s.openChannel("sftp")
		c.connect()
		c.put(source + file_pattern,destination)
		c.exit()
		s.disconnect()
	except Exception as e:
		raise

def download_file(spark,server,user,source,destination,file_pattern,identity=None,password=None):
	try:
		java_import(spark._jvm,'com.jcraft.jsch.JSch')
		jsch = spark._jvm.JSch()
		if identity != None and password == None:
			jsch.addIdentity(identity)
		s = jsch.getSession(user,server,22)
		s.setConfig("StrictHostKeyChecking","no")
		if identity == None and password != None:
			s.setPassword(password)
		s.connect()
		c = s.openChannel("sftp")
		c.connect()
		tgt_file_nm = None
		files = c.ls(source)
		if files != None:
			file_list = []
			for f in files:
				if re.match(re.compile(file_pattern),f.getFilename()) != None:
					file_list.append((f.getFilename(),f.getAttrs().getMTime()))
			if len(file_list) != 0:
				file_list = sorted(file_list, key=lambda k: -k[1])
				tgt_file_nm = file_list[0][0]
				c.get(source + tgt_file_nm,destination + tgt_file_nm)
		c.exit()
		s.disconnect()
		return tgt_file_nm
	except Exception as e:
		raise

def remove_file(spark,server,user,source,file_pattern,identity=None,password=None):
	try:
		java_import(spark._jvm,'com.jcraft.jsch.JSch')
		jsch = spark._jvm.JSch()
		if identity != None and password == None:
			jsch.addIdentity(identity)
		s = jsch.getSession(user,server,22)
		s.setConfig("StrictHostKeyChecking","no")
		if identity == None and password != None:
			s.setPassword(password)
		s.connect()
		c = s.openChannel("sftp")
		c.connect()
		c.rm(source + file_pattern)
		c.exit()
		s.disconnect()
	except Exception as e:
		raise
