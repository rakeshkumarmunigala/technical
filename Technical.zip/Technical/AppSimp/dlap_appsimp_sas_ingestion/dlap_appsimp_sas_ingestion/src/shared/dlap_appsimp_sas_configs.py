"""dlap_appsimp_sas_configs.py: This Program defines various subroutines for setting and getting params and configs values from Hive"""

__author__      = "Amar Kashyap", "Sai Sunil Vanam"
__copyright__   = "Copyright 2019, This Code is Developed for BCBSMA by IBM Under Appsimp Program - SAS Mainframe to DLAP Migration"
__credits__     = ["Rakesh Munigala", "Sai Sunil Vanam"]
__version__     = "1.0"
__maintainer__  = "Amar Kashyap", "Sai Sunil Vanam"
__email__       = "amar.kashyap@bcbsma.com, amakashy@in.ibm.com"

import traceback

def get_param(spark,env,job_nm):
	try:
		param = spark.sql("""
			SELECT
				param
			FROM
				{0}_appsimp_logs.appsimp_param
			WHERE
				job_nm = '{1}'
			ORDER BY insert_ts DESC
			""".format(env,job_nm)).collect()
		return param[0]['param']
	except Exception as e:
		raise


def get_config(spark,env,job_nm):
	try:
		config = spark.sql("""
			SELECT
				config
			FROM
				{0}_appsimp_logs.appsimp_config
			WHERE
				job_nm = '{1}'
			ORDER BY insert_ts DESC
			""".format(env,job_nm)).collect()
		return config[0]['config']
	except Exception as e:
		raise

def set_param(spark,env,dmn,job_nm,param):
	try:
		df = spark.sql("""
			SELECT
				'{0}' as dmn,
				'{1}' as job_nm,
				map{2} as param,
				current_timestamp as insert_ts
			""".format(dmn,job_nm,param))
		tbl_name = env + "_appsimp_logs.appsimp_param"
		df.write.insertInto(tbl_name,overwrite = False)
	except Exception as e:
		raise

def set_config(spark,env,dmn,job_nm,config):
	try:
		df = spark.sql("""
			SELECT
				'{0}' as dmn,
				'{1}' as job_nm,
				map{2} as config,
				current_timestamp as insert_ts
				""".format(dmn,job_nm,config))
		tbl_name = env + "_appsimp_logs.appsimp_config"
		df.write.insertInto(tbl_name,overwrite = False)
	except Exception as e:
		raise
