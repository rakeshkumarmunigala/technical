#!/bin/bash

###############################################################################################################
#Script Name    : dlap_appsimp_sas_oozie_submit.sh
#Description    : This Program is a Oozie Submit Script for submitting Oozie Jobs
#Args           : $JOB_TYPE $JOB_NAME
#Author         : "Amar Kashyap"
#Copyright      : "Copyright 2019, This Code is Developed for BCBSMA by IBM Under Appsimp Program - SAS Mainframe to DLAP Migration"
#Credits        : "Rakesh Munigala", "Sai Sunil Vanam"
#Version        : "1.0"
#Maintainer     : "Amar Kashyap"
#Email          : "amar.kashyap@bcbsma.com, amakashy@in.ibm.com"
#Usage          : ./dlap_appsimp_sas_oozie_submit.sh wf dlap_appsimp_sas_nasco_weekly_cash_dtl_report
###############################################################################################################

SCRIPT_NAME="dlap_appsimp_sas_oozie_submit.sh"

echo "User is "$USER

echo "User Home is "$HOME

source ../../conf/env/dlap_appsimp_sas_job_env_var.sh

BUILD_VERSION=`cat ../../make_version.txt | grep BUILD_VERSION | cut -d '=' -f 2`
INSTALL_VERSION=`cat ../../make_version.txt | grep INSTALL_VERSION | tail -1 | cut -d '=' -f 2`

if [[ $BUILD_VERSION == $INSTALL_VERSION ]]
then
	echo "Successfully Verified Build and Install Version"
else
	echo "Mismatched Build and Install Version"
	echo "Make Sure to Run the Build and Install Correctly"
	exit 1
fi

if [[ -z "$JOB_ENV" ]]
then
	echo "Error: JOB_ENV(dev|test|stg|prd) needs to be set before running this script"
	exit 1
fi

if [[ -z "$JOB_DOMAIN" ]]
then
	echo "Error: JOB_DOMAIN needs to be set before running this script"
	exit 1
fi

if [[ -z "$JOB_OOZIE_URL" ]]
then
	echo "Error: JOB_OOZIE_URL needs to be set before running this script"
	exit 1
fi

if [[ -z "$JOB_NAMENODE_URL" ]]
then
	echo "Error: JOB_NAMENODE_URL needs to be set before running this script"
	exit 1
fi

JOB_TYPE=$1

JOB_NAME=$2

echo "Submitted JobType is: "$JOB_TYPE
echo "Job Oozie URL is: "$JOB_OOZIE_URL
echo "Job Namenode URL is: "$JOB_NAMENODE_URL
echo "Submitted JobName is: "$JOB_NAME
echo "Submitted JobDomain is: "$JOB_DOMAIN
echo "Job Environment is: "$JOB_ENV
echo "Job Optional Common Args are: "$JOB_COMMON_ARGS

if [[ $JOB_TYPE == wf ]]
then
	echo "Submitting the Oozie JobType "$JOB_TYPE
	if [ -f ../../conf/oozie/workflow/"$JOB_NAME"_workflow.xml ]
	then
		WF_APP_NAME="$JOB_NAME"_workflow.xml
	else
		WF_APP_NAME=dlap_appsimp_sas_shell_action_workflow.xml
	fi
	echo "Wf Application Name is: "$WF_APP_NAME
	oozie job -oozie $JOB_OOZIE_URL \
	-D user.home="$HOME" \
	-D appsimp.job.namenode.url="$JOB_NAMENODE_URL" \
	-D appsimp.job.tracker=yarnRM \
	-D appsimp.job.path="$JOB_NAMENODE_URL"/user/"$USER"/appsimp/sas/"$JOB_ENV"/dlap_appsimp_sas_ingestion/dist \
	-D oozie.wf.application.path="$JOB_NAMENODE_URL"/user/"$USER"/appsimp/sas/"$JOB_ENV"/dlap_appsimp_sas_ingestion/dist/conf/oozie/workflow/"$WF_APP_NAME" \
	-D appsimp.job.name="$JOB_NAME" \
	-D appsimp.job.dmn="$JOB_DOMAIN" \
	-D appsimp.job.env="$JOB_ENV" \
	-D appsimp.job.common.args="$JOB_COMMON_ARGS" \
	-D appsimp.job.syncsort.success.hdfs.dir="$JOB_SYNCSORT_SUCCESS_HDFS_DIR" \
	-D appsimp.job.spark.anaconda.path="$JOB_SPARK_ANACONDA_PYTHON" \
	-D appsimp.job.spark.driver.memory="$JOB_SPARK_DRIVER_MEMORY" \
	-D appsimp.job.spark.executory.memory="$JOB_SPARK_EXECUTOR_MEMORY" \
	-D appsimp.job.spark.num.executors="$JOB_SPARK_NUM_EXECUTORS" \
	-D appsimp.job.spark.executor.cores="$JOB_SPARK_EXECUTOR_CORES" \
	-D appsimp.job.spark.driver.cores="$JOB_SPARK_DRIVER_CORES" \
	-D appsimp.job.spark.yarn.maxAppAttempts="$JOB_SPARK_YARN_MAXAPPATTEMPTS" \
	-config ../../conf/oozie/jobs/"$JOB_NAME"_job.properties \
	-run
elif [[ $JOB_TYPE == coord ]]
then
	echo "Submitting the Oozie JobType "$JOB_TYPE
	if [ -f ../../conf/oozie/coordinator/"$JOB_NAME"_coordinator.xml ]
	then
		COORD_APP_NAME="$JOB_NAME"_coordinator.xml
	else
		COORD_APP_NAME=dlap_appsimp_sas_shell_action_coordinator.xml
	fi
	echo "Coord Application Name is: "$COORD_APP_NAME
	oozie job -oozie $JOB_OOZIE_URL \
	-D user.home="$HOME" \
	-D appsimp.job.namenode.url="$JOB_NAMENODE_URL" \
	-D appsimp.job.tracker=yarnRM \
	-D appsimp.job.path="$JOB_NAMENODE_URL"/user/"$USER"/appsimp/sas/"$JOB_ENV"/dlap_appsimp_sas_ingestion/dist \
	-D oozie.coord.application.path="$JOB_NAMENODE_URL"/user/"$USER"/appsimp/sas/"$JOB_ENV"/dlap_appsimp_sas_ingestion/dist/conf/oozie/coordinator/"$COORD_APP_NAME" \
	-D appsimp.job.name="$JOB_NAME" \
	-D appsimp.job.dmn="$JOB_DOMAIN" \
	-D appsimp.job.env="$JOB_ENV" \
	-D appsimp.job.common.args="$JOB_COMMON_ARGS" \
	-D appsimp.job.syncsort.success.hdfs.dir="$JOB_SYNCSORT_SUCCESS_HDFS_DIR" \
	-D appsimp.job.spark.anaconda.path="$JOB_SPARK_ANACONDA_PYTHON" \
	-D appsimp.job.spark.driver.memory="$JOB_SPARK_DRIVER_MEMORY" \
	-D appsimp.job.spark.executory.memory="$JOB_SPARK_EXECUTOR_MEMORY" \
	-D appsimp.job.spark.num.executors="$JOB_SPARK_NUM_EXECUTORS" \
	-D appsimp.job.spark.executor.cores="$JOB_SPARK_EXECUTOR_CORES" \
	-D appsimp.job.spark.driver.cores="$JOB_SPARK_DRIVER_CORES" \
	-D appsimp.job.spark.yarn.maxAppAttempts="$JOB_SPARK_YARN_MAXAPPATTEMPTS" \
	-config ../../conf/oozie/jobs/"$JOB_NAME"_job.properties \
	-run
else
	echo "Error: Please Specify Correct Job Type [wf|coord]"
	exit 1
fi
