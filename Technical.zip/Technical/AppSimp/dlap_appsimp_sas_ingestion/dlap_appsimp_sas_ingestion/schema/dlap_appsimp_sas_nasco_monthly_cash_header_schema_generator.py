dataset_name = "claim_sas_nasco_monthly_cash_header"

from py4j.java_gateway import java_import

java_import(spark._jvm, 'org.apache.hadoop.hbase.HBaseConfiguration')
java_import(spark._jvm, 'org.apache.hadoop.hbase.client._')
java_import(spark._jvm, 'org.apache.hadoop.hbase.util.Bytes')
java_import(spark._jvm, 'org.apache.hadoop.hbase.filter.ColumnRangeFilter')

java_import(spark._jvm, 'org.apache.hadoop.hbase.client.ConnectionFactory')
java_import(spark._jvm, 'org.apache.hadoop.hbase.TableName')

java_import(spark._jvm, 'org.apache.hadoop.hbase.CellUtil')
java_import(spark._jvm, 'org.apache.hadoop.hbase.client.Get')

hbaseConf = spark._jvm.HBaseConfiguration.create()
conn = spark._jvm.ConnectionFactory.createConnection(hbaseConf)

table = conn.getTable(spark._jvm.TableName.valueOf("test_cif:dataset"))
get = spark._jvm.Get(spark._jvm.Bytes.toBytes("raw_nsc." + dataset_name + ".v1"))
get.addFamily(spark._jvm.Bytes.toBytes("schema"))
result = table.get(get)

schema = {}
schema["name"] = dataset_name
schema["bussiness_domain"] = "sas"
schema["source_system_code"] = "nsc"
schema["description"] = "This is Cash Header Record Extract from Nasco. This is received Monthly"
schema["file_format"] = "DELIMITED"
schema["delimiter"] = "|"
schema["file_naming_format"] = "(DEV|TEST|STG|PROD)_NASCO_(MONTHLY|WEEKLY|DAILY)_CASH_HEADER_\d{8}.txt"
schema["partitioning_keys"] = ["feed_cycle","feed_dt"]
schema["ingest_type"] = "FILE"
schema["multi_record_type_indicator"] = ""
schema["multi_record_type_indicator_pos"] = ""

import json
sch = []
for cell in result.rawCells():
	value = json.loads(spark._jvm.Bytes.toString(spark._jvm.CellUtil.cloneValue(cell)))
	r = {}
	r["name"] = value["name"]
	r["type"] = value["type"]
	r["nullable"] = value["required"]
	r["metadata"] = {"id": value["id"]+1,"description": value["description"],"position": value["position"],"size": value["size"]}
	sch.append(r)

import operator
sch = sorted(sch, key=lambda k: k["metadata"]["id"])

schema["raw_schema"] = sch

table = conn.getTable(spark._jvm.TableName.valueOf("test_cif:dataset"))
get = spark._jvm.Get(spark._jvm.Bytes.toBytes("curate_clm." + dataset_name + ".v1"))
get.addFamily(spark._jvm.Bytes.toBytes("schema"))
result = table.get(get)

import json
sch = []
for cell in result.rawCells():
	value = json.loads(spark._jvm.Bytes.toString(spark._jvm.CellUtil.cloneValue(cell)))
	r = {}
	r["name"] = value["name"]
	r["type"] = value["type"]
	r["nullable"] = value["required"]
	r["metadata"] = {"id": value["id"]+1,"description": value["description"],"position": value["position"],"size": value["size"]}
	sch.append(r)

import operator
sch = sorted(sch, key=lambda k: k["metadata"]["id"])
schema["curate_schema"] = sch

f = open("schema_" + dataset_name + "_v1.json", mode = 'w')
f.write(json.dumps(schema,indent=4))
f.close()
