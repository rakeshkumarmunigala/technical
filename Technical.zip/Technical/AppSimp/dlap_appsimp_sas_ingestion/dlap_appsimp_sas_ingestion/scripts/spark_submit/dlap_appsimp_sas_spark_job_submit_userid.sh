#!/bin/bash

###############################################################################################################
#Script Name    : dlap_appsimp_sas_spark_job_submit_userid.sh
#Description    : This Program is a Wrapper for Submitting the Spark Python Jobs Using Spark Submit Command by using individual lanid
#Args           : --job $PYSPARK_JOB_NAME --dmn $PYSPARK_JOB_DMN --env $PYSPARK_JOB_ENV --job-args $PYSPARK_JOB_ARGS
#Author         : "Amar Kashyap"
#Copyright      : "Copyright 2019, This Code is Developed for BCBSMA by IBM Under Appsimp Program - SAS Mainframe to DLAP Migration"
#Credits        : "Rakesh Munigala", "Sai Sunil Vanam"
#Version        : "1.0"
#Maintainer     : "Amar Kashyap"
#Email          : "amar.kashyap@bcbsma.com, amakashy@in.ibm.com"
#Usage          : ./dlap_appsimp_sas_spark_job_submit_userid.sh --job dlap_appsimp_sas_nasco_monthly_cash_dtl_report --dmn dlap_appsimp_sas --env test --job-args support_mail_list=email_id1@xyz.com,email_id2@xyz.com tw_password=xyz
###############################################################################################################

SCRIPT_NAME="dlap_appsimp_sas_spark_job_submit_userid.sh"

source ../../conf/env/dlap_appsimp_sas_job_env_var.sh

echo "User is "$USER

echo "User Home is "$HOME

BUILD_VERSION=`cat ../../make_version.txt | grep BUILD_VERSION | cut -d '=' -f 2`
INSTALL_VERSION=`cat ../../make_version.txt | grep INSTALL_VERSION | tail -1 | cut -d '=' -f 2`

if [[ $BUILD_VERSION == $INSTALL_VERSION ]]
then
	echo "Successfully Verified Build and Install Version"
else
	echo "Mismatched Build and Install Version"
	echo "Make Sure to Run the Build and Install Correctly"
	exit 1
fi

if [[ -z "$JOB_SPARK_ANACONDA_PYTHON" ]]
then
        echo "JOB_SPARK_ANACONDA_PYTHON needs to be set before running this script"
        exit 1
fi

ANACONDA_PYTHON=$JOB_SPARK_ANACONDA_PYTHON

echo "Anaconda Python is "$ANACONDA_PYTHON

if [[ -z "$JOB_SPARK_DRIVER_MEMORY" ]]
then
        echo "JOB_SPARK_DRIVER_MEMORY needs to be set before running this script"
        exit 1
fi

if [[ -z "$JOB_SPARK_EXECUTOR_MEMORY" ]]
then
        echo "JOB_SPARK_EXECUTOR_MEMORY needs to be set before running this script"
        exit 1
fi

if [[ -z "$JOB_SPARK_NUM_EXECUTORS" ]]
then
        echo "JOB_SPARK_NUM_EXECUTORS needs to be set before running this script"
        exit 1
fi

if [[ -z "$JOB_SPARK_EXECUTOR_CORES" ]]
then
	echo "JOB_SPARK_EXECUTOR_CORES needs to be set before running this script"
	exit 1
fi

if [[ -z "$JOB_SPARK_DRIVER_CORES" ]]
then
	echo "JOB_SPARK_DRIVER_CORES needs to be set before running this script"
	exit 1
fi

if [[ -z "$JOB_SPARK_YARN_MAXAPPATTEMPTS" ]]
then
	echo "JOB_SPARK_YARN_MAXAPPATTEMPTS needs to be set before running this script"
	exit 1
fi

echo "Arguments Passed Are "$@

log4j_file_name=$2_`date +"%Y_%m_%d_%H_%M_%S"`
echo "Log4j Logging File Name is "$log4j_file_name

PY_JOB_ENV=$JOB_ENV

log4j_setting="-Dlog4j.configuration=file:dlap_appsimp_sas_log4j.properties -Dlog_file_name=$log4j_file_name -Dlog_file_env=$PY_JOB_ENV"
echo "Log4j Logging Setting is "$log4j_setting

if [[ $PY_JOB_ENV == "prd" ]]
then
	SPARK_SUBMIT_CMD="spark-submit"
else
	SPARK_SUBMIT_CMD="spark2-submit"
fi

echo "SPARK_SUBMIT_CMD is "$SPARK_SUBMIT_CMD

$SPARK_SUBMIT_CMD \
--master yarn \
--deploy-mode cluster \
--driver-memory "$JOB_SPARK_DRIVER_MEMORY" \
--executor-memory "$JOB_SPARK_EXECUTOR_MEMORY" \
--num-executors "$JOB_SPARK_NUM_EXECUTORS" \
--executor-cores "$JOB_SPARK_EXECUTOR_CORES" \
--driver-cores "$JOB_SPARK_DRIVER_CORES" \
--files ../../conf/log4j/dlap_appsimp_sas_log4j.properties#dlap_appsimp_sas_log4j.properties \
--conf "spark.driver.extraJavaOptions=$log4j_setting" \
--conf "spark.executor.extraJavaOptions=$log4j_setting" \
--conf "spark.pyspark.driver.python=$ANACONDA_PYTHON" \
--conf "spark.pyspark.python=$ANACONDA_PYTHON" \
--conf "spark.yarn.appMasterEnv.PYSPARK_DRIVER_PYTHON=$ANACONDA_PYTHON" \
--conf "spark.yarn.appMasterEnv.PYSPARK_PYTHON=$ANACONDA_PYTHON" \
--conf "spark.yarn.maxAppAttempts=$JOB_SPARK_YARN_MAXAPPATTEMPTS" \
--keytab "$HOME"/.key \
--principal "$USER"@BCBSMAMD.NET \
--jars /opt/cloudera/parcels/CDH/lib/hive/lib/hive-jdbc-standalone.jar \
--archives ../../lib/libs.zip \
--py-files ../../lib/jobs.zip dlap_appsimp_sas_main.py $@
