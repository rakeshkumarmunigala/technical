#!/bin/bash

###############################################################################################################
#Script Name    : dlap_appsimp_sas_create_table.sh
#Description    : This Program is a Beeline Hive Shell Script to be used to create table in Hive using HQL
#Args           : 
#Author         : "Amar Kashyap"
#Copyright      : "Copyright 2019, This Code is Developed for BCBSMA by IBM Under Appsimp Program - SAS Mainframe to DLAP Migration"
#Credits        : "Rakesh Munigala", "Sai Sunil Vanam"
#Version        : "1.0"
#Maintainer     : "Amar Kashyap"
#Email          : "amar.kashyap@bcbsma.com, amakashy@in.ibm.com"
#Usage          : ./dlap_appsimp_sas_create_table.sh
###############################################################################################################

SCRIPT_NAME="dlap_appsimp_sas_create_table.sh"

echo "User is "$USER

echo "User Home is "$HOME

source ../../conf/env/dlap_appsimp_sas_job_env_var.sh

BUILD_VERSION=`cat ../../make_version.txt | grep BUILD_VERSION | cut -d '=' -f 2`
INSTALL_VERSION=`cat ../../make_version.txt | grep INSTALL_VERSION | cut -d '=' -f 2`

if [[ $BUILD_VERSION == $INSTALL_VERSION ]]
then
	echo "Successfully Verified Build and Install Version"
else
	echo "Mismatched Build and Install Version"
	echo "Make Sure to Run the Build and Install Correctly"
	exit 1
fi

if [[ -z "$JOB_ENV" ]]
then
	echo "JOB_ENV(dev|test|stg|prd) needs to be set before running this script"
	exit 1
fi

if [[ -z "$JOB_HIVE_BEELINE_URL" ]]
then
	echo "JOB_OOZIE_URL needs to be set before running this script"
	exit 1
fi

if [[ -z "$JOB_HIVE_BEELINE_PRINCIPAL" ]]
then
	echo "JOB_NAMENODE_URL needs to be set before running this script"
	exit 1
fi

echo "Job Hive Beeline URL is: "$JOB_HIVE_BEELINE_URL
echo "Job Hive Beeline Principal is: "$JOB_HIVE_BEELINE_PRINCIPAL
echo "Job Environment is: "$JOB_ENV

echo "Staring to Execute HQL using Hive Beeline"

beeline --verbose=true --showHeader=false -u "$JOB_HIVE_BEELINE_URL;principal=$JOB_HIVE_BEELINE_PRINCIPAL;ssl=true;" -f dlap_appsimp_sas_create_table.hql
