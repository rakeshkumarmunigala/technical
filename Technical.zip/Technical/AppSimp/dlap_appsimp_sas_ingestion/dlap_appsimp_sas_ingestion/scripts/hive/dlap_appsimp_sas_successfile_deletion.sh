#!/bin/bash

export JOB_NAME=$2

present=`pwd`
echo $present

source ../../conf/env/dlap_appsimp_sas_job_env_var.sh

yarn_app_id=`yarn application -list -appStates RUNNING|grep $JOB_NAME |awk '{print $1}'`
echo "Yarn app ID"
echo ${yarn_app_id}
pwd
present=`pwd`
echo $present
export strt_time=`date '+%Y-%m-%d %H:%M:%S'`

export table=${JOB_ENV}_appsimp_logs.appsimp_logs
export host_nm=`hostname -f`
export job_run_dt=`date '+%Y-%m-%d'`

success_file="*_success.txt"
echo "If success_file: ${JOB_SYNCSORT_SUCCESS_HDFS_DIR}${success_file} is present then it will be removed"
hadoop fs -test -f ${JOB_SYNCSORT_SUCCESS_HDFS_DIR}${success_file}

if [[ $? -eq 0 ]]
then
echo "As $success_file is present hence it will be removed"
hadoop fs -rm ${JOB_SYNCSORT_SUCCESS_HDFS_DIR}${success_file}
sync_suc_cd=$?
else
sync_suc_cd=0
fi


echo "If success_file: ${JOB_INGESTION_SUCCESS_HDFS_DIR}${success_file} is present then it will be removed"
hadoop fs -test -f ${JOB_INGESTION_SUCCESS_HDFS_DIR}${success_file}

if [[ $? -eq 0 ]]
then
echo "As $success_file is present hence it will be removed"
hadoop fs -rm ${JOB_INGESTION_SUCCESS_HDFS_DIR}${success_file}
ingstn_suc_cd=$?
else
ingstn_suc_cd=0
fi

if [[ ${sync_suc_cd} == 0 && ${ingstn_suc_cd} == 0 ]]; then
echo "As the SuccessFiles were removed Successfully, Hence exiting job with Success Status"
echo "Success in Removing SuccessFiles i.e., Syncsort SuccessFile, Ingestion SuccessFile"
echo  "${JOB_ENV} : SUCCESS - Syncsort Job ${JOB_NAME} SUCCESS .Message:As the Syncsort Job ${JOB_NAME} removed SuccessFiles Successfully, Hence exiting job with Success Status "|mailx -s "${JOB_ENV} : SUCCESS - Syncsort Job ${JOB_NAME} Success " -S smtp=smtp://smtp.bcbsma.com ${MAIL_LIST}
export end_tm=`date '+%Y-%m-%d %H:%M:%S'`
export insert_ts=`date '+%Y-%m-%d %H:%M:%S'`
kinit -k -t /home/`whoami`/.key csa01etl@BCBSMAMD.NET
#Logging Failure entry into appsimp_logs table
beeline --verbose=true --showHeader=false -u "$JOB_HIVE_BEELINE_URL;principal=$JOB_HIVE_BEELINE_PRINCIPAL;ssl=$JOB_HIVE_BEELINE_SSL;" -e "USE ${JOB_ENV}_appsimp_logs; \
SET hive.exec.dynamic.partition=true; \
SET hive.exec.dynamic.partition.mode=nonstrict; 
INSERT INTO ${table} partition (dmn,job_run_dt) \
VALUES ('${JOB_NAME}','${host_nm}','${yarn_app_id}','${strt_time}','${end_tm}', \
'','SUCCESS','As the Syncsort Job ${JOB_NAME} removed SuccessFiles Successfully, Hence exiting job with Success Status','${insert_ts}','${DMN_NAME}','${job_run_dt}');"
else
echo "Failure in Removing one of the SuccessFiles i.e., Syncsort SuccessFile or Ingestion SuccessFile"
echo  "${JOB_ENV} : FAILURE - Syncsort Job ${JOB_NAME} FAILURE .Message:As the Pyspark Job ${JOB_NAME} Failed in removing one of the  SuccessFiles i.e., Syncsort SuccessFile or Ingestion SuccessFile, Hence exiting job with Failure Status "|mailx -s "${JOB_ENV} : FAILURE - Syncsort Job ${JOB_NAME} Failed " -S smtp=smtp://smtp.bcbsma.com ${MAIL_LIST}
export end_tm=`date '+%Y-%m-%d %H:%M:%S'`
export insert_ts=`date '+%Y-%m-%d %H:%M:%S'`
kinit -k -t /home/`whoami`/.key csa01etl@BCBSMAMD.NET
#Logging Failure entry into appsimp_logs table
beeline --verbose=true --showHeader=false -u "$JOB_HIVE_BEELINE_URL;principal=$JOB_HIVE_BEELINE_PRINCIPAL;ssl=$JOB_HIVE_BEELINE_SSL;" -e "USE ${JOB_ENV}_appsimp_logs; \
SET hive.exec.dynamic.partition=true; \
SET hive.exec.dynamic.partition.mode=nonstrict; 
INSERT INTO ${table} partition (dmn,job_run_dt) \
VALUES ('${JOB_NAME}','${host_nm}','${yarn_app_id}','${strt_time}','${end_tm}', \
'','FAILURE','As the Pyspark Job ${JOB_NAME} Failed in removing one of the  SuccessFiles i.e., Syncsort SuccessFile or Ingestion SuccessFile, Hence exiting job with Failure Status','${insert_ts}','${DMN_NAME}','${job_run_dt}');"
fi
