#!/bin/bash

###############################################################################################################
#Script Name    : datapod_create_database.sh
#Description    : This Program is a Beeline Hive Shell Script to be used to create database in Hive using HQL
#Args           : 
#Author         : "Rakesh Munigala"
#Copyright      : "Copyright 2019, This Code is Developed for BCBSMA by IBM Under Datapod Porgram"
#Credits        : "Rakesh Munigala"
#Version        : "1.0"
#Maintainer     : "Rakesh Munigala"
#Email          : "rakesh.munigala@bcbsma.com"
#Usage          : ./datapod_create_database.sh
###############################################################################################################

SCRIPT_NAME="datapod_create_database.sh"

echo "User is "$USER

echo "User Home is "$HOME

source ../../conf/env/datapod_job_env_var.sh

BUILD_VERSION=`cat ../../make_version.txt | grep BUILD_VERSION | cut -d '=' -f 2`
INSTALL_VERSION=`cat ../../make_version.txt | grep INSTALL_VERSION | cut -d '=' -f 2`

if [[ $BUILD_VERSION == $INSTALL_VERSION ]]
then
	echo "Successfully Verified Build and Install Version"
else
	echo "Mismatched Build and Install Version"
	echo "Make Sure to Run the Build and Install Correctly"
	exit 1
fi

if [[ -z "$JOB_ENV" ]]
then
	echo "JOB_ENV(hyb|prd) needs to be set before running this script"
	exit 1
fi

if [[ -z "$JOB_HIVE_BEELINE_URL" ]]
then
	echo "JOB_HIVE_BEELINE_URL needs to be set before running this script"
	exit 1
fi

if [[ -z "$JOB_HIVE_BEELINE_PRINCIPAL" ]]
then
	echo "JOB_HIVE_BEELINE_PRINCIPAL needs to be set before running this script"
	exit 1
fi

if [[ -z "$JOB_HIVE_BEELINE_SSL" ]]
then
	echo "JOB_HIVE_BEELINE_SSL needs to be set before running this script"
	exit 1
fi

echo "Job Hive Beeline URL is: "$JOB_HIVE_BEELINE_URL
echo "Job Hive Beeline Principal is: "$JOB_HIVE_BEELINE_PRINCIPAL
echo "Job Hive Beeline SSL is: "$JOB_HIVE_BEELINE_SSL
echo "Job Environment is: "$JOB_ENV

echo "Staring to Execute HQL using Hive Beeline"

beeline --verbose=true --showHeader=false -u "$JOB_HIVE_BEELINE_URL;principal=$JOB_HIVE_BEELINE_PRINCIPAL;ssl=$JOB_HIVE_BEELINE_SSL;" -f datapod_create_database.hql
