"""datapod_insert_config_overwrite_util.py: This Program Reads Config Details and Insert into datapod_config and datapod_config_hstry table"""

__author__      = "Rakesh Munigala"
__copyright__   = "This Code is Developed for BCBSMA by IBM Under Datapod program"
__credits__     = ["Rakesh Munigala"]
__version__     = "1.0"
__maintainer__  = "Rakesh Munigala"
__email__       = "rakesh.munigala@bcbsma.com"

import os,sys,shutil,json,traceback,argparse,socket,time
from datetime import datetime
from dateutil.relativedelta import *

from pyspark.sql import SparkSession
from pyspark.sql.types import *
from pyspark.sql.functions import *

from shared import datapod_mail_util as mu
from shared import datapod_audit_update as au

class datapod_insert_config_overwrite_util:
	def __init__(self,spark,args):
		self.spark = spark
		self.env = args['env']
		self.dmn = args['dmn']
		self.temp_dir = args['temp_dir']
		self.args = args
		self.job_nm = spark.sparkContext.appName
		self.yarn_app_id = spark.sparkContext.applicationId
		self.start_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
		self.job_run_time = datetime.today().strftime('%Y-%m-%d-%H-%M-%S')
		self.host_nm = socket.getfqdn()
		self.from_mail = spark.sparkContext.sparkUser()
		self.log_file = args['log_file']
		self.logger = spark.sparkContext._jvm.org.apache.log4j.LogManager.getLogger(__name__)
	def run(self):
		self.logger.info('Started Running the Job: ' + self.job_nm)
		self.logger.info('Job is Running in Region: ' + self.env)
		self.logger.info('Job is Running for Domain: ' + self.dmn)
		self.logger.info('Job is Running on Hostname: ' + self.host_nm)
		self.logger.info('Job is using Temp Directory: ' + self.temp_dir)
		self.logger.info('Job Start Time: ' + self.start_time)
		self.logger.info('Job Yarn Application Id is: ' + self.yarn_app_id)
		self.logger.info('Job Log File Name is: ' + self.log_file)
		self.logger.info('Started Setting Job Level SparkConf')
		self.spark.conf.set("spark.sql.crossJoin.enabled", "true")
		self.spark.conf.set("spark.sql.shuffle.partitions", "4")
		self.spark.conf.set("hive.exec.dynamic.partition", "true")
		self.spark.conf.set("hive.exec.dynamic.partition.mode", "nonstrict")
		self.logger.info('Finished Setting Job Level SparkConf')
		
		if 'log_db_nm' in self.args:
			log_db_nm = self.args["log_db_nm"]
		self.logger.info('Log DB Name is: ' + log_db_nm)

		try:
			tgt_param_hstry_tbl = log_db_nm + ".datapod_config_hstry"
			tgt_param_tbl = log_db_nm + ".datapod_config"
			INSERT_DF = self.spark.sql("""
						SELECT
							dmn,job_nm,config,insert_ts
						FROM
						(
							SELECT
								dmn,job_nm,config,insert_ts,
								rank() over(partition by job_nm order by insert_ts desc) rank
							FROM
								{0}
						) A
						WHERE
							A.rank > 1""".format(tgt_param_tbl))
			INSERT_DF.write.insertInto(tgt_param_hstry_tbl,overwrite = False)
			self.logger.info('Successfully Inserted oldest entries into target table'+tgt_param_hstry_tbl)

			INSERT_OVERWRITE_DF = self.spark.sql("""
							SELECT
								dmn,job_nm,config,insert_ts
							FROM
							(
								SELECT
									*,
									rank() over(partition by job_nm order by insert_ts desc) rank
								FROM
									{0}
							) A
							WHERE
								A.rank = 1""".format(tgt_param_tbl))
			INSERT_CACHED = INSERT_OVERWRITE_DF.cache()	
			INSERT_CACHED.count()
			INSERT_OVERWRITE_RDD = INSERT_CACHED.rdd
			schema = StructType([StructField('dmn',StringType(),True),
							StructField('job_nm',StringType(),True),
							StructField('config',MapType(StringType(), StringType(), True), True),
							StructField('insert_ts', TimestampType(),True)])
			result = self.spark.createDataFrame(INSERT_OVERWRITE_RDD,schema)
			result.coalesce(1).write.insertInto(tgt_param_tbl,overwrite = True)
			self.logger.info('Successfully Inserted newest entries into target table'+tgt_param_tbl)
			self.logger.info('datapod Audit logs table will be updated with SUCCESS Status')
			au.set_success(self.spark,self.env,self.job_nm,self.host_nm,self.yarn_app_id,self.start_time,"",self.log_file,self.dmn)
			self.end_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
			self.logger.info('Job End Time is: ' + self.end_time)
			self.logger.info('Finished Executing the Job: ' + self.job_nm)
		except Exception as e:
			error = traceback.format_exc()
			self.logger.error('Received Error: ' + error)
			self.logger.info('datapod Audit logs table will be updated with FAILED Status')
			au.set_failed(self.spark,self.env,self.job_nm,self.host_nm,self.yarn_app_id,self.start_time,"",self.log_file,self.dmn)
			raise

def main(spark,**args):
	logger = spark.sparkContext._jvm.org.apache.log4j.LogManager.getLogger(__name__)
	obj =  datapod_insert_config_overwrite_util(spark,args)
	logger.info("Successfully Initialized the Pyspark Job: " + spark.sparkContext.appName)
	try:
		obj.run()
	except Exception as e:
		raise
