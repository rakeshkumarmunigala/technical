#!/bin/bash

###############################################################################################################
#Script Name    : datapod_oozie_submit.sh
#Description    : This Program is a Oozie Submit Script for submitting Oozie Jobs
#Args           : $JOB_TYPE $JOB_NAME
#Author         : "Rakesh Munigala"
#Copyright      : "Copyright 2019, This Code is Developed for BCBSMA by IBM Under Datapod Program"
#Credits        : "Rakesh Munigala"
#Version        : "1.0"
#Maintainer     : "Rakesh Munigala"
#Email          : "rakesh.munigala@bcbsma.com"
#Usage          : ./datapod_oozie_submit.sh wf datapod_blueview_interaction_file_ingestion
###############################################################################################################

SCRIPT_NAME="datapod_oozie_submit.sh"

echo "User is "$USER

echo "User Home is "$HOME

source ../../conf/env/datapod_job_env_var.sh

BUILD_VERSION=`cat ../../make_version.txt | grep BUILD_VERSION | cut -d '=' -f 2`
INSTALL_VERSION=`cat ../../make_version.txt | grep INSTALL_VERSION | tail -1 | cut -d '=' -f 2`

if [[ $BUILD_VERSION == $INSTALL_VERSION ]]
then
	echo "Successfully Verified Build and Install Version"
else
	echo "Mismatched Build and Install Version"
	echo "Make Sure to Run the Build and Install Correctly"
	exit 1
fi

if [[ -z "$JOB_ENV" ]]
then
	echo "Error: JOB_ENV(hyb|prd) needs to be set before running this script"
	exit 1
fi

if [[ -z "$JOB_DOMAIN" ]]
then
	echo "Error: JOB_DOMAIN needs to be set before running this script"
	exit 1
fi

if [[ -z "$JOB_OOZIE_URL" ]]
then
	echo "Error: JOB_OOZIE_URL needs to be set before running this script"
	exit 1
fi

if [[ -z "$JOB_NAMENODE_URL" ]]
then
	echo "Error: JOB_NAMENODE_URL needs to be set before running this script"
	exit 1
fi

JOB_TYPE=$1

JOB_NAME=$2

echo "Submitted JobType is: "$JOB_TYPE
echo "Job Oozie URL is: "$JOB_OOZIE_URL
echo "Job Namenode URL is: "$JOB_NAMENODE_URL
echo "Submitted JobName is: "$JOB_NAME
echo "Submitted JobDomain is: "$JOB_DOMAIN
echo "Job Environment is: "$JOB_ENV
echo "Job Optional Common Args are: "$JOB_COMMON_ARGS

if [[ $JOB_TYPE == wf ]]
then
	echo "Submitting the Oozie JobType "$JOB_TYPE
	oozie job -oozie $JOB_OOZIE_URL \
	-D user.home="$HOME" \
	-D datapod.job.namenode.url="$JOB_NAMENODE_URL" \
	-D datapod.job.tracker=yarnRM \
	-D datapod.job.path="$JOB_NAMENODE_URL"/user/"$USER"/datapod/"$JOB_ENV"/dist \
	-D oozie.wf.application.path="$JOB_NAMENODE_URL"/user/"$USER"/datapod/"$JOB_ENV"/dist/conf/oozie/workflow/datapod_shell_action_workflow.xml \
	-D datapod.job.name="$JOB_NAME" \
	-D datapod.job.dmn="$JOB_DOMAIN" \
	-D datapod.job.env="$JOB_ENV" \
	-D datapod.job.common.args="$JOB_COMMON_ARGS" \
	-D datapod.job.syncsort.success.hdfs.dir="$JOB_SYNCSORT_SUCCESS_HDFS_DIR" \
	-D datapod.job.spark.anaconda.path="$JOB_SPARK_ANACONDA_PYTHON" \
	-D datapod.job.spark.driver.memory="$JOB_SPARK_DRIVER_MEMORY" \
	-D datapod.job.spark.executory.memory="$JOB_SPARK_EXECUTOR_MEMORY" \
	-D datapod.job.spark.num.executors="$JOB_SPARK_NUM_EXECUTORS" \
	-D datapod.job.spark.executor.cores="$JOB_SPARK_EXECUTOR_CORES" \
	-D datapod.job.spark.driver.cores="$JOB_SPARK_DRIVER_CORES" \
	-D datapod.job.spark.yarn.maxAppAttempts="$JOB_SPARK_YARN_MAXAPPATTEMPTS" \
	-config ../../conf/oozie/jobs/"$JOB_NAME"_job.properties \
	-run
elif [[ $JOB_TYPE == coord ]]
then
	echo "Submitting the Oozie JobType "$JOB_TYPE
	if [ -f ../../conf/oozie/coordinator/"$JOB_NAME"_coordinator.xml ]
	then
		COORD_APP_NAME="$JOB_NAME"_coordinator.xml
	else
		COORD_APP_NAME=datapod_shell_action_coordinator.xml
	fi
	echo "Coord Application Name is: "$COORD_APP_NAME
	oozie job -oozie $JOB_OOZIE_URL \
	-D user.home="$HOME" \
	-D datapod.job.namenode.url="$JOB_NAMENODE_URL" \
	-D datapod.job.tracker=yarnRM \
	-D datapod.job.path="$JOB_NAMENODE_URL"/user/"$USER"/datapod/"$JOB_ENV"/dist \
	-D oozie.coord.application.path="$JOB_NAMENODE_URL"/user/"$USER"/datapod/"$JOB_ENV"/dist/conf/oozie/coordinator/"$COORD_APP_NAME" \
	-D datapod.job.name="$JOB_NAME" \
	-D datapod.job.dmn="$JOB_DOMAIN" \
	-D datapod.job.env="$JOB_ENV" \
	-D datapod.job.common.args="$JOB_COMMON_ARGS" \
	-D datapod.job.syncsort.success.hdfs.dir="$JOB_SYNCSORT_SUCCESS_HDFS_DIR" \
	-D datapod.job.spark.anaconda.path="$JOB_SPARK_ANACONDA_PYTHON" \
	-D datapod.job.spark.driver.memory="$JOB_SPARK_DRIVER_MEMORY" \
	-D datapod.job.spark.executory.memory="$JOB_SPARK_EXECUTOR_MEMORY" \
	-D datapod.job.spark.num.executors="$JOB_SPARK_NUM_EXECUTORS" \
	-D datapod.job.spark.executor.cores="$JOB_SPARK_EXECUTOR_CORES" \
	-D datapod.job.spark.driver.cores="$JOB_SPARK_DRIVER_CORES" \
	-D datapod.job.spark.yarn.maxAppAttempts="$JOB_SPARK_YARN_MAXAPPATTEMPTS" \
	-config ../../conf/oozie/jobs/"$JOB_NAME"_job.properties \
	-run
else
	echo "Error: Please Specify Correct Job Type [wf|coord]"
	exit 1
fi
