"""datapod_audit_update.py: This Program defines various subroutines for logging SUCCESS and FAILED Status of Job in Hive"""

__author__      = "Rakesh Munigala"
__copyright__   = "Copyright 2019, This Code is Developed for BCBSMA by IBM Under Datapod Program "
__credits__     = ["Rakesh Munigala"]
__version__     = "1.0"
__maintainer__  = "Rakesh Munigala"
__email__       = "rakesh.munigala@bcbsma.com"

import traceback

def set_success(spark,env,job_nm,host_nm,yarn_app_id,start_time,output_file,log_file,dmn):
	try:
		df = spark.sql("""
			SELECT
				'{0}' as job_nm,
				'{1}' as host_nm,
				'{2}' as yarn_app_id,
				'{3}' as start_time,
				current_timestamp as end_time,
				'{4}' as output_file,
				'SUCCESS' as job_stat,
				'{5}' as log_file,
				current_timestamp as insert_ts,
				'{6}'as domain,
				current_date as job_run_dt
			""".format(job_nm,host_nm,yarn_app_id,start_time,output_file,log_file,dmn))
		tbl_name = env + "_datapod_logs.datapod_logs"
		df.write.insertInto(tbl_name,overwrite = False)
	except Exception as e:
		raise

def set_failed(spark,env,job_nm,host_nm,yarn_app_id,start_time,output_file,log_file,dmn):
	try:
		df = spark.sql("""
			SELECT
				'{0}' as job_nm,
				'{1}' as host_nm,
				'{2}' as yarn_app_id,
				'{3}' as start_time,
				current_timestamp as end_time,
				'{4}' as output_file,
				'FAILED' as job_stat,
				'{5}' as log_file,
				current_timestamp as insert_ts,
				'{6}'as domain,
				current_date as job_run_dt
			""".format(job_nm,host_nm,yarn_app_id,start_time,output_file,log_file,dmn))
		tbl_name = env + "_datapod_logs.datapod_logs"
		df.write.insertInto(tbl_name,overwrite = False)
	except Exception as e:
		raise
