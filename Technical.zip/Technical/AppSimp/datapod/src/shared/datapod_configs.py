"""datapod_configs.py: This Program defines various subroutines for setting and getting params and configs values from Hive"""

__author__      = "Rakesh Munigala"
__copyright__   = "Copyright 2019, This Code is Developed for BCBSMA by IBM Under datapod Program "
__credits__     = ["Rakesh Munigala"]
__version__     = "1.0"
__maintainer__  = "Rakesh Munigala"
__email__       = "rakesh.munigala@bcbsma.com"

import traceback

def get_param(spark,env,job_nm):
	try:
		param = spark.sql("""
			SELECT
				param
			FROM
				{0}_datapod_logs.datapod_param
			WHERE
				job_nm = '{1}'
			ORDER BY insert_ts DESC
			""".format(env,job_nm)).collect()
		return param[0]['param']
	except Exception as e:
		raise


def get_config(spark,env,job_nm):
	try:
		config = spark.sql("""
			SELECT
				config
			FROM
				{0}_datapod_logs.datapod_config
			WHERE
				job_nm = '{1}'
			ORDER BY insert_ts DESC
			""".format(env,job_nm)).collect()
		return config[0]['config']
	except Exception as e:
		raise

def set_param(spark,env,dmn,job_nm,param):
	try:
		df = spark.sql("""
			SELECT
				'{0}' as dmn,
				'{1}' as job_nm,
				map{2} as param,
				current_timestamp as insert_ts
			""".format(dmn,job_nm,param))
		tbl_name = env + "_datapod_logs.datapod_param"
		df.write.insertInto(tbl_name,overwrite = False)
	except Exception as e:
		raise

def set_config(spark,env,dmn,job_nm,config):
	try:
		df = spark.sql("""
			SELECT
				'{0}' as dmn,
				'{1}' as job_nm,
				map{2} as config,
				current_timestamp as insert_ts
				""".format(dmn,job_nm,config))
		tbl_name = env + "_datapod_logs.datapod_config"
		df.write.insertInto(tbl_name,overwrite = False)
	except Exception as e:
		raise
