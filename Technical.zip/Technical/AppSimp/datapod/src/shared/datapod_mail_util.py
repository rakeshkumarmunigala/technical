"""datapod_mail_util.py: This Program defines subroutine for sending an email alert"""

__author__      = "Rakesh Munigala"
__copyright__   = "Copyright 2019, This Code is Developed for BCBSMA by IBM Under datapod Program"
__credits__     = ["Rakesh Munigala"]
__version__     = "1.0"
__maintainer__  = "Rakesh Munigala"
__email__       = "rakesh.munigala@bcbsma.com"

import os
import smtplib,socket
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import traceback

def send_mail(job_nm,from_mail,to_mail, mail_subject, mail_body):
	try:
		mail_header = """Hi All"""
		mail_trailer = """Thanks\n""" + job_nm
		mail_server = smtplib.SMTP('smtp.bcbsma.com')
		mail_from = from_mail + '@' + socket.getfqdn()
		mail_to = to_mail
		msg = MIMEMultipart()
		msg['To'] = ", ".join(mail_to)
		msg['From'] = mail_from
		msg['Subject'] = mail_subject
		mail_content = mail_header + "\n\n" + mail_body + "\n\n" +mail_trailer
		msg.attach(MIMEText(mail_content))
		mail_server.sendmail(mail_from,mail_to,msg.as_string())
		mail_server.quit()
	except Exception as e:
		raise
