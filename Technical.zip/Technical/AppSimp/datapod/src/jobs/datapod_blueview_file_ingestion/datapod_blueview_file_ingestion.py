"""datapod_blueview_file_ingestion.py: This Program Reads the Data from Source File and Ingest the Data into Hive Curate Table"""

__author__      = "Munigala Rakesh"
__copyright__   = "This Code is Developed for BCBSMA by IBM Under Datapod Program to ingest Blueview Interaction and Intent files to ODH"
__credits__     = ["Munigala Rakesh"]
__version__     = "1.0"
__maintainer__  = "Munigala Rakesh"
__email__       = "rakesh.munigala@bcbsma.com"

import os,sys,shutil,json,traceback,argparse,socket,time
from datetime import datetime
from dateutil.relativedelta import *
from enum import Enum

from pyspark.sql import SparkSession
from pyspark.sql.types import *
from pyspark.sql.functions import *
from py4j.java_gateway import java_import
from pyspark.sql.functions import lit

from shared import datapod_mail_util as mu
from shared import datapod_audit_update as au
from shared import datapod_sftp_util as tw
from shared import datapod_configs as cfg

class AuditValidationError(Exception):
	def __init__(self, value): 
		self.value = value 
	def __str__(self): 
		return(repr(self.value))

class DataValidationError(Exception): 
	def __init__(self, value): 
		self.value = value 
	def __str__(self): 
		return(repr(self.value))

class FileNotFoundError(Exception):
	def __init__(self, value):
		self.value = value	
	def __str__(self):
		return(repr(self.value))

class datapod_blueview_file_ingestion:
	def __init__(self,spark,args):
		java_import(spark._jvm, 'org.apache.hadoop.fs.Path')
		self.spark = spark
		self.env = args['env']
		self.dmn = args['dmn']
		self.temp_dir = args['temp_dir']
		self.args = args
		self.job_nm = spark.sparkContext.appName
		self.yarn_app_id = spark.sparkContext.applicationId
		self.start_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
		self.job_run_time = datetime.today().strftime('%Y-%m-%d-%H-%M-%S')
		self.host_nm = socket.getfqdn()
		self.hdfs_output_file = None 
		self.from_mail = spark.sparkContext.sparkUser()
		#self.intrctn_extrct_temp_table_view=None
		self.log_file = args['log_file']
		self.logger = spark.sparkContext._jvm.org.apache.log4j.LogManager.getLogger(__name__)
	def get_schema(self,schema_list,all_string = False):
		import operator
		schema_list = sorted(schema_list, key=lambda k: k["metadata"]["id"])
		schema_fields = []
		for col in schema_list:
			if all_string:
				schema_fields.append(StructField(col['name'], StringType(), True, col["metadata"]))
			else:
				if col['type'] == "STRING":
					schema_fields.append(StructField(col['name'], StringType(), True, col["metadata"]))
				elif col['type'] in ["INTEGER"]:
					schema_fields.append(StructField(col['name'], IntegerType(), True, col["metadata"]))
				elif col['type'] in ["LONG"]:
					schema_fields.append(StructField(col['name'], LongType(), True, col["metadata"]))
				elif col['type'] in ["DOUBLE"]:
					schema_fields.append(StructField(col['name'], DoubleType(), True, col["metadata"]))
				elif col['type'] == "TIMESTAMP":
					schema_fields.append(StructField(col['name'], DateType(), True, col["metadata"]))
		return StructType(schema_fields)
	def get_interaction_mapAndTrsformQuery(self,raw_schema_enum,curate_schema_enum,ingest_file_nm):
		mapAndTrsformQuery = """
			{0.interaction_id.name} as {1.intrctn_id.name},
			{0.interaction_type_descr.name} as {1.intrctn_type_descr.name},
			{0.entry_date_of_interaction.name} as {1.entry_dt_of_intrctn.name},
			{0.interaction_entry_user_id.name} as {1.intrctn_entry_user_id.name},
			{0.interaction_entry_user_name.name} as {1.intrctn_entry_user_nm.name},
			{0.interaction_entry_work_group.name} as {1.intrctn_entry_work_grp.name},
			{0.resolved_date_of_interaction.name} as {1.resolvd_dt_of_intrctn.name},
			{0.interaction_resolved_user_id.name} as {1.intrctn_resolvd_user_id.name},
			{0.interaction_resolved_user_name.name} as {1.intrctn_resolvd_user_nm.name},
			{0.interaction_resolved_work_group.name} as {1.intrctn_resolvd_work_grp.name},
			{0.contract_id.name} as {1.cntrct_id.name},
			{0.subscriber_name.name} as {1.sub_nm.name},
			{0.subscriber_state.name} as {1.sub_state.name},
			{0.member_id_in_focus.name} as {1.mem_id_in_focus.name},
			{0.member_name_in_focus.name} as {1.mem_nm_in_focus.name},
			{0.verified_contact_name.name} as {1.verified_cntct_nm.name},
			{0.contact_type.name} as {1.cntct_type.name},
			{0.interaction_account_name.name} as {1.intrctn_acct_nm.name},
			{0.interaction_account_number.name} as {1.intrctn_acct_nbr.name},
			{0.group_name.name} as {1.grp_nm.name},
			{0.group_number.name} as {1.grp_nbr.name},
			{0.interaction_uacc.name} as {1.intrctn_uacc.name},
			{0.interaction_uacc_description.name} as {1.intrctn_uacc_descr.name},
			{0.primary_reason_for_interaction.name} as {1.prmry_rsn_for_intrctn.name},
			{0.interaction_language.name} as {1.intrctn_lang.name},
			{0.description_of_issue.name} as {1.descr_of_issue.name},
			{0.description_of_resolution.name} as {1.descr_of_resolution.name},
			{0.corporate_received_date_time.name} as {1.corporate_received_dt_time.name},
			{0.source_for_non_live_interaction.name} as {1.src_for_non_live_intrctn.name},
			{0.reason_for_non_live_interaction.name} as {1.rsn_for_non_live_intrctn.name},
			{0.email.name} as {1.email.name},
			{0.interaction_duration.name} as {1.intrctn_drtn.name},
			{0.interaction_comments.name} as {1.intrctn_cmnts.name},
			{0.interaction_type.name} as {1.intrctn_typ.name},
			{0.channel.name} as {1.channel.name},
			{0.alert_type.name} as {1.alert_typ.name},
			{0.alert_level.name} as {1.alert_level.name},
			{0.alert_description.name} as {1.alert_descr.name},
			{0.alert_category.name} as {1.alert_cat.name},
			{0.alert_action.name} as {1.alert_actn.name},
			{0.plan_type.name} as {1.pln_typ.name},
			'{2}' as {1.file_nm.name},
			current_timestamp() as {1.load_timestamp.name},
			substr(split('{2}','_')[3],1,15) as {1.feed_dt.name}
			""".format(raw_schema_enum,curate_schema_enum,ingest_file_nm)
		return mapAndTrsformQuery
	def get_intent_mapAndTrsformQuery(self,raw_schema_enum,curate_schema_enum,ingest_file_nm):
		mapAndTrsformQuery = """
			{0.interaction_id.name} as {1.intrctn_id.name},
			{0.service_intent_id.name} as {1.svc_intent_id.name},
			{0.service_intent_type_description.name} as {1.svc_intent_type_descr.name},
			{0.entry_date_of_intent.name} as {1.entry_dt_of_intent.name},
			{0.entry_work_group.name} as {1.entry_work_grp.name},
			{0.resolved_date_of_intent.name} as {1.resolvd_dt_of_intent.name},
			{0.intent_resolved_user_id.name} as {1.intent_resolvd_user_id.name},
			{0.intent_resolved_user_name.name} as {1.intent_resolvd_user_nm.name},
			{0.intent_contract_id.name} as {1.intent_cntrct_id.name},
			{0.intent_member_id.name} as {1.intent_mem_id.name},
			{0.intent_account_name.name} as {1.intent_acct_nm.name},
			{0.intent_account_number.name} as {1.intent_acct_nbr.name},
			{0.intent_group_name.name} as {1.intent_grp_nm.name},
			{0.intent_group_number.name} as {1.intent_grp_nbr.name},
			{0.intent_uacc.name} as {1.intent_uacc.name},
			{0.intent_uacc_description.name} as {1.intent_uacc_descr.name},
			{0.claim_number.name} as {1.clm_nbr.name},
			{0.service_exception_scenario.name} as {1.svc_excep_scenario.name},
			{0.service_exception_reason.name} as {1.svc_excep_rsn.name},
			{0.type_of_response_to_customer.name} as {1.typ_of_resp_to_cust.name},
			{0.reason_for_callback.name} as {1.rsn_for_callback.name},
			{0.intent_benefit_category_discussed.name} as {1.intent_ben_cat_discussed.name},
			{0.intent_benefit_subcategory_discussed.name} as {1.intent_ben_subcat_discussed.name},
			{0.service_intent_comments.name} as {1.svc_intent_cmnts.name},
			{0.other_comments.name} as {1.other_cmnts.name},
			{0.date_document_request_sent_to_vendor.name} as {1.dt_dcmnt_req_snt_to_vndr.name},
			{0.document_code.name} as {1.dcmnt_cd.name},
			{0.member_received_bill.name} as {1.mem_received_bill.name},
			{0.advised_member_of_seep_process.name} as {1.advised_mem_of_seep_prcs.name},
			{0.leader_approval_received.name} as {1.leader_approv_received.name},
			{0.leader_name.name} as {1.leader_nm.name},
			{0.amount_asked_to_be_paid.name} as {1.amt_asked_to_be_paid.name},
			{0.applies_to_entire_claim.name} as {1.applies_to_entire_clm.name},
			{0.how_to_proceed_with_adjustment.name} as {1.how_to_proceed_with_adj.name},
			{0.final_reason_to_adjust.name} as {1.final_rsn_to_adj.name},
			{0.pcp_reason_for_change.name} as {1.pcp_rsn_for_chng.name},
			{0.chart_letter_delivery_method.name} as {1.chart_ltr_dlvry_mthd.name},
			{0.billing_cancel_reason.name} as {1.billing_cncl_rsn.name},
			{0.outbound_call_type.name} as {1.outbound_call_typ.name},
			{0.outbound_call_outcome.name} as {1.outbound_call_outcm.name},
			{0.third_party_type.name} as {1.third_party_typ.name},
			{0.initiating_team.name} as {1.initiating_team.name},
			{0.outbound_call_reason.name} as {1.outbound_call_rsn.name},
			{0.call_attempt.name} as {1.call_attempt.name},
			{0.interest.name} as {1.interest.name},
			{0.call_campaign_name.name} as {1.call_campaign_nm.name},
			{0.care_mgmt_category.name} as {1.care_mgmt_cat.name},
			{0.care_mgmt_subcategory.name} as {1.care_mgmt_subcat.name},
			{0.care_mgmt_engagement.name} as {1.care_mgmt_engagement.name},
			{0.rekeyed_claim_number.name} as {1.rekeyed_clm_num.name},
			{0.gsi_category.name} as {1.gsi_cat.name},
			{0.gsi_subcategory.name} as {1.gsi_subcat.name},
			{0.gsi_manager_approval.name} as {1.gsi_mgr_approv.name},
			{0.gsi_requestor_name.name} as {1.gsi_requestor_nm.name},
			{0.gsi_requestor_phone.name} as {1.gsi_requestor_ph.name},
			{0.gsi_requestor_address.name} as {1.gsi_requestor_addr.name},
			{0.gsi_requestor_relationship.name} as {1.gsi_requestor_rel.name},
			{0.gsi_physician_name.name} as {1.gsi_physn_nm.name},
			{0.gsi_physician_phone.name} as {1.gsi_physn_ph.name},
			{0.gsi_qualified_program.name} as {1.gsi_qualified_prgrm.name},
			{0.gsi_service_requested.name} as {1.gsi_svc_req.name},
			{0.gsi_diagnosis.name} as {1.gsi_diag.name},
			{0.gsi_medication.name} as {1.gsi_medication.name},
			{0.gsi_request_type.name} as {1.gsi_req_typ.name},
			{0.gsi_anoc_missing_materials.name} as {1.gsi_anoc_missing_mtrl.name},
			{0.gsi_do_not_contact_member.name} as {1.gsi_do_nt_cntct_mem.name},
			{0.gsi_plan_type.name} as {1.gsi_pln_typ.name},
			{0.gsi_correct_medicare_number.name} as {1.gsi_crct_medicare_num.name},
			{0.gsi_correct_part_a_eff_date.name} as {1.gsi_crct_part_a_eff_dt.name},
			{0.gsi_correct_part_b_eff_date.name} as {1.gsi_crct_part_b_eff_dt.name},
			{0.gsi_crossover_reason.name} as {1.gsi_crossover_rsn.name},
			{0.web_tracking_id.name} as {1.web_trk_id.name},
			{0.transaction_status.name} as {1.txn_stat.name},
			{0.transaction_date.name} as {1.txn_dt.name},
			'{2}' as {1.file_nm.name},
			current_timestamp() as {1.load_timestamp.name},
			substr(split('{2}','_')[3],1,15) as {1.feed_dt.name}
			""".format(raw_schema_enum,curate_schema_enum,ingest_file_nm)
		return mapAndTrsformQuery
	def run(self):
		input_trigger_list = None
		ingest_status = None
		tw_tgt_file_nm = None
		local_output_dir = self.temp_dir + "/"
		self.logger.info('Started Running the Job: ' + self.job_nm)
		self.logger.info('Job is Running in Region: ' + self.env)
		self.logger.info('Job is Running for Domain: ' + self.dmn)
		self.logger.info('Job is Running on Hostname: ' + self.host_nm)
		self.logger.info('Job is using Temp Directory: ' + self.temp_dir)
		self.logger.info('Job Start Time: ' + self.start_time)
		self.logger.info('Job Yarn Application Id is: ' + self.yarn_app_id)
		self.logger.info('Job Log File Name is: ' + self.log_file)
		self.logger.info('Started Setting Job Level SparkConf')
		self.spark.conf.set("spark.sql.crossJoin.enabled", "true")
		self.spark.conf.set("spark.sql.shuffle.partitions", "4")
		self.spark.conf.set("hive.exec.dynamic.partition", "true")
		self.spark.conf.set("hive.exec.dynamic.partition.mode", "nonstrict")
		self.logger.info('Finished Setting Job Level SparkConf')

		self.logger.info('Defining Data Validation Function')
		def data_validation(row,schema,zone):
			not_valid = []
			for i in range(len(schema.fields)):
				field = schema.fields[i]
				if zone == "raw":
					try:
						if str(field.dataType) == "StringType":
							data_type = "String"
							str(row[i])
						elif str(field.dataType) in ["IntegerType","LongType"]:
							data_type = "Integer"
							int(row[i])
						elif str(field.dataType) == "DoubleType":
							data_type = "Double"
							float(row[i])
					except Exception as e:
						not_valid.append(field.name + " : Expected " + data_type)
				elif zone == "curate":
					if str(field.dataType) == "StringType" and row[i] != None and not isinstance(row[i],str):
						not_valid.append(field.name + " : Expected String")
					elif str(field.dataType) in ["IntegerType","LongType"] and row[i] != None and not isinstance(row[i],int):
						not_valid.append(field.name + " : Expected Integer")
					elif str(field.dataType) == "DoubleType" and row[i] != None and not isinstance(row[i],float):
						not_valid.append(field.name + " : Expected Double")
			if len(not_valid) > 0:
				return (row,"isNotValid",not_valid)
			else:
				return (row,"isValid",not_valid)
		self.logger.info('Defined Data Validation Function')
		
		try:
			feed_cycle = self.args['feed_cycle']
			self.logger.info('Feed Cycle is: ' + feed_cycle)

			self.logger.info('Started Reading Job Configurations from Config Table')
			config = cfg.get_config(self.spark,self.env,self.job_nm)
			self.logger.info('Job Configurations Read from Config Table are: ' + json.dumps(config))
			staging_hdfs_dir = "/" + self.env + config["staging_hdfs_dir"]
			error_hdfs_dir = "/" + self.env + config["error_hdfs_dir"]
			schema_hdfs_dir = "/" + self.env + config["schema_hdfs_dir"]
			extract_hdfs_dir = config["extract_hdfs_dir"]
			interaction_extract_nm = config["interaction_extract_nm"]
			intent_extract_nm = config["intent_extract_nm"]
			tw_server = config["tw_server"]
			tw_user = config["tw_user"]
			tw_ascii_src_dir = config["tw_ascii_src_dir"]
			tw_outbound_dir = config["tw_outbound_dir"]
			tw_src_interaction_file_pattern = config["tw_src_interaction_file_pattern"]
			tw_src_interaction_audit_file_pattern = config["tw_src_interaction_audit_file_pattern"]
			tw_src_intent_file_pattern = config["tw_src_intent_file_pattern"]
			tw_src_intent_audit_file_pattern = config["tw_src_intent_audit_file_pattern"]
			error_business_mail_list = config['error_business_mail_list'].split(',')
			self.logger.info('Successfully Read Job Configurations from Config Table')

			self.logger.info('Staging HDFS Dir is: ' + staging_hdfs_dir)
			self.logger.info('Error HDFS Dir is: ' + error_hdfs_dir)
			self.logger.info('Source Schema HDFS Dir is: ' + schema_hdfs_dir)
			self.logger.info('Extract HDFS Dir is: ' + extract_hdfs_dir)
			self.logger.info('Interaction Extract File Name is: ' + interaction_extract_nm)
			self.logger.info('Intent Extract File Name is: ' + intent_extract_nm)
			self.logger.info('TW FTP Server is: ' + tw_server)
			self.logger.info('TW FTP User is: ' + tw_user)
			self.logger.info('TW FTP Source Dir is: ' + tw_ascii_src_dir)
			self.logger.info('TW Outbound Dir is: ' + tw_outbound_dir)
			self.logger.info('TW FTP Source Interaction File Name Pattern is: ' + tw_src_interaction_file_pattern)
			self.logger.info('TW FTP Source Interaction Audit File Name Pattern is: ' + tw_src_interaction_audit_file_pattern)
			self.logger.info('TW FTP Source Intent File Name Pattern is: ' + tw_src_intent_file_pattern)
			self.logger.info('TW FTP Source Intent Audit File Name Pattern is: ' + tw_src_intent_audit_file_pattern)
			

			fs = self.spark._jvm.org.apache.hadoop.fs.FileSystem.get(self.spark._jsc.hadoopConfiguration())
			try:
				if 'tw_id_file' in self.args or 'tw_password' in self.args:
					self.logger.info('Downloading Source Ingestion File from TW FTP Server at Location: ' + tw_ascii_src_dir)
					if 'tw_id_file' in self.args:
						tw_id = self.args['tw_id_file']
						tw_tgt_interaction_file_nm = tw.download_file(self.spark,tw_server,tw_user,tw_ascii_src_dir,local_output_dir,tw_src_interaction_file_pattern,identity=tw_id)
						tw_tgt_interaction_audit_file_nm = tw.download_file(self.spark,tw_server,tw_user,tw_ascii_src_dir,local_output_dir,tw_src_interaction_audit_file_pattern,identity=tw_id)
						tw_tgt_intent_file_nm = tw.download_file(self.spark,tw_server,tw_user,tw_ascii_src_dir,local_output_dir,tw_src_intent_file_pattern,identity=tw_id)
						tw_tgt_intent_audit_file_nm = tw.download_file(self.spark,tw_server,tw_user,tw_ascii_src_dir,local_output_dir,tw_src_intent_audit_file_pattern,identity=tw_id)
					elif 'tw_password' in self.args:
						tw_pass = self.args['tw_password']
						tw_tgt_interaction_file_nm = tw.download_file(self.spark,tw_server,tw_user,tw_ascii_src_dir,local_output_dir,tw_src_interaction_file_pattern,password=tw_pass)
						tw_tgt_interaction_audit_file_nm = tw.download_file(self.spark,tw_server,tw_user,tw_ascii_src_dir,local_output_dir,tw_src_interaction_audit_file_pattern,password=tw_pass)
						tw_tgt_intent_file_nm = tw.download_file(self.spark,tw_server,tw_user,tw_ascii_src_dir,local_output_dir,tw_src_intent_file_pattern,password=tw_pass)
						tw_tgt_intent_audit_file_nm = tw.download_file(self.spark,tw_server,tw_user,tw_ascii_src_dir,local_output_dir,tw_src_intent_audit_file_pattern,password=tw_pass)
			except Exception as e:
				self.logger.info('Failed to Download Source Ingestion/Audit File from TW FTP Server')
				raise

			if (tw_tgt_interaction_file_nm == None or
				tw_tgt_interaction_audit_file_nm == None or
				tw_tgt_intent_file_nm == None or
				tw_tgt_intent_audit_file_nm == None):
				raise(FileNotFoundError("Source Ingestion File/Audit File from TW FTP Server Not Found"))
			else:
				self.logger.info('Successfully Downloaded Source Ingestion File from TW FTP Server with File Name: ' + tw_tgt_interaction_file_nm)
				self.logger.info('Successfully Downloaded Source Ingestion File from TW FTP Server with File Name: ' + tw_tgt_interaction_audit_file_nm)
				self.logger.info('Successfully Downloaded Source Ingestion File from TW FTP Server with File Name: ' + tw_tgt_intent_file_nm)
				self.logger.info('Successfully Downloaded Source Ingestion File from TW FTP Server with File Name: ' + tw_tgt_intent_audit_file_nm)


			self.logger.info('Started writing Source Ingestion Files and Audit files from Local to HDFS Staging Directory: ' + staging_hdfs_dir)
			local_ingest_interaction_file_path = local_output_dir + tw_tgt_interaction_file_nm
			local_ingest_interaction_audit_file_path = local_output_dir + tw_tgt_interaction_audit_file_nm
			local_ingest_intent_file_path = local_output_dir + tw_tgt_intent_file_nm
			local_ingest_intent_audit_file_path = local_output_dir + tw_tgt_intent_audit_file_nm
			fs.copyFromLocalFile(self.spark.sparkContext._jvm.Path(local_ingest_interaction_file_path),self.spark.sparkContext._jvm.Path(staging_hdfs_dir))
			fs.copyFromLocalFile(self.spark.sparkContext._jvm.Path(local_ingest_interaction_audit_file_path),self.spark.sparkContext._jvm.Path(staging_hdfs_dir))
			fs.copyFromLocalFile(self.spark.sparkContext._jvm.Path(local_ingest_intent_file_path),self.spark.sparkContext._jvm.Path(staging_hdfs_dir))
			fs.copyFromLocalFile(self.spark.sparkContext._jvm.Path(local_ingest_intent_audit_file_path),self.spark.sparkContext._jvm.Path(staging_hdfs_dir))
			self.logger.info('Finished writing Source Ingestion Files and Audit Files from Local to HDFS Staging Directory')

			self.logger.info('Reading Feed Date from Local Ingest File Name')
			interaction_feed_dt = local_ingest_interaction_file_path.split("/")[-1].split("_")[3][:15]
			interaction_audit_feed_dt = local_ingest_interaction_file_path.split("/")[-1].split("_")[3][:15]
			intent_feed_dt = local_ingest_intent_file_path.split("/")[-1].split("_")[3][:15]
			intent_audit_feed_dt = local_ingest_intent_file_path.split("/")[-1].split("_")[3][:15]
			feed_mnth= ""
			self.logger.info('Feed Date from Local Ingest Interaction File Name is: ' + interaction_feed_dt)
			self.logger.info('Feed Date from Local Ingest Interaction File Name is: ' + interaction_audit_feed_dt)
			self.logger.info('Feed Date from Local Ingest intent File Name is: ' + intent_feed_dt)
			self.logger.info('Feed Date from Local Ingest intent File Name is: ' + intent_audit_feed_dt)
			
			self.logger.info('Audit Check Started')
			auditintrctncnt=self.spark.read.text(staging_hdfs_dir + tw_tgt_interaction_audit_file_nm)
			auditintentncnt=self.spark.read.text(staging_hdfs_dir + tw_tgt_intent_audit_file_nm)
			intrctnfile=self.spark.read.option("delimiter",",").option("header", "true").csv(staging_hdfs_dir + tw_tgt_interaction_file_nm)
			intentfile=self.spark.read.option("delimiter",",").option("header", "true").csv(staging_hdfs_dir + tw_tgt_intent_file_nm)
			
			intrctnfilecnt=intrctnfile.count()
			intentfilecnt=intentfile.count()
			
			auditintrctncnt = auditintrctncnt.withColumn("cnt",trim(auditintrctncnt["value"]))
			auditintentncnt = auditintentncnt.withColumn("cnt",trim(auditintentncnt["value"]))
			auditintrctnmatchcnt=auditintrctncnt.where(auditintrctncnt['cnt'] == intrctnfilecnt).count()
			auditintentmatchcnt=auditintentncnt.where(auditintentncnt['cnt'] == intentfilecnt).count()
			self.logger.info('auditintrctnmatchcnt Value: ' + str(auditintrctnmatchcnt))
			self.logger.info('auditintentmatchcnt Value: ' + str(auditintentmatchcnt))
			
			try:
				if auditintrctnmatchcnt != 1 and auditintentmatchcnt != 1:
					content_msg = "BLUEVIEW AUDIT CHECK FAILED FOR AUDIT FILES" + ':' + tw_tgt_interaction_audit_file_nm + ',' + tw_tgt_intent_audit_file_nm
					mu.send_mail(self.job_nm,'bcbsma_datapod_prod',error_business_mail_list,\
								'ODH BLUEVIEW AUDIT CHECK FAILED ',content_msg)
					raise(AuditValidationError("Audit Check Failed for Interaction and Intent Files"))
				else:
						if auditintrctnmatchcnt != 1:
							content_msg = "BLUEVIEW AUDIT CHECK FAILED FOR AUDIT FILE" + ':' + tw_tgt_interaction_audit_file_nm
							mu.send_mail(self.job_nm,'bcbsma_datapod_prod',error_business_mail_list,\
										'ODH BLUEVIEW AUDIT CHECK FAILED ',content_msg)
							raise(AuditValidationError("Audit Check Failed for Interaction File"))
						
						if auditintentmatchcnt != 1:
							content_msg = "BLUEVIEW AUDIT CHECK FAILED FOR AUDIT FILE" + ':' + tw_tgt_intent_audit_file_nm
							mu.send_mail(self.job_nm,'bcbsma_datapod_prod',error_business_mail_list,\
										'ODH BLUEVIEW AUDIT CHECK FAILED ',content_msg)
							raise(AuditValidationError("Audit Check Failed for Intent File"))
			except Exception as e:
				self.logger.info('Failed to send the email for Blueview Audit Check')
				raise 

			self.logger.info('Audit Check Completed')


			self.logger.info('Connecting to HiveServer2 using JDBC')
			java_import(self.spark._jvm, 'org.apache.hive.jdbc.HiveDriver')
			driver = self.spark.sparkContext._jvm.HiveDriver()
			hive2_jdbc_url = self.args['hive2_jdbc_url']
			hive2_jdbc_principal = self.args['hive2_jdbc_principal']
			hive2_jdbc_ssl = self.args['hive2_jdbc_ssl']
			hive2_jdbc_connect_url = hive2_jdbc_url +";principal="+ hive2_jdbc_principal + ";ssl=" + hive2_jdbc_ssl + ";"
			self.logger.info('Hive2 JDBC CONNECT URL is ' + hive2_jdbc_connect_url)
			conn = driver.connect(hive2_jdbc_connect_url,self.spark.sparkContext._jvm.java.util.Properties())
			stmt = conn.createStatement()
			self.logger.info('Successfully Connected to HiveServer2 using JDBC')

			self.logger.info('Trying to Ingest the Nasco interaction File with Feed Date: ' + interaction_feed_dt)
			self.logger.info('Trying to Ingest the Nasco intent File with Feed Date: ' + intent_feed_dt)
			

			input_trigger_list = [	(tw_tgt_interaction_file_nm, "schema_blueview_intrctn_extrct.json"),
									(tw_tgt_intent_file_nm, "schema_blueview_intent_extrct.json")]

			self.logger.info('Validating if all the Input Trigger File Exists')
			fs = self.spark._jvm.org.apache.hadoop.fs.FileSystem.get(self.spark._jsc.hadoopConfiguration())
			for ingest_file_nm,schema_file_nm in input_trigger_list:
				try:
					fs.getFileStatus(self.spark.sparkContext._jvm.Path(staging_hdfs_dir + ingest_file_nm))
				except Exception as e:
					self.logger.info('Input Ingest Trigger File Does Not Exists: ' + ingest_file_nm)
					raise
				try:
					fs.getFileStatus(self.spark.sparkContext._jvm.Path(schema_hdfs_dir + schema_file_nm))
				except Exception as e:
					self.logger.info('Input Schema Trigger File Does Not Exists: ' + schema_file_nm)
					raise
			self.logger.info('Validation of Input Trigger File Done Successfully')

			ingest_status = {}

			for ingest_file_nm,schema_file_nm in input_trigger_list:
				ingest_status[ingest_file_nm] = {'ParquetWrite': 'FAILED','AlterQuery': 'FAILED','RawMove': 'FAILED'}
				ingest_status[ingest_file_nm]['staging_hdfs_dir'] = staging_hdfs_dir

				self.logger.info('Ingestion File Name is ' + ingest_file_nm)
				self.logger.info('Source Schema File Name is ' + schema_file_nm)

				self.logger.info('Started Reading the Schema File')
				jsonSchema_0 = self.spark.read.text(schema_hdfs_dir + schema_file_nm)
				jsonSchema = jsonSchema_0.rdd.map(lambda l: (1,l.value)).groupByKey().map(lambda l: "".join(list(l[1]))).collect()
				dataset = json.loads(jsonSchema[0])
				curate_table_name = dataset["name"]
				curate_db_name = self.env + "_curate_" + dataset["business_domain"]
				curate_hdfs_dir= "/" + self.env + "/curate/" + dataset["business_domain"] + "/" + dataset["name"] + "/"
				ingest_status[ingest_file_nm]['curate_hdfs_dir'] = curate_hdfs_dir
				raw_hdfs_dir = "/" + self.env +"/raw/"+ dataset["business_domain"] +"/" + dataset["source_system_code"] +"/"+ dataset["name"] +"/"
				ingest_status[ingest_file_nm]['raw_hdfs_dir'] = raw_hdfs_dir
				partition_keys_list = dataset["partition_keys"]
				raw_schema_list = dataset["raw_schema"]
				curate_schema_list = dataset["curate_schema"]
				self.logger.info('Successfully Read the Schema File')

				self.logger.info('Curate DB Name is ' + curate_db_name)
				self.logger.info('Curate Table Name is ' + curate_table_name)
				self.logger.info('Curate HDFS Directory is ' + curate_hdfs_dir)
				self.logger.info('Curate DB Name is ' + curate_db_name)
				self.logger.info('Raw HDFS Directory is ' + raw_hdfs_dir)

				self.logger.info('Get Raw Schema and Raw Schema Enum')
				raw_schema = self.get_schema(raw_schema_list)
				raw_string_schema = self.get_schema(raw_schema_list,all_string = True)
				raw_schema_enum = Enum('raw_schema_enum',[c.name for c in raw_schema.fields],start=0)
				self.logger.info('Successfully Got Raw Schema, Raw String Schema and Raw Schema Enum')

				self.logger.info('Get Curate Schema and Curate Schema Enum')
				curate_schema = self.get_schema(curate_schema_list)
				curate_schema_enum = Enum('curate_schema_enum',[c.name for c in curate_schema.fields],start=0)
				self.logger.info('Successfully Got Curate Schema and Curate Schema Enum')

				#self.logger.info('Raw Schema are ' + raw_schema)
				#self.logger.info('Curate Schema are ' + curate_schema)
				partition_columns = partition_keys_list
				self.logger.info('Curate Table Partitioning Columns are ' + "".join(partition_columns))

				raw_temp_table_view = "raw_temp_view_" + curate_table_name
				self.logger.info('Raw Temp Table View is: ' + raw_temp_table_view)

				curate_temp_table_view = "curate_temp_view_" + curate_table_name
				self.logger.info('Curate Temp Table View is: ' + curate_temp_table_view)

				self.logger.info('Creating Mapping and Transformation Query')

				if schema_file_nm == "schema_blueview_intrctn_extrct.json":
					mapAndTrsformQuery = self.get_interaction_mapAndTrsformQuery(raw_schema_enum,curate_schema_enum,ingest_file_nm)
					
				if schema_file_nm == "schema_blueview_intent_extrct.json":
					mapAndTrsformQuery = self.get_intent_mapAndTrsformQuery(raw_schema_enum,curate_schema_enum,ingest_file_nm)


				self.logger.info('Map and Transform Query is: ' + mapAndTrsformQuery)

				self.logger.info('Reading Ingest File From Staging HDFS Directory')
				A = self.spark.read.option("delimiter",",").option("header", "true").schema(raw_string_schema).csv(staging_hdfs_dir + ingest_file_nm)
				self.logger.info('Read Ingest File From Staging HDFS Directory')
				
				self.logger.info('Getting Valid data from Ingest file')
				if schema_file_nm == "schema_blueview_intrctn_extrct.json":
					validbluedata = A.dropDuplicates(subset = ['interaction_id']).where(A["interaction_id"].isNotNull() & A["entry_date_of_interaction"].isNotNull() & A["interaction_entry_user_id"].isNotNull())

				if schema_file_nm == "schema_blueview_intent_extrct.json":
					validbluedata = A.dropDuplicates(subset = ['service_intent_id']).where(A["service_intent_id"].isNotNull() & A["entry_date_of_intent"].isNotNull())

				self.logger.info('Started Doing Data Validation on Raw Ingest File')
				B = validbluedata.rdd.map(lambda row: data_validation(row,raw_schema,"raw"))
				notValidCount = B.filter(lambda row: row[1] == "isNotValid").count()
				if notValidCount != 0:
					self.logger.info('Data Validation on Raw Ingest File Failed')
					self.logger.info('Number of Records Failed Raw Data Validation is: ' + str(notValidCount))
					error_file_name = error_hdfs_dir + ingest_file_nm
					B.filter(lambda row: row[1] == "isNotValid").saveAsTextFile(error_hdfs_dir +"RAW_"+ ingest_file_nm)
					self.logger.info('Bad Records Written in Error File: ' + error_hdfs_dir +"RAW_"+ ingest_file_nm)
					self.logger.info('Aborting Ingest Process')
					raise(DataValidationError("Raw Data Validation Failed"))
				else:
					self.logger.info('Data Validation on Raw Ingest File Succeeded')

				self.logger.info('Creating Raw Data Frame by Applying Raw Schema')
				C = self.spark.read.option("delimiter",",").option("header", "true").schema(raw_schema).csv(staging_hdfs_dir + ingest_file_nm)
				
				self.logger.info('Filtering Duplicate records and doing data validations from Ingest file')
				if schema_file_nm == "schema_blueview_intrctn_extrct.json":
					validbluedata1 = C.dropDuplicates(subset = ['interaction_id']).where(C["interaction_id"].isNotNull() & C["entry_date_of_interaction"].isNotNull() & C["interaction_entry_user_id"].isNotNull())

				if schema_file_nm == "schema_blueview_intent_extrct.json":
					validbluedata1 = C.dropDuplicates(subset = ['service_intent_id']).where(C["service_intent_id"].isNotNull() & C["entry_date_of_intent"].isNotNull())
				
				if schema_file_nm == "schema_blueview_intrctn_extrct.json":				
					self.logger.info('Getting Duplicate records from Ingest file to write into Error File')
					validbluedata2 = C.where(C["interaction_id"].isNotNull() & C["entry_date_of_interaction"].isNotNull() & C["interaction_entry_user_id"].isNotNull())
					duplicatedata = validbluedata2.groupBy("interaction_id").agg(count(lit(1)).alias("cnt")).filter(col("cnt")>1)
					validbluedata1 = validbluedata1.alias('validbluedata1')
					duplicatedata = duplicatedata.alias('duplicatedata')
					duplicaterows = validbluedata1.join(duplicatedata, validbluedata1.interaction_id == duplicatedata.interaction_id).select(validbluedata1["*"])
					duplicaterows = duplicaterows.withColumn("error_description",lit('DUPLICATE INTERACTION ID'))

					self.logger.info('Getting InValid data from Ingest file to write into Error File')
					invalidbluedata = C.where(C["interaction_id"].isNull() | C["entry_date_of_interaction"].isNull() | C["interaction_entry_user_id"].isNull())
					invalidbluedata = invalidbluedata.withColumn("error_description",when(invalidbluedata["interaction_id"].isNull(), "INTERACTION ID IS BLANK").when(invalidbluedata["entry_date_of_interaction"].isNull(), "ENTRY DATE OF INTERACTION IS BLANK").when(invalidbluedata["interaction_entry_user_id"].isNull(), "INTERACTION ENTRY USER ID IS BLANK"))
					interactionerrordata = duplicaterows.union(invalidbluedata)

				if schema_file_nm == "schema_blueview_intent_extrct.json":				
					self.logger.info('Getting Duplicate records from Ingest file to write into Error File')
					validbluedata2 = C.where(C["service_intent_id"].isNotNull() & C["entry_date_of_intent"].isNotNull())
					duplicatedata = validbluedata2.groupBy("service_intent_id").agg(count(lit(1)).alias("cnt")).filter(col("cnt")>1)
					validbluedata1 = validbluedata1.alias('validbluedata1')
					duplicatedata = duplicatedata.alias('duplicatedata')
					duplicaterows = validbluedata1.join(duplicatedata, validbluedata1.service_intent_id == duplicatedata.service_intent_id).select(validbluedata1["*"])
					duplicaterows = duplicaterows.withColumn("error_description",lit('DUPLICATE SERVICE INTENT ID'))

					self.logger.info('Getting InValid data from Ingest file to write into Error File')
					invalidbluedata = C.where(C["service_intent_id"].isNull() | C["entry_date_of_intent"].isNull())
					invalidbluedata = invalidbluedata.withColumn("error_description",when(invalidbluedata["service_intent_id"].isNull(), "SERVICE INTENT ID IS BLANK").when(invalidbluedata["entry_date_of_intent"].isNull(), "ENTRY DATE OF INTENT IS BLANK"))
					intenterrordata = duplicaterows.union(invalidbluedata)
					
				validbluedata1.createOrReplaceTempView(raw_temp_table_view)
				self.logger.info('Created Raw Data Frame Successfully')

				self.logger.info('Applying Curate Mapping and Transformation on Raw Data Frame')
				E = self.spark.sql("""SELECT {0} FROM {1}""".format(mapAndTrsformQuery,raw_temp_table_view))
			
				self.logger.info('Started Doing Data Validation on Curate Data Frame')
				F = E.rdd.map(lambda row: data_validation(row,curate_schema,"curate"))
				notValidCount = F.filter(lambda row: row[1] == "isNotValid").count()
				if notValidCount != 0:
					self.logger.info('Data Validation on Curate Data Frame Failed')
					self.logger.info('Number of Records Failed Curate Data Validation is: ' + str(notValidCount))
					self.logger.info('Aborting Ingest Process')
					F.filter(lambda row: row[1] == "isNotValid").saveAsTextFile(error_hdfs_dir +"CURATE_"+ ingest_file_nm)
					self.logger.info('Bad Records Written in Error File: ' + error_hdfs_dir +"CURATE_"+ ingest_file_nm)
					raise(DataValidationError("Curate Data Validation Failed"))
				else:
					self.logger.info('Data Validation on Curate Data Frame Succeeded')

				E.createOrReplaceTempView(curate_temp_table_view)
				#self.logger.info('The Curate Data are: ' + E.show(truncate=False))

				try:
					self.logger.info('Writting Curate Data to Parquet File')
					E.write.mode("append").partitionBy(partition_columns).parquet(curate_hdfs_dir)
					df_E=self.spark.sql("""SELECT cast(count(*) as STRING) FROM {0}""".format(curate_temp_table_view))
					self.extract_dt = (datetime.now().strftime('%m-%d-%Y'))
					if schema_file_nm == "schema_blueview_intrctn_extrct.json":
					
						self.interaction_hdfs_output_dir = "/" + self.env + extract_hdfs_dir + interaction_extract_nm + "/" + self.job_run_time + "/"
						self.interaction_hdfs_output_file = self.interaction_hdfs_output_dir + interaction_extract_nm + self.extract_dt + ".csv"
						self.interaction_hdfs_output_audit_file = self.interaction_hdfs_output_dir + interaction_extract_nm + self.extract_dt + ".aud"
					
						df_E.coalesce(1).write.text(self.interaction_hdfs_output_dir)
						part_file = fs.globStatus(self.spark.sparkContext._jvm.Path(self.interaction_hdfs_output_dir +'/' + 'part-*'))[0].getPath().getName()
						fs.rename(
								self.spark.sparkContext._jvm.Path(self.interaction_hdfs_output_dir + part_file),
								self.spark.sparkContext._jvm.Path(self.interaction_hdfs_output_audit_file))
						
						E.coalesce(1).write.option("header", "true").csv(self.interaction_hdfs_output_dir)
						part_file = fs.globStatus(self.spark.sparkContext._jvm.Path(self.interaction_hdfs_output_dir +'/' + 'part-*'))[0].getPath().getName()
						fs.rename(
								self.spark.sparkContext._jvm.Path(self.interaction_hdfs_output_dir + part_file),
								self.spark.sparkContext._jvm.Path(self.interaction_hdfs_output_file))
								
					if schema_file_nm == "schema_blueview_intent_extrct.json":
					
						self.intent_hdfs_output_dir = "/" + self.env + extract_hdfs_dir + intent_extract_nm + "/" + self.job_run_time + "/"
						self.intent_hdfs_output_file = self.intent_hdfs_output_dir + intent_extract_nm + self.extract_dt + ".csv"
						self.intent_hdfs_output_audit_file = self.intent_hdfs_output_dir + intent_extract_nm + self.extract_dt + ".aud"
					
						df_E.coalesce(1).write.text(self.intent_hdfs_output_dir)
						part_file = fs.globStatus(self.spark.sparkContext._jvm.Path(self.intent_hdfs_output_dir +'/' + 'part-*'))[0].getPath().getName()
						fs.rename(
								self.spark.sparkContext._jvm.Path(self.intent_hdfs_output_dir + part_file),
								self.spark.sparkContext._jvm.Path(self.intent_hdfs_output_audit_file))
						
						E.coalesce(1).write.option("header", "true").csv(self.intent_hdfs_output_dir)
						part_file = fs.globStatus(self.spark.sparkContext._jvm.Path(self.intent_hdfs_output_dir +'/' + 'part-*'))[0].getPath().getName()
						fs.rename(
								self.spark.sparkContext._jvm.Path(self.intent_hdfs_output_dir + part_file),
								self.spark.sparkContext._jvm.Path(self.intent_hdfs_output_file))
						
			
					final_error_hdfs_dir = error_hdfs_dir + dataset["source_system_code"] +"/"  + ingest_file_nm
					if schema_file_nm == "schema_blueview_intrctn_extrct.json":	
						interactionerrordata.coalesce(1).write.option("header", "true").csv(final_error_hdfs_dir)	
					if schema_file_nm == "schema_blueview_intent_extrct.json":	
						intenterrordata.coalesce(1).write.option("header", "true").csv(final_error_hdfs_dir)	
					
					if schema_file_nm == "schema_blueview_intrctn_extrct.json":	
						notValidData = interactionerrordata.count()
					if schema_file_nm == "schema_blueview_intent_extrct.json":	
						notValidData = intenterrordata.count()
					self.logger.info('Number of Records failed in BLUEVIEW Data Validation is: ' + str(notValidData))
					if notValidData != 0:
						self.logger.info('Copying ERROR File FROM HDFS into Local Directory')
						part_file = fs.globStatus(self.spark.sparkContext._jvm.Path(final_error_hdfs_dir +'/' + 'part-*'))[0].getPath().getName()
						fs.rename(
								self.spark.sparkContext._jvm.Path(final_error_hdfs_dir +'/' + part_file),
								self.spark.sparkContext._jvm.Path(final_error_hdfs_dir +'/' + "ERROR_"+ ingest_file_nm))
						self.logger.info('copying the file to Local in' + final_error_hdfs_dir +'/'+ "ERROR_" + ingest_file_nm +'/' )
						fs.copyToLocalFile(
								self.spark.sparkContext._jvm.Path(final_error_hdfs_dir +'/' + "ERROR_"+ ingest_file_nm),
								self.spark.sparkContext._jvm.Path(local_output_dir))
						self.logger.info('Copied ERROR File FROM HDFS into Local Directory' + final_error_hdfs_dir +'/'+ "ERROR_" + ingest_file_nm +'/')
						
						tw_error_source_dir = local_output_dir
						tw_error_destintion_dir = tw_ascii_src_dir + "Inbound/Error_Files/"
						tw_error_tgt_file_nm = "ERROR_"+ ingest_file_nm
											
						try:
							if 'tw_id_file' in self.args or 'tw_password' in self.args:
								self.logger.info('Uploading Error File to TW FTP Server at Location: ' + tw_error_destintion_dir)
								if 'tw_id_file' in self.args:
									tw_id = self.args['tw_id_file'] 
									tw_error_tgt_file_nm = tw.upload_file(self.spark,tw_server,tw_user,tw_error_source_dir,tw_error_destintion_dir,tw_error_tgt_file_nm,identity=tw_id)
								elif 'tw_password' in self.args:
									tw_pass = self.args['tw_password']
									tw_error_tgt_file_nm = tw.upload_file(self.spark,tw_server,tw_user,tw_error_source_dir,tw_error_destintion_dir,tw_error_tgt_file_nm,password=tw_pass)
						except Exception as e:
							self.logger.info('Failed to Upload Error file to TW FTP Server')
							raise
							
						try:
							if schema_file_nm == "schema_blueview_intrctn_extrct.json":	
								content_msg = "BLUEVIEW INTERACTION ERROR FILE" + ':' + tw_error_destintion_dir + "ERROR_" + ingest_file_nm
								mu.send_mail(self.job_nm,'bcbsma_datapod_prod',error_business_mail_list,\
											'BLUEVIEW ERROR FILE NOTIFICATION ',content_msg)
							if schema_file_nm == "schema_blueview_intent_extrct.json":	
								content_msg = "BLUEVIEW INTENT ERROR FILE" + ':' + tw_error_destintion_dir + "ERROR_" + ingest_file_nm
								mu.send_mail(self.job_nm,'bcbsma_datapod_prod',error_business_mail_list,\
											'BLUEVIEW ERROR FILE NOTIFICATION ',content_msg)
						except Exception as e:
							self.logger.info('Failed to send the email for Blueview Error Files')
							raise 

					else:
						self.logger.info('NO ERROR RECORDS')
					
					ingest_status[ingest_file_nm]['ParquetWrite'] = 'SUCCESS'
					self.logger.info('Curate Data Successfully Written to Parquet File')
				except Exception as e:
					self.logger.info('Failed to Write Curate Data to Parquet File')
					raise
			
				try:
					self.logger.info('Adding Partitions to Table')
					alterQuery = """MSCK REPAIR TABLE {0}.{1}""".format(curate_db_name,curate_table_name)
					self.logger.info('Alter Query is: ' + alterQuery)
					result = stmt.execute(alterQuery)
					ingest_status[ingest_file_nm]['AlterQuery'] = 'SUCCESS'
					self.logger.info('Partitions Added Successfully')
				except Exception as e:
					self.logger.info('Failed to Add Partitions to Table')
					raise

				try:
					self.logger.info('Moving Ingest File from Staging HDFS to Raw HDFS Directory')
					fs = self.spark._jvm.org.apache.hadoop.fs.FileSystem.get(self.spark._jsc.hadoopConfiguration())
					if fs.exists(self.spark.sparkContext._jvm.Path(raw_hdfs_dir + ingest_file_nm)):
						fs.rename(
							self.spark.sparkContext._jvm.Path(raw_hdfs_dir + ingest_file_nm),
							self.spark.sparkContext._jvm.Path(raw_hdfs_dir + ingest_file_nm + "_" +datetime.today().strftime('%Y%m%d%H%M%S')))
						self.logger.info('Backed Up Older Raw HDFS Ingest File')
					fs.rename(
						self.spark.sparkContext._jvm.Path(staging_hdfs_dir + ingest_file_nm),
						self.spark.sparkContext._jvm.Path(raw_hdfs_dir + ingest_file_nm))
					ingest_status[ingest_file_nm]['RawMove'] = 'SUCCESS'
					self.logger.info('Successfully Moved Ingest File from Staging to Raw HDFS Directory')
				except Exception as e:
					self.logger.info('Failed to Move Ingest File from Staging HDFS to RAW HDFS Directory')
					raise

				self.logger.info('Ingest Status is: ' + json.dumps(ingest_status))

			self.logger.info('Closing Connection to HiveServer2')
			conn.close()
			self.logger.info('Successfully Closed Connection to HiveServer2')

			try:
				if 'tw_id_file' in self.args or 'tw_password' in self.args:
					self.logger.info('Uploading Interaction and Intent Extracts to TW Outbound Directory ' + tw_outbound_dir)
					if 'tw_id_file' in self.args:
						tw_id = self.args['tw_id_file']
						interaction_hdfs_output_audit_file = tw.upload_file(self.spark,tw_server,tw_user,tw_outbound_dir,self.interaction_hdfs_output_audit_file,identity=tw_id)
						interaction_hdfs_output_file = tw.upload_file(self.spark,tw_server,tw_user,tw_outbound_dir,self.interaction_hdfs_output_file,identity=tw_id)
						intent_hdfs_output_audit_file = tw.upload_file(self.spark,tw_server,tw_user,tw_outbound_dir,self.intent_hdfs_output_audit_file,identity=tw_id)
						intent_hdfs_output_file = tw.upload_file(self.spark,tw_server,tw_user,tw_outbound_dir,self.intent_hdfs_output_file,identity=tw_id)
	
					elif 'tw_password' in self.args:
						tw_pass = self.args['tw_password']
						interaction_hdfs_output_audit_file = tw.upload_file(self.spark,tw_server,tw_user,tw_outbound_dir,self.interaction_hdfs_output_audit_file,identity=tw_id)
						interaction_hdfs_output_file = tw.upload_file(self.spark,tw_server,tw_user,tw_outbound_dir,self.interaction_hdfs_output_file,identity=tw_id)
						intent_hdfs_output_audit_file = tw.upload_file(self.spark,tw_server,tw_user,tw_outbound_dir,self.intent_hdfs_output_audit_file,identity=tw_id)
						intent_hdfs_output_file = tw.upload_file(self.spark,tw_server,tw_user,tw_outbound_dir,self.intent_hdfs_output_file,identity=tw_id)
			except Exception as e:
				self.logger.info('Failed to upload Interaction and Intent Extracts to TW Outbound Directory')
				
			#try:
				#if 'tw_id_file' in self.args or 'tw_password' in self.args:
					#self.logger.info('Removing Source Ingestion File from TW FTP Server at Location: ' + tw_ascii_src_dir)
					#if 'tw_id_file' in self.args:
						#tw_id = self.args['tw_id_file']
						#tw_tgt_interaction_file_nm = tw.remove_file(self.spark,tw_server,tw_user,tw_ascii_src_dir,tw_tgt_interaction_file_nm,identity=tw_id)
						#tw_tgt_intent_file_nm = tw.remove_file(self.spark,tw_server,tw_user,tw_ascii_src_dir,tw_tgt_intent_file_nm,identity=tw_id)
					#elif 'tw_password' in self.args:
						#tw_pass = self.args['tw_password']
						#tw_tgt_interaction_file_nm = tw.remove_file(self.spark,tw_server,tw_user,tw_ascii_src_dir,tw_tgt_interaction_file_nm,password=tw_pass)
						#tw_tgt_intent_file_nm = tw.remove_file(self.spark,tw_server,tw_user,tw_ascii_src_dir,tw_tgt_intent_file_nm,password=tw_pass)
			#except Exception as e:
				#self.logger.info('Failed to Remove Source Ingestion File from TW FTP Server')

			self.logger.info('Appsimp Audit logs table will be updated with SUCCESS Status')
			au.set_success(self.spark,self.env,self.job_nm,self.host_nm,self.yarn_app_id,self.start_time,"",self.log_file,self.dmn)
			self.end_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
			self.logger.info('Job End Time is: ' + self.end_time)
			self.logger.info('Finished Executing the Job: ' + self.job_nm)
		except Exception as e:
			self.logger.info('Rolling back Ingested Data if Required')
			if ingest_status != None and input_trigger_list != None:
				for ingest_file_nm,schema_file_nm in input_trigger_list:
					file_key = ingest_file_nm
					if file_key in ingest_status.keys() and ingest_status[file_key]['RawMove'] == 'SUCCESS':
						self.logger.info('Rolling back Ingest File from RAW HDFS to Staging HDFS Directory')
						self.logger.info('Deleting RAW HDFS Directory: ' + ingest_status[file_key]['raw_hdfs_dir'] + ingest_file_nm)
						fs.delete(self.spark.sparkContext._jvm.Path(ingest_status[file_key]['raw_hdfs_dir'] + ingest_file_nm),True)
						self.logger.info('Deleted RAW HDFS Directory Successfully')
					if file_key in ingest_status.keys() and (ingest_status[file_key]['AlterQuery'] == 'SUCCESS' or ingest_status[file_key]['ParquetWrite'] == 'SUCCESS'):
						self.logger.info('Rolling back Ingest File from Curate HDFS Directory')
						self.logger.info('Deleting Curate HDFS Directory: '+ ingest_status[file_key]['curate_hdfs_dir'] +'feed_dt='+ feed_dt)
						fs.delete(self.spark.sparkContext._jvm.Path(ingest_status[file_key]['curate_hdfs_dir'] + 'feed_dt='+ feed_dt),True)
						self.logger.info('Deleting Curate HDFS Directory Sucessfully')
				self.logger.info('Rolling back Ingested Data Done')
			self.logger.info('Appsimp Audit logs table will be updated with FAILED Status')
			au.set_failed(self.spark,self.env,self.job_nm,self.host_nm,self.yarn_app_id,self.start_time,"",self.log_file,self.dmn)
			raise

def main(spark,**args):
	logger = spark.sparkContext._jvm.org.apache.log4j.LogManager.getLogger(__name__)
	obj =  datapod_blueview_file_ingestion(spark,args)
	logger.info("Successfully Initialized the Pyspark Job: " + spark.sparkContext.appName)
	try:
		obj.run()
	except Exception as e:
		raise
