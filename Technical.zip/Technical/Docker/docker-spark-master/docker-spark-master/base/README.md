# Spark base

The Spark base image serves as a base image for the Spark master, Spark worker and Spark submit images. The user should not run this image directly. See [big-data-europe/docker-spark README](https://github.com/big-data-europe/docker-spark) for more information.