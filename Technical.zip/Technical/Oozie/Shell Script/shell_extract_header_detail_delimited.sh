# workarounds:
export PYTHON_EGG_CACHE='/tmp'

kinit csaload1 -kt /home/csaload1/.key

current_time=$(date "+%Y%m%d_%H%M%S")

FILE=$1_$current_time.txt
DELIMITER=$2
EXTRACT_SQL=$3
INSERT_SQL=$4
TW_FOLDER=$5


#echo "----------START-----------------"
#echo "File-->$FILE"
#echo "---------------------------"
#echo "EXTRACT_SQL-->$EXTRACT_SQL"
#echo "---------------------------"
#echo "INSERT_SQL-->$INSERT_SQL"
#echo "---------------------------"
#echo "TW_FOLDER-->$TW_FOLDER"
#echo "----------END-----------------"




shift
shift
shift
shift
shift
# iterate
while test ${#} -gt 0
do
  impala-shell -i impala.dr.bcbsma.com -d default -k --ssl -B --output_delimiter="$DELIMITER" -q "$1"  >> $FILE
  shift
done

#echo "EXTRACT_SQL-->$EXTRACT_SQL"
impala-shell -i impala.dr.bcbsma.com -d default -k --ssl -B --output_delimiter="$DELIMITER" -q "$EXTRACT_SQL" >> $FILE

export SSHPASS=Wintersnow@2019
sshpass -e sftp -oBatchMode=no -b - csaload01ts@staging.sftp.bluecrossma.com << !
   cd $TW_FOLDER
   put $FILE
   !rm $FILE
   bye
!

#echo "SFTP return code1-->$?"
#echo "SFTP return code2-->$?"

if [ $? -eq 0 ]  
then 
#   echo "INSERT_SQL-->$INSERT_SQL"
   impala-shell -i impala.dr.bcbsma.com -d default -k --ssl -B -q "$INSERT_SQL"
else
    echo "SFTP to Tumble Weed is failed"
    exit 1
fi 



