# workarounds:
export PYTHON_EGG_CACHE='/tmp'

kinit csaload1 -kt /home/csaload1/.key

current_time=$(date "+$8")

FILE=$2_$current_time$7
EXTRACT_SQL=$1
DELIMITER=$3
TW_FOLDER=$4
INSERT_SQL=$5
HEADER_SQL=$6
FILE_FORMAT=$7
FILE_TIMESTAMP=$8

echo "----------START------------------"
echo "File-->$FILE"
echo "---------------------------"
echo "EXTRACT_SQL-->$EXTRACT_SQL"
echo "---------------------------"
echo "DELIMITER-->$DELIMITER"
echo "---------------------------"
echo "TW_FOLDER-->$TW_FOLDER"
echo "---------------------------"
echo "INSERT_SQL-->$INSERT_SQL"
echo "---------------------------"
echo "HEADER_SQL-->$HEADER_SQL"
echo "---------------------------"
echo "FILE_FORMAT-->$FILE_FORMAT"
echo "---------------------------"
echo "FILE_TIMESTAMP-->$FILE_TIMESTAMP"
echo "----------END--------------------"

echo "Running Header SQL...."
impala-shell -i impala.dr.bcbsma.com -d default -k --ssl -B --output_delimiter="$DELIMITER" -q "$HEADER_SQL"  >> $FILE
echo "Running Extract SQL...."
impala-shell -i impala.dr.bcbsma.com -d default -k --ssl -B --output_delimiter="$DELIMITER" -q "$EXTRACT_SQL" >> $FILE

echo "Sending file to SFTP...."
export SSHPASS=Wintersnow@2019
sshpass -e sftp -oBatchMode=no -b - csaload01ts@staging.sftp.bluecrossma.com << !
   cd $TW_FOLDER
   put $FILE
   !rm $FILE
   bye
!

#echo "SFTP return code-->$?"

if [ $? -eq 0 ]  
then 
   rcdcount=$(impala-shell -i impala.dr.bcbsma.com -k --ssl -B -q "select count(*) from test_publish_fin.cash_detail_mon;" 2>/dev/null)
   sleep 5
   totamt=$(impala-shell -i impala.dr.bcbsma.com -k --ssl -B -q "select sum(tot_alloc_amt) from test_publish_fin.cash_detail_mon;" 2>/dev/null)
   sleep 5
   echo "rcdcount-->$rcdcount"
   echo "totamt-->$totamt"
   echo "INSERT_SQL-->$INSERT_SQL"
   impala-shell -i impala.dr.bcbsma.com -d default -k --ssl -B --var=rcdcount1=$rcdcount --var=filename=$FILE --var=totamt1=$totamt -q "$INSERT_SQL"
   echo "Hello"
else
    echo "SFTP to Tumble Weed is failed"
    exit 1
fi 
